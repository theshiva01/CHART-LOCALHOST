/** @type {import('tailwindcss').Config} */
export default {
  content: [
    "./index.html",
    "./src/**/*.{js,ts,jsx,tsx}",
  ],
  darkMode: 'class',
  theme: {
    extend: {
      colors: {
        tv: {
          dark: {
            bg: '#131722',
            card: '#1e222d',
            hover: '#2a2e39',
            border: '#2a2e39',
            subtle: '#363c4e',
            text: '#d1d4dc',
            textMuted: '#787b86',
            green: '#089981',
            red: '#f23645',
            blue: '#2962ff'
          },
          light: {
            bg: '#f0f3fa',
            card: '#ffffff',
            hover: '#f8f9fd',
            border: '#e0e3eb',
            subtle: '#d1d4dc',
            text: '#131722',
            textMuted: '#787b86',
            green: '#089981',
            red: '#f23645',
            blue: '#2962ff'
          }
        }
      }
    },
  },
  plugins: [],
}

