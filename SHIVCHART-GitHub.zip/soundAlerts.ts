/**
 * Web Audio API synthesized sound generator for Order Block alerts
 * Zero external audio files required, zero latency, works 100% reliably
 */

class SoundAlertManager {
  private ctx: AudioContext | null = null;
  private soundEnabled: boolean = true;

  constructor() {
    // Read initial preference from localStorage
    const saved = localStorage.getItem('shivchart_sound_enabled');
    if (saved !== null) {
      this.soundEnabled = saved === 'true';
    }
  }

  private initContext() {
    if (!this.ctx) {
      const AudioContextClass = window.AudioContext || (window as any).webkitAudioContext;
      if (AudioContextClass) {
        this.ctx = new AudioContextClass();
      }
    }
    if (this.ctx && this.ctx.state === 'suspended') {
      this.ctx.resume().catch(() => {});
    }
  }

  public isEnabled(): boolean {
    return this.soundEnabled;
  }

  public setEnabled(enabled: boolean) {
    this.soundEnabled = enabled;
    localStorage.setItem('shivchart_sound_enabled', String(enabled));
    if (enabled) {
      this.initContext();
      // Quick subtle feedback chirp when turning sound ON
      this.playChirp(880, 0.08);
    }
  }

  public toggle(): boolean {
    this.setEnabled(!this.soundEnabled);
    return this.soundEnabled;
  }

  /**
   * Play audio chime when an SMC Order Block forms
   */
  public playOrderBlockAlert(type: 'bullish' | 'bearish') {
    if (!this.soundEnabled) return;
    this.initContext();
    if (!this.ctx) return;

    const now = this.ctx.currentTime;

    if (type === 'bullish') {
      // Bullish Demand (+OB): Ascending harmonic chime (D5 -> A5)
      this.playTone(587.33, now, 0.12, 'sine', 0.18);
      this.playTone(880.00, now + 0.1, 0.28, 'triangle', 0.22);
    } else {
      // Bearish Supply (-OB): Alert descending chime (G5 -> Eb5)
      this.playTone(783.99, now, 0.12, 'sine', 0.18);
      this.playTone(622.25, now + 0.1, 0.28, 'sawtooth', 0.15);
    }
  }

  private playTone(freq: number, startTime: number, duration: number, wave: OscillatorType, maxVolume = 0.2) {
    if (!this.ctx) return;
    try {
      const osc = this.ctx.createOscillator();
      const gain = this.ctx.createGain();

      osc.type = wave;
      osc.frequency.setValueAtTime(freq, startTime);

      // Smooth attack and exponential decay to prevent audio clicks
      gain.gain.setValueAtTime(0.0001, startTime);
      gain.gain.exponentialRampToValueAtTime(maxVolume, startTime + 0.02);
      gain.gain.exponentialRampToValueAtTime(0.0001, startTime + duration);

      osc.connect(gain);
      gain.connect(this.ctx.destination);

      osc.start(startTime);
      osc.stop(startTime + duration);
    } catch (_) {}
  }

  private playChirp(freq: number, duration: number) {
    if (!this.ctx) return;
    const now = this.ctx.currentTime;
    this.playTone(freq, now, duration, 'sine', 0.1);
  }
}

export const soundManager = new SoundAlertManager();

