import React from 'react';
import {
  Moon,
  Sun,
  Sliders,
  Key,
  Maximize,
  Minimize,
  Eye,
  EyeOff,
  Crosshair,
  Clock,
  TrendingUp,
  BarChart2,
  LineChart,
  Layers,
  ChevronDown,
  PanelLeftClose,
  PanelLeftOpen,
  Volume2,
  VolumeX
} from 'lucide-react';
import { LayoutSelector } from './LayoutSelector';
import { LayoutPreset, Timeframe, ChartType, IndicatorConfig, UpstoxStatus } from '../types/chart';

interface HeaderProps {
  currentLayout: LayoutPreset;
  onSelectLayout: (layout: LayoutPreset) => void;
  isDark: boolean;
  onToggleTheme: () => void;
  onOpenIndicators: () => void;
  onOpenUpstox: () => void;
  upstoxStatus: UpstoxStatus;
  globalIndicators: IndicatorConfig;
  onToggleQuickIndicator: (key: keyof IndicatorConfig) => void;
  activeTimeframe: Timeframe;
  onChangeTimeframe: (tf: Timeframe) => void;
  activeChartType: ChartType;
  onChangeChartType: (type: ChartType) => void;
  syncCrosshair: boolean;
  onToggleSyncCrosshair: () => void;
  syncTime: boolean;
  onToggleSyncTime: () => void;
  isFullscreen: boolean;
  onToggleFullscreen: () => void;
  showToolbar: boolean;
  onToggleToolbar: () => void;
  soundEnabled: boolean;
  onToggleSound: () => void;
}

const TIMEFRAMES: Timeframe[] = ['1m', '3m', '5m', '15m', '30m', '1h', '1D'];

export const Header: React.FC<HeaderProps> = ({
  currentLayout,
  onSelectLayout,
  isDark,
  onToggleTheme,
  onOpenIndicators,
  onOpenUpstox,
  upstoxStatus,
  globalIndicators,
  onToggleQuickIndicator,
  activeTimeframe,
  onChangeTimeframe,
  activeChartType,
  onChangeChartType,
  syncCrosshair,
  onToggleSyncCrosshair,
  syncTime,
  onToggleSyncTime,
  isFullscreen,
  onToggleFullscreen,
  showToolbar,
  onToggleToolbar,
  soundEnabled,
  onToggleSound,
}) => {
  return (
    <header
      className={`h-12 px-3 border-b flex items-center justify-between text-xs select-none z-30 shrink-0 ${
        isDark ? 'bg-[#1e222d] border-[#2a2e39] text-[#d1d4dc]' : 'bg-[#ffffff] border-[#e0e3eb] text-[#131722]'
      }`}
    >
      {/* Left: Brand + Layout + Timeframe + Chart Type */}
      <div className="flex items-center gap-3">
        {/* Logo */}
        <div className="flex items-center gap-1.5 font-bold tracking-tight text-sm pr-2 border-r border-opacity-30 border-gray-500">
          <div className="w-6 h-6 rounded bg-[#2962ff] flex items-center justify-center text-white font-black text-xs shadow-sm">
            ⚡
          </div>
          <span className="bg-gradient-to-r from-blue-500 via-indigo-500 to-teal-400 bg-clip-text text-transparent font-black tracking-wider">
            SHIVCHART
          </span>
          <span className="text-[10px] px-1 py-0.5 rounded bg-blue-500/10 text-[#2962ff] font-mono">
            PRO
          </span>
        </div>

        {/* Layout Selector (1 - 12 charts) */}
        <LayoutSelector
          currentCount={currentLayout}
          onSelectLayout={onSelectLayout}
          isDark={isDark}
        />

        {/* Toggle Left Drawing Toolbar */}
        <button
          onClick={onToggleToolbar}
          title={showToolbar ? 'Hide Drawing Tools (Full Width Charts)' : 'Show Drawing Tools'}
          className={`p-1.5 rounded transition-all flex items-center gap-1 ${
            showToolbar ? 'bg-black/10 dark:bg-white/10 text-[#2962ff]' : 'opacity-60 hover:opacity-100 hover:bg-current/10'
          }`}
        >
          {showToolbar ? <PanelLeftClose className="w-3.5 h-3.5" /> : <PanelLeftOpen className="w-3.5 h-3.5" />}
        </button>

        {/* Timeframes Bar */}
        <div className="flex items-center bg-black/5 dark:bg-[#131722] p-0.5 rounded border border-current/10">
          {TIMEFRAMES.map((tf) => (
            <button
              key={tf}
              onClick={() => onChangeTimeframe(tf)}
              className={`px-2 py-1 rounded text-[11px] font-semibold transition-all ${
                activeTimeframe === tf
                  ? 'bg-[#2962ff] text-white shadow-sm'
                  : 'hover:bg-current/10 opacity-70 hover:opacity-100'
              }`}
            >
              {tf}
            </button>
          ))}
        </div>

        {/* Chart Style Switcher */}
        <div className="flex items-center bg-black/5 dark:bg-[#131722] p-0.5 rounded border border-current/10">
          <button
            onClick={() => onChangeChartType('candlestick')}
            title="Candlestick Chart"
            className={`p-1 rounded ${activeChartType === 'candlestick' ? 'bg-[#2962ff] text-white' : 'opacity-60 hover:opacity-100'}`}
          >
            <BarChart2 className="w-3.5 h-3.5" />
          </button>
          <button
            onClick={() => onChangeChartType('heikin')}
            title="Heikin-Ashi Candles"
            className={`px-1.5 py-0.5 rounded text-[10px] font-bold ${activeChartType === 'heikin' ? 'bg-[#2962ff] text-white' : 'opacity-60 hover:opacity-100'}`}
          >
            HA
          </button>
          <button
            onClick={() => onChangeChartType('line')}
            title="Line Chart"
            className={`p-1 rounded ${activeChartType === 'line' ? 'bg-[#2962ff] text-white' : 'opacity-60 hover:opacity-100'}`}
          >
            <LineChart className="w-3.5 h-3.5" />
          </button>
          <button
            onClick={() => onChangeChartType('area')}
            title="Area Chart"
            className={`p-1 rounded ${activeChartType === 'area' ? 'bg-[#2962ff] text-white' : 'opacity-60 hover:opacity-100'}`}
          >
            <TrendingUp className="w-3.5 h-3.5" />
          </button>
        </div>
      </div>

      {/* Center: Quick Indicator Pills (EMA 9, 15, VWAP, PDH/PDL, 5m, 15m) */}
      <div className="hidden lg:flex items-center gap-1.5">
        {/* EMA 9 */}
        <button
          onClick={() => onToggleQuickIndicator('ema9')}
          className={`flex items-center gap-1 px-2 py-1 rounded text-[11px] font-semibold border transition-all ${
            globalIndicators.ema9.enabled
              ? 'bg-blue-500/15 border-blue-500 text-blue-500'
              : 'border-transparent opacity-40 hover:opacity-75'
          }`}
          title="Toggle EMA 9"
        >
          <span className="w-2 h-2 rounded-full" style={{ backgroundColor: globalIndicators.ema9.color }} />
          EMA 9
        </button>

        {/* EMA 15 */}
        <button
          onClick={() => onToggleQuickIndicator('ema15')}
          className={`flex items-center gap-1 px-2 py-1 rounded text-[11px] font-semibold border transition-all ${
            globalIndicators.ema15.enabled
              ? 'bg-orange-500/15 border-orange-500 text-orange-500'
              : 'border-transparent opacity-40 hover:opacity-75'
          }`}
          title="Toggle EMA 15"
        >
          <span className="w-2 h-2 rounded-full" style={{ backgroundColor: globalIndicators.ema15.color }} />
          EMA 15
        </button>

        {/* VWAP */}
        <button
          onClick={() => onToggleQuickIndicator('vwap')}
          className={`flex items-center gap-1 px-2 py-1 rounded text-[11px] font-semibold border transition-all ${
            globalIndicators.vwap.enabled
              ? 'bg-pink-500/15 border-pink-500 text-pink-500'
              : 'border-transparent opacity-40 hover:opacity-75'
          }`}
          title="Toggle VWAP"
        >
          <span className="w-2 h-2 rounded-full" style={{ backgroundColor: globalIndicators.vwap.color }} />
          VWAP
        </button>

        {/* PDH / PDL */}
        <button
          onClick={() => {
            onToggleQuickIndicator('pdh');
            onToggleQuickIndicator('pdl');
          }}
          className={`flex items-center gap-1 px-2 py-1 rounded text-[11px] font-semibold border transition-all ${
            globalIndicators.pdh.enabled || globalIndicators.pdl.enabled
              ? 'bg-emerald-500/15 border-emerald-500 text-emerald-500'
              : 'border-transparent opacity-40 hover:opacity-75'
          }`}
          title="Toggle Previous Day High & Low"
        >
          <span className="w-2 h-2 rounded-full bg-emerald-500" />
          PDH / PDL
        </button>

        {/* 5m High / Low */}
        <button
          onClick={() => onToggleQuickIndicator('highLow5m')}
          className={`flex items-center gap-1 px-2 py-1 rounded text-[11px] font-semibold border transition-all ${
            globalIndicators.highLow5m.enabled
              ? 'bg-cyan-500/15 border-cyan-500 text-cyan-500'
              : 'border-transparent opacity-40 hover:opacity-75'
          }`}
          title="Toggle 5-Min Opening High / Low"
        >
          <span className="w-2 h-2 rounded-full bg-cyan-400" />
          5m H/L
        </button>

        {/* 15m High / Low */}
        <button
          onClick={() => onToggleQuickIndicator('highLow15m')}
          className={`flex items-center gap-1 px-2 py-1 rounded text-[11px] font-semibold border transition-all ${
            globalIndicators.highLow15m.enabled
              ? 'bg-yellow-500/15 border-yellow-500 text-yellow-500'
              : 'border-transparent opacity-40 hover:opacity-75'
          }`}
          title="Toggle 15-Min Opening High / Low"
        >
          <span className="w-2 h-2 rounded-full bg-yellow-400" />
          15m H/L
        </button>

        {/* SMC Order Blocks */}
        <button
          onClick={() => onToggleQuickIndicator('orderBlocks')}
          className={`flex items-center gap-1 px-2 py-1 rounded text-[11px] font-semibold border transition-all ${
            globalIndicators.orderBlocks?.enabled
              ? 'bg-emerald-500/15 border-emerald-500 text-emerald-400 font-bold'
              : 'border-transparent opacity-40 hover:opacity-75'
          }`}
          title="Toggle SMC Order Blocks (+OB Demand / -OB Supply)"
        >
          <span className="w-2 h-2 rounded-full bg-emerald-400" />
          OB Zones
        </button>

        {/* Session Break Line (Solid Vertical Line) */}
        <button
          onClick={() => onToggleQuickIndicator('sessionBreak')}
          className={`flex items-center gap-1 px-2 py-1 rounded text-[11px] font-semibold border transition-all ${
            globalIndicators.sessionBreak?.enabled
              ? 'bg-blue-500/15 border-blue-500 text-blue-400 font-bold'
              : 'border-transparent opacity-40 hover:opacity-75'
          }`}
          title="Toggle Yesterday/Today Session Break Solid Line"
        >
          <span className="w-2 h-2 rounded-full bg-blue-500" />
          Session Line
        </button>

        {/* Supertrend (Pine Script ta.supertrend) */}
        <button
          onClick={() => onToggleQuickIndicator('supertrend')}
          className={`flex items-center gap-1 px-2 py-1 rounded text-[11px] font-semibold border transition-all ${
            globalIndicators.supertrend?.enabled
              ? 'bg-emerald-500/15 border-emerald-500 text-emerald-400 font-bold'
              : 'border-transparent opacity-40 hover:opacity-75'
          }`}
          title="Toggle Supertrend (ATR 10, Multiplier 3.0)"
        >
          <span className="w-2 h-2 rounded-full bg-emerald-400" />
          ST
        </button>

        {/* ADX Live Candle Label (Pine Script ta.dmi) */}
        <button
          onClick={() => onToggleQuickIndicator('adx')}
          className={`flex items-center gap-1 px-2 py-1 rounded text-[11px] font-semibold border transition-all ${
            globalIndicators.adx?.enabled
              ? 'bg-teal-500/15 border-teal-500 text-teal-400 font-bold'
              : 'border-transparent opacity-40 hover:opacity-75'
          }`}
          title="Toggle ADX Live Candle Label"
        >
          <span className="w-2 h-2 rounded-full bg-teal-400" />
          ADX
        </button>

        {/* TOD RVOL (Relative Volume Histogram) */}
        <button
          onClick={() => onToggleQuickIndicator('todRvol')}
          className={`flex items-center gap-1 px-2 py-1 rounded text-[11px] font-semibold border transition-all ${
            globalIndicators.todRvol?.enabled
              ? 'bg-lime-500/15 border-lime-500 text-lime-400 font-bold'
              : 'border-transparent opacity-40 hover:opacity-75'
          }`}
          title="Toggle Time-of-Day Relative Volume"
        >
          <span className="w-2 h-2 rounded-full bg-lime-400" />
          RVOL
        </button>

        {/* Demand & Supply Levels (1,2,3 Day, 1,2,3 Week, 1,2,3 Month) */}
        <button
          onClick={() => onToggleQuickIndicator('demandSupply')}
          className={`flex items-center gap-1 px-2 py-1 rounded text-[11px] font-semibold border transition-all ${
            globalIndicators.demandSupply?.enabled
              ? 'bg-purple-500/15 border-purple-500 text-purple-400 font-bold'
              : 'border-transparent opacity-40 hover:opacity-75'
          }`}
          title="Toggle 1,2,3 Day | 1,2,3 Week | 1,2,3 Month Demand & Supply Levels"
        >
          <span className="w-2 h-2 rounded-full bg-purple-400" />
          D/S (1,2,3)
        </button>

        {/* Indicators Modal Button */}
        <button
          onClick={onOpenIndicators}
          className="p-1.5 rounded hover:bg-current/10 opacity-70 hover:opacity-100 transition-opacity"
          title="Customize Indicator Colors & Settings"
        >
          <Sliders className="w-3.5 h-3.5" />
        </button>
      </div>

      {/* Right: Sync Controls + Upstox Token + Theme + Fullscreen */}
      <div className="flex items-center gap-2">
        {/* Sound Alert Toggle */}
        <button
          onClick={onToggleSound}
          title={soundEnabled ? 'Order Block Sound Alerts: Active' : 'Order Block Sound Alerts: Muted'}
          className={`px-2 py-1.5 rounded border transition-all flex items-center gap-1.5 font-bold ${
            soundEnabled
              ? 'bg-emerald-500/15 border-emerald-500/40 text-emerald-400'
              : 'border-transparent opacity-40 hover:opacity-100 hover:bg-current/10 text-gray-400'
          }`}
        >
          {soundEnabled ? <Volume2 className="w-3.5 h-3.5" /> : <VolumeX className="w-3.5 h-3.5" />}
          <span className="text-[10px] hidden sm:inline">{soundEnabled ? 'Sound ON' : 'Muted'}</span>
        </button>
        {/* Sync Crosshair */}
        <button
          onClick={onToggleSyncCrosshair}
          title={syncCrosshair ? 'Sync Crosshair: Active' : 'Sync Crosshair: Disabled'}
          className={`p-1.5 rounded transition-all flex items-center gap-1 ${
            syncCrosshair
              ? 'bg-[#2962ff] text-white'
              : 'opacity-60 hover:opacity-100 hover:bg-current/10'
          }`}
        >
          <Crosshair className="w-3.5 h-3.5" />
          <span className="text-[10px] hidden xl:inline">Crosshair Sync</span>
        </button>

        {/* Sync Time */}
        <button
          onClick={onToggleSyncTime}
          title={syncTime ? 'Sync Time Scale: Active' : 'Sync Time Scale: Disabled'}
          className={`p-1.5 rounded transition-all flex items-center gap-1 ${
            syncTime
              ? 'bg-[#2962ff] text-white'
              : 'opacity-60 hover:opacity-100 hover:bg-current/10'
          }`}
        >
          <Clock className="w-3.5 h-3.5" />
          <span className="text-[10px] hidden xl:inline">Time Sync</span>
        </button>

        <div className="w-px h-5 bg-gray-500/30 mx-1" />

        {/* Upstox Connect Button */}
        <button
          onClick={onOpenUpstox}
          className={`flex items-center gap-1.5 px-2.5 py-1.5 rounded border font-semibold transition-all ${
            upstoxStatus.connected
              ? 'bg-emerald-500/15 border-emerald-500/40 text-emerald-400 hover:bg-emerald-500/25'
              : 'bg-amber-500/10 border-amber-500/30 text-amber-400 hover:bg-amber-500/20'
          }`}
          title="Connect Upstox Access Token for Live Tick Feed"
        >
          <span className={`w-2 h-2 rounded-full ${upstoxStatus.connected ? 'bg-emerald-500' : 'bg-amber-400'} animate-pulse`} />
          <Key className="w-3.5 h-3.5" />
          <span>{upstoxStatus.connected ? 'Upstox Live' : 'Upstox Token'}</span>
        </button>

        {/* Theme Toggle (Light / Dark) */}
        <button
          onClick={onToggleTheme}
          title={`Switch to ${isDark ? 'Light' : 'Dark'} Theme`}
          className="p-1.5 rounded hover:bg-current/10 transition-colors"
        >
          {isDark ? <Sun className="w-4 h-4 text-amber-400" /> : <Moon className="w-4 h-4 text-indigo-600" />}
        </button>

        {/* Fullscreen */}
        <button
          onClick={onToggleFullscreen}
          title={isFullscreen ? 'Exit Fullscreen' : 'Enter Fullscreen'}
          className="p-1.5 rounded hover:bg-current/10 transition-colors"
        >
          {isFullscreen ? <Minimize className="w-4 h-4" /> : <Maximize className="w-4 h-4" />}
        </button>
      </div>
    </header>
  );
};

