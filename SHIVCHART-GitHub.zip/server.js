const http = require('http');
const path = require('path');
const express = require('express');
const cors = require('cors');
const { WebSocketServer, WebSocket } = require('ws');
const instruments = require('./instruments.json');
const upstoxFeed = require('./upstoxFeed');

const app = express();
const PORT = process.env.PORT || (process.env.SERVE_STATIC ? 5000 : 5005);

app.use(cors());
app.use(express.json());

// Serve static frontend build if requested
const clientDistPath = path.join(__dirname, '..', 'client', 'dist');
if (process.env.SERVE_STATIC) {
  app.use(express.static(clientDistPath));
}

// Create HTTP Server
const server = http.createServer(app);

// Create WebSocket Server
const wss = new WebSocketServer({ server });

// Set of all active subscribed instrument keys across all clients
const activeSubscribers = new Map(); // clientWs -> Set of instrumentKeys

// Track ticks per second
let ticksCount = 0;
let currentTps = 0;
setInterval(() => {
  currentTps = ticksCount;
  ticksCount = 0;
}, 1000);

// Forward Upstox ticks directly to connected clients
upstoxFeed.on('tick', (tick) => {
  ticksCount++;
  broadcastTick(tick);
});

// Broadcast Upstox connection status changes
upstoxFeed.on('status', (status) => {
  console.log('📡 Upstox Status Changed:', status);
  broadcastToAll({
    type: 'status',
    ...status
  });

  if (status.connected) {
    // Automatically subscribe Upstox to all active chart instruments
    const allKeys = new Set();
    activeSubscribers.forEach(keys => keys.forEach(k => allKeys.add(k)));
    if (allKeys.size === 0) {
      instruments.slice(0, 12).forEach(i => allKeys.add(i.instrumentKey));
    }
    const keysArray = Array.from(allKeys);
    console.log(`⚡ Auto-subscribing Upstox to ${keysArray.length} active keys:`, keysArray.slice(0, 5));
    upstoxFeed.subscribe(keysArray);
  }
});

function broadcastTick(tick) {
  const msg = JSON.stringify({ type: 'tick', data: tick });
  wss.clients.forEach(client => {
    if (client.readyState === WebSocket.OPEN) {
      const clientSubs = activeSubscribers.get(client);
      if (!clientSubs || clientSubs.has(tick.instrumentKey) || clientSubs.size === 0) {
        client.send(msg);
      }
    }
  });
}

function broadcastToAll(payload) {
  const msg = JSON.stringify(payload);
  wss.clients.forEach(client => {
    if (client.readyState === WebSocket.OPEN) {
      client.send(msg);
    }
  });
}

// WebSocket Connection Handler
wss.on('connection', (ws) => {
  activeSubscribers.set(ws, new Set());

  // Send initial status
  ws.send(JSON.stringify({
    type: 'status',
    connected: upstoxFeed.isConnected,
    mode: upstoxFeed.isConnected ? 'live' : 'standby',
    user: upstoxFeed.userProfile,
    message: upstoxFeed.isConnected ? 'Connected to Upstox Live Feed' : 'Enter Upstox Access Token for Live Ticks'
  }));

  ws.on('message', (message) => {
    try {
      const data = JSON.parse(message.toString());

      if (data.type === 'subscribe') {
        const keys = Array.isArray(data.keys) ? data.keys : [data.keys];
        const subs = activeSubscribers.get(ws);
        keys.forEach(k => subs.add(k));

        // Always register with Upstox live feed
        upstoxFeed.subscribe(keys);
      } else if (data.type === 'unsubscribe') {
        const keys = Array.isArray(data.keys) ? data.keys : [data.keys];
        const subs = activeSubscribers.get(ws);
        keys.forEach(k => subs.delete(k));

        if (upstoxFeed.isConnected) {
          const neededByOthers = new Set();
          activeSubscribers.forEach((otherSubs, otherWs) => {
            if (otherWs !== ws) otherSubs.forEach(k => neededByOthers.add(k));
          });
          const toUnsub = keys.filter(k => !neededByOthers.has(k));
          if (toUnsub.length > 0) {
            upstoxFeed.unsubscribe(toUnsub);
          }
        }
      } else if (data.type === 'ping') {
        ws.send(JSON.stringify({ type: 'pong', time: Date.now() }));
      }
    } catch (err) {
      console.error('WS message parse error:', err.message);
    }
  });

  ws.on('close', () => {
    activeSubscribers.delete(ws);
  });
});

// REST API Endpoints

// 1. Instruments list & search (Indices + 501 Nifty 500 stocks)
app.get('/api/instruments', (req, res) => {
  const query = (req.query.q || '').toLowerCase();
  if (!query) {
    return res.json(instruments);
  }
  const filtered = instruments.filter(i => 
    i.symbol.toLowerCase().includes(query) || 
    i.name.toLowerCase().includes(query) ||
    i.instrumentKey.toLowerCase().includes(query)
  );
  res.json(filtered);
});

// 2. 100% REAL LIVE Historical Candles (No mock/simulator)
app.get('/api/candles', async (req, res) => {
  const { instrumentKey = 'NSE_INDEX|Nifty 50', interval = '5m' } = req.query;

  try {
    const result = await upstoxFeed.fetchHistoricalCandles(instrumentKey, interval);

    res.json({
      success: true,
      source: 'upstox_live',
      instrumentKey,
      interval,
      candles: result.candles,
      pdh: result.pdh,
      pdl: result.pdl,
      demandSupply: result.demandSupply
    });
  } catch (err) {
    res.status(500).json({ success: false, error: err.message });
  }
});

// 3. Connect Upstox Token
app.post('/api/upstox/token', async (req, res) => {
  const { token } = req.body;
  if (!token) {
    return res.status(400).json({ success: false, error: 'Token is required' });
  }

  try {
    const result = await upstoxFeed.setAccessToken(token);
    
    // Auto-subscribe all currently active charts immediately
    const allKeys = new Set();
    activeSubscribers.forEach(keys => keys.forEach(k => allKeys.add(k)));
    if (allKeys.size === 0) {
      instruments.slice(0, 12).forEach(i => allKeys.add(i.instrumentKey));
    }
    upstoxFeed.subscribe(Array.from(allKeys));

    res.json({
      success: true,
      message: 'Upstox Token connected successfully',
      ...result
    });
  } catch (err) {
    res.status(401).json({ success: false, error: err.message });
  }
});

// 4. Disconnect Upstox Token
app.delete('/api/upstox/token', async (req, res) => {
  try {
    await upstoxFeed.setAccessToken('');
    res.json({ success: true, message: 'Disconnected from Upstox.' });
  } catch (err) {
    res.status(500).json({ success: false, error: err.message });
  }
});

// 5. Check Upstox Status
app.get('/api/upstox/status', (req, res) => {
  res.json({
    connected: upstoxFeed.isConnected,
    mode: upstoxFeed.isConnected ? 'live' : 'standby',
    user: upstoxFeed.userProfile,
    activeSubscribersCount: activeSubscribers.size,
    tps: currentTps
  });
});

if (process.env.SERVE_STATIC) {
  app.get('*', (req, res) => {
    res.sendFile(path.join(clientDistPath, 'index.html'));
  });
}

// Start listening on port 5005 (proxied through 5000)
server.listen(PORT, () => {
  console.log(`===============================================`);
  console.log(`🚀 SHIVCHART Server running on port ${PORT}`);
  console.log(`📡 WebSocket endpoint: ws://localhost:${PORT}`);
  console.log(`📊 Mode: 100% REAL LIVE UPSTOX DATA`);
  console.log(`===============================================`);
});
