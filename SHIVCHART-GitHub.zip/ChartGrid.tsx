import React, { useState } from 'react';
import { SingleChart } from './SingleChart';
import {
  ChartConfig,
  LayoutPreset,
  InstrumentItem,
  TickData,
  OrderBlockAlert
} from '../types/chart';

interface ChartGridProps {
  charts: ChartConfig[];
  layoutCount: LayoutPreset;
  isDark: boolean;
  onUpdateChartConfig: (id: string, newConfig: Partial<ChartConfig>) => void;
  onRemoveChart: (id: string) => void;
  onOpenIndicatorsForChart: (chart: ChartConfig) => void;
  instrumentsList: InstrumentItem[];
  subscribe: (keys: string | string[], cb: (tick: TickData) => void) => void;
  unsubscribe: (keys: string | string[], cb: (tick: TickData) => void) => void;
  syncCrosshair: boolean;
  onOrderBlockAlert?: (alert: OrderBlockAlert) => void;
}

export const ChartGrid: React.FC<ChartGridProps> = ({
  charts,
  layoutCount,
  isDark,
  onUpdateChartConfig,
  onRemoveChart,
  onOpenIndicatorsForChart,
  instrumentsList,
  subscribe,
  unsubscribe,
  syncCrosshair,
  onOrderBlockAlert,
}) => {
  const [maximizedChartId, setMaximizedChartId] = useState<string | null>(null);
  const [syncTime, setSyncTime] = useState<number | null>(null);

  // Take only the active number of charts specified by layoutCount
  const activeCharts = charts.slice(0, layoutCount);

  // Calculate CSS grid classes based on layoutCount (up to 12)
  const getGridClasses = (count: number): string => {
    switch (count) {
      case 1:
        return 'grid-cols-1 grid-rows-1';
      case 2:
        return 'grid-cols-1 md:grid-cols-2 grid-rows-1';
      case 3:
        return 'grid-cols-1 md:grid-cols-3 grid-rows-1';
      case 4:
        return 'grid-cols-1 md:grid-cols-2 grid-rows-2';
      case 6:
        return 'grid-cols-1 md:grid-cols-3 grid-rows-2';
      case 8:
        return 'grid-cols-2 md:grid-cols-4 grid-rows-2';
      case 9:
        return 'grid-cols-1 md:grid-cols-3 grid-rows-3';
      case 10:
        return 'grid-cols-2 md:grid-cols-5 grid-rows-2';
      case 12:
        return 'grid-cols-2 md:grid-cols-4 grid-rows-3';
      default:
        return 'grid-cols-2 md:grid-cols-4 grid-rows-3';
    }
  };

  const handleCrosshairMove = (time: number | null) => {
    if (syncCrosshair) {
      setSyncTime(time);
    }
  };

  return (
    <main className="flex-1 w-full h-full p-1 bg-black/5 dark:bg-[#131722] overflow-hidden">
      {maximizedChartId ? (
        // Single Maximized View
        <div className="w-full h-full">
          {charts
            .filter((c) => c.id === maximizedChartId)
            .map((chart) => (
              <SingleChart
                key={chart.id}
                config={chart}
                isDark={isDark}
                isMaximized={true}
                onToggleMaximize={() => setMaximizedChartId(null)}
                onRemove={() => {
                  setMaximizedChartId(null);
                  onRemoveChart(chart.id);
                }}
                onUpdateConfig={(newConf) => onUpdateChartConfig(chart.id, newConf)}
                onOpenIndicators={() => onOpenIndicatorsForChart(chart)}
                instrumentsList={instrumentsList}
                subscribe={subscribe}
                unsubscribe={unsubscribe}
                onOrderBlockAlert={onOrderBlockAlert}
              />
            ))}
        </div>
      ) : (
        // Multi-Chart Grid View (Up to 12 charts simultaneously)
        <div className={`w-full h-full grid gap-1 ${getGridClasses(activeCharts.length)}`}>
          {activeCharts.map((chart) => (
            <SingleChart
              key={chart.id}
              config={chart}
              isDark={isDark}
              isMaximized={false}
              onToggleMaximize={() => setMaximizedChartId(chart.id)}
              onRemove={() => onRemoveChart(chart.id)}
              onUpdateConfig={(newConf) => onUpdateChartConfig(chart.id, newConf)}
              onOpenIndicators={() => onOpenIndicatorsForChart(chart)}
              instrumentsList={instrumentsList}
              subscribe={subscribe}
              unsubscribe={unsubscribe}
              syncCrosshairTime={syncTime}
              onCrosshairMove={handleCrosshairMove}
              onOrderBlockAlert={onOrderBlockAlert}
            />
          ))}
        </div>
      )}
    </main>
  );
};

