import React, { useEffect, useRef, useState, useCallback } from 'react';
import {
  createChart,
  IChartApi,
  ISeriesApi,
  IPriceLine,
  LineStyle,
  CandlestickData,
  LineData,
  HistogramData,
  Time
} from 'lightweight-charts';
import {
  Maximize2,
  Minimize2,
  Sliders,
  X,
  Search,
  ChevronDown,
  RefreshCw,
  TrendingUp,
  Activity
} from 'lucide-react';
import {
  ChartConfig,
  Timeframe,
  CandleData,
  TickData,
  InstrumentItem,
  OrderBlock,
  OrderBlockAlert,
  DemandSupplyData
} from '../types/chart';
import {
  getChartThemeOptions,
  CANDLE_COLORS
} from '../utils/chartOptions';
import {
  calculateEMA,
  calculateVWAP,
  calculatePDH_PDL,
  calculateOpeningRange,
  calculateHeikinAshi,
  computeSmcOrderBlocks,
  getTimeCoordinate,
  getISTDateStr,
  calculateSupertrend,
  calculateADX,
  calculateTodRvol,
  countLevelReactions,
  SupertrendPoint,
  AdxResult,
  TodRvolResult
} from '../utils/indicators';
import { soundManager } from '../utils/soundAlerts';

interface SingleChartProps {
  config: ChartConfig;
  isDark: boolean;
  isMaximized: boolean;
  onToggleMaximize: () => void;
  onRemove: () => void;
  onUpdateConfig: (newConfig: Partial<ChartConfig>) => void;
  onOpenIndicators: () => void;
  instrumentsList: InstrumentItem[];
  subscribe: (keys: string | string[], cb: (tick: TickData) => void) => void;
  unsubscribe: (keys: string | string[], cb: (tick: TickData) => void) => void;
  syncCrosshairTime?: number | null;
  onCrosshairMove?: (time: number | null) => void;
  onOrderBlockAlert?: (alert: OrderBlockAlert) => void;
}

const TIMEFRAMES: Timeframe[] = ['1m', '3m', '5m', '15m', '30m', '1h', '1D'];

export const SingleChart: React.FC<SingleChartProps> = ({
  config,
  isDark,
  isMaximized,
  onToggleMaximize,
  onRemove,
  onUpdateConfig,
  onOpenIndicators,
  instrumentsList,
  subscribe,
  unsubscribe,
  syncCrosshairTime,
  onCrosshairMove,
  onOrderBlockAlert,
}) => {
  const containerRef = useRef<HTMLDivElement>(null);
  const chartRef = useRef<IChartApi | null>(null);

  // Series references
  const mainSeriesRef = useRef<ISeriesApi<any> | null>(null);
  const volumeSeriesRef = useRef<ISeriesApi<'Histogram'> | null>(null);
  const ema9SeriesRef = useRef<ISeriesApi<'Line'> | null>(null);
  const ema15SeriesRef = useRef<ISeriesApi<'Line'> | null>(null);
  const vwapSeriesRef = useRef<ISeriesApi<'Line'> | null>(null);

  // Price line references
  const pdhLineRef = useRef<IPriceLine | null>(null);
  const pdlLineRef = useRef<IPriceLine | null>(null);
  const high5mLineRef = useRef<IPriceLine | null>(null);
  const low5mLineRef = useRef<IPriceLine | null>(null);
  const high15mLineRef = useRef<IPriceLine | null>(null);
  const low15mLineRef = useRef<IPriceLine | null>(null);

  // State
  const [candles, setCandles] = useState<CandleData[]>([]);
  const [currentLtp, setCurrentLtp] = useState<number>(0);
  const [priceChange, setPriceChange] = useState<{ diff: number; pct: number }>({ diff: 0, pct: 0 });
  const [flashClass, setFlashClass] = useState<'flash-up' | 'flash-down' | ''>('');
  const [isLoading, setIsLoading] = useState<boolean>(true);
  const [searchOpen, setSearchOpen] = useState<boolean>(false);
  const [searchQuery, setSearchQuery] = useState<string>('');
  const [cursorBar, setCursorBar] = useState<CandleData | null>(null);

  const prevLtpRef = useRef<number>(0);
  const rawCandlesRef = useRef<CandleData[]>([]);
  const serverPdhRef = useRef<number | null>(null);
  const serverPdlRef = useRef<number | null>(null);
  const svgRef = useRef<SVGSVGElement | null>(null);
  const orderBlocksRef = useRef<OrderBlock[]>([]);
  const renderOrderBlocksRef = useRef<() => void>(() => {});
  const notifiedOrderBlocksRef = useRef<Set<string>>(new Set());
  const isFirstLoadRef = useRef<boolean>(true);

  // Pine Script Indicators Refs & States
  const supertrendDataRef = useRef<SupertrendPoint[]>([]);
  const adxDataRef = useRef<AdxResult | null>(null);
  const todRvolDataRef = useRef<TodRvolResult | null>(null);
  const [supertrendInfo, setSupertrendInfo] = useState<{ value: number; direction: 1 | -1 } | null>(null);
  const [adxInfo, setAdxInfo] = useState<{ value: number; color: string } | null>(null);
  const [todRvolInfo, setTodRvolInfo] = useState<{ rvol: number; color: string } | null>(null);
  const demandSupplyRef = useRef<DemandSupplyData | null>(null);

  // Quick Type-to-Search state (TradingView style)
  const [quickSearchOpen, setQuickSearchOpen] = useState<boolean>(false);
  const [quickSearchQuery, setQuickSearchQuery] = useState<string>('');
  const [quickSelectedIndex, setQuickSelectedIndex] = useState<number>(0);
  const isChartFocusedRef = useRef<boolean>(false);
  const quickSearchInputRef = useRef<HTMLInputElement>(null);

  const filteredQuickStocks = React.useMemo(() => {
    if (!quickSearchQuery) return instrumentsList.slice(0, 15);
    const q = quickSearchQuery.toLowerCase();
    return instrumentsList
      .filter(i => i.symbol.toLowerCase().includes(q) || i.name.toLowerCase().includes(q))
      .slice(0, 15);
  }, [instrumentsList, quickSearchQuery]);

  const handleSelectQuickStock = (inst: InstrumentItem) => {
    onUpdateConfig({
      symbol: inst.symbol,
      name: inst.name,
      instrumentKey: inst.instrumentKey,
    });
    setQuickSearchOpen(false);
    setQuickSearchQuery('');
  };

  useEffect(() => {
    if (quickSearchOpen && quickSearchInputRef.current) {
      quickSearchInputRef.current.focus();
    }
  }, [quickSearchOpen]);

  useEffect(() => {
    const handleGlobalKeyDown = (e: KeyboardEvent) => {
      const activeEl = document.activeElement;
      const isInput = activeEl?.tagName === 'INPUT' || activeEl?.tagName === 'TEXTAREA' || activeEl?.tagName === 'SELECT';

      if (isInput && activeEl !== quickSearchInputRef.current) {
        return;
      }

      if (quickSearchOpen) {
        if (e.key === 'Escape') {
          setQuickSearchOpen(false);
          setQuickSearchQuery('');
          e.preventDefault();
          return;
        }
        if (e.key === 'ArrowDown') {
          setQuickSelectedIndex(prev => Math.min(prev + 1, Math.max(0, filteredQuickStocks.length - 1)));
          e.preventDefault();
          return;
        }
        if (e.key === 'ArrowUp') {
          setQuickSelectedIndex(prev => Math.max(0, prev - 1));
          e.preventDefault();
          return;
        }
        if (e.key === 'Enter') {
          if (filteredQuickStocks.length > 0 && filteredQuickStocks[quickSelectedIndex]) {
            handleSelectQuickStock(filteredQuickStocks[quickSelectedIndex]);
          }
          e.preventDefault();
          return;
        }
        return;
      }

      // If user is focused on this chart and starts typing alphanumeric key (A-Z, 0-9)
      if (isChartFocusedRef.current && !e.ctrlKey && !e.altKey && !e.metaKey && e.key.length === 1 && /^[a-zA-Z0-9]$/.test(e.key)) {
        setQuickSearchOpen(true);
        setQuickSearchQuery(e.key.toUpperCase());
        setQuickSelectedIndex(0);
        e.preventDefault();
      }
    };

    window.addEventListener('keydown', handleGlobalKeyDown);
    return () => window.removeEventListener('keydown', handleGlobalKeyDown);
  }, [quickSearchOpen, quickSelectedIndex, filteredQuickStocks]);

  const getTimeframeSeconds = (tf: Timeframe): number => {
    switch (tf) {
      case '1m': return 60;
      case '3m': return 180;
      case '5m': return 300;
      case '15m': return 900;
      case '30m': return 1800;
      case '1h': return 3600;
      case '1D': return 86400;
      default: return 300;
    }
  };

  // 1. Fetch initial historical candles
  const fetchCandles = useCallback(async () => {
    setIsLoading(true);
    isFirstLoadRef.current = true;
    notifiedOrderBlocksRef.current.clear();
    try {
      const res = await fetch(
        `/api/candles?instrumentKey=${encodeURIComponent(config.instrumentKey)}&interval=${config.timeframe}&count=300`
      );
      const data = await res.json();
      if (data.success && Array.isArray(data.candles)) {
        rawCandlesRef.current = data.candles;
        serverPdhRef.current = data.pdh || null;
        serverPdlRef.current = data.pdl || null;
        demandSupplyRef.current = data.demandSupply || null;
        setCandles(data.candles);
        if (data.candles.length > 0) {
          const last = data.candles[data.candles.length - 1];
          const first = data.candles[0];
          setCurrentLtp(last.close);
          prevLtpRef.current = last.close;
          const diff = last.close - first.open;
          const pct = first.open > 0 ? (diff / first.open) * 100 : 0;
          setPriceChange({ diff, pct });
        }
      }
    } catch (err) {
      console.error('Failed to fetch candles for', config.instrumentKey, err);
    } finally {
      setIsLoading(false);
    }
  }, [config.instrumentKey, config.timeframe]);

  useEffect(() => {
    fetchCandles();
  }, [fetchCandles]);

  // 2. Initialize Lightweight Chart with IST Time Formatting (09:15 to 15:30)
  useEffect(() => {
    if (!containerRef.current) return;

    const chart = createChart(containerRef.current, {
      ...getChartThemeOptions(isDark),
      width: containerRef.current.clientWidth,
      height: containerRef.current.clientHeight,
      // Format timestamps in Indian Standard Time (IST: 09:15 - 15:30)
      localization: {
        timeFormatter: (timestamp: number) => {
          const date = new Date(timestamp * 1000);
          return date.toLocaleTimeString('en-IN', {
            timeZone: 'Asia/Kolkata',
            hour12: false,
            hour: '2-digit',
            minute: '2-digit',
          });
        },
        dateFormat: 'dd MMM yyyy',
      },
      timeScale: {
        timeVisible: true,
        secondsVisible: false,
        tickMarkFormatter: (time: number) => {
          const date = new Date(time * 1000);
          return date.toLocaleTimeString('en-IN', {
            timeZone: 'Asia/Kolkata',
            hour12: false,
            hour: '2-digit',
            minute: '2-digit',
          });
        },
      },
    });
    chartRef.current = chart;

    // Volume Series
    const volumeSeries = chart.addHistogramSeries({
      priceFormat: { type: 'volume' },
      priceScaleId: 'volume',
    });
    chart.priceScale('volume').applyOptions({
      scaleMargins: { top: 0.85, bottom: 0 },
    });
    volumeSeriesRef.current = volumeSeries;

    // Main Series
    let mainSeries: ISeriesApi<any>;
    if (config.chartType === 'line') {
      mainSeries = chart.addLineSeries({
        color: '#2962ff',
        lineWidth: 2,
        priceLineVisible: true,
        lastValueVisible: true,
      });
    } else if (config.chartType === 'area') {
      mainSeries = chart.addAreaSeries({
        topColor: 'rgba(41, 98, 255, 0.4)',
        bottomColor: 'rgba(41, 98, 255, 0.02)',
        lineColor: '#2962ff',
        lineWidth: 2,
        priceLineVisible: true,
        lastValueVisible: true,
      });
    } else {
      mainSeries = chart.addCandlestickSeries({
        upColor: CANDLE_COLORS.upColor,
        downColor: CANDLE_COLORS.downColor,
        borderUpColor: CANDLE_COLORS.borderUpColor,
        borderDownColor: CANDLE_COLORS.borderDownColor,
        wickUpColor: CANDLE_COLORS.wickUpColor,
        wickDownColor: CANDLE_COLORS.wickDownColor,
        priceLineVisible: true,
        lastValueVisible: true,
      });
    }
    mainSeriesRef.current = mainSeries;

    // EMA 9 Line (CLEAN: No horizontal line, no price scale label)
    const ema9Series = chart.addLineSeries({
      color: config.indicators.ema9.color,
      lineWidth: config.indicators.ema9.lineWidth,
      priceLineVisible: false,  // REMOVE HORIZONTAL LINE
      lastValueVisible: false,   // REMOVE LABEL BADGE
      title: '',                 // REMOVE NAME
      visible: config.indicators.ema9.enabled,
    });
    ema9SeriesRef.current = ema9Series;

    // EMA 15 Line (CLEAN: No horizontal line, no price scale label)
    const ema15Series = chart.addLineSeries({
      color: config.indicators.ema15.color,
      lineWidth: config.indicators.ema15.lineWidth,
      priceLineVisible: false,  // REMOVE HORIZONTAL LINE
      lastValueVisible: false,   // REMOVE LABEL BADGE
      title: '',                 // REMOVE NAME
      visible: config.indicators.ema15.enabled,
    });
    ema15SeriesRef.current = ema15Series;

    // VWAP Line (CLEAN: No horizontal line, no price scale label)
    const vwapSeries = chart.addLineSeries({
      color: config.indicators.vwap.color,
      lineWidth: config.indicators.vwap.lineWidth,
      priceLineVisible: false,  // REMOVE HORIZONTAL LINE
      lastValueVisible: false,   // REMOVE LABEL BADGE
      title: '',                 // REMOVE NAME
      visible: config.indicators.vwap.enabled,
    });
    vwapSeriesRef.current = vwapSeries;

    // Crosshair move listener
    chart.subscribeCrosshairMove((param) => {
      if (!param || !param.time || !param.seriesData) {
        setCursorBar(null);
        if (onCrosshairMove) onCrosshairMove(null);
        return;
      }
      const barData = param.seriesData.get(mainSeries) as any;
      if (barData) {
        setCursorBar({
          time: Number(param.time),
          open: barData.open ?? barData.value,
          high: barData.high ?? barData.value,
          low: barData.low ?? barData.value,
          close: barData.close ?? barData.value,
        });
      }
      if (onCrosshairMove) {
        onCrosshairMove(Number(param.time));
      }
    });

    // Subscribe to chart zoom, pan, and scroll to keep Order Block boxes aligned
    chart.timeScale().subscribeVisibleLogicalRangeChange(() => {
      renderOrderBlocksRef.current();
    });
    chart.timeScale().subscribeVisibleTimeRangeChange(() => {
      renderOrderBlocksRef.current();
    });

    const resizeObserver = new ResizeObserver((entries) => {
      if (!entries || entries.length === 0 || !containerRef.current) return;
      const { width, height } = entries[0].contentRect;
      chart.applyOptions({ width, height });
      renderOrderBlocksRef.current();
    });
    resizeObserver.observe(containerRef.current);

    return () => {
      resizeObserver.disconnect();
      chart.remove();
      chartRef.current = null;
    };
  }, [config.chartType]);

  // 3. Theme changes
  useEffect(() => {
    if (!chartRef.current) return;
    chartRef.current.applyOptions(getChartThemeOptions(isDark));
  }, [isDark]);

  // Render SMC Order Blocks (+OB / -OB rectangles) and Session Break Lines on SVG overlay
  const renderOrderBlocks = useCallback(() => {
    const svg = svgRef.current;
    const chart = chartRef.current;
    const candleSeries = mainSeriesRef.current;
    const container = containerRef.current;
    if (!svg || !chart || !candleSeries || !container) return;

    if (
      !config.indicators.orderBlocks?.enabled &&
      !config.indicators.sessionBreak?.enabled &&
      !config.indicators.supertrend?.enabled &&
      !(config.indicators.adx?.enabled && config.indicators.adx?.showLabel) &&
      !config.indicators.demandSupply?.enabled
    ) {
      svg.innerHTML = '';
      return;
    }

    const effectiveCandles = rawCandlesRef.current;
    if (!effectiveCandles || effectiveCandles.length === 0) {
      svg.innerHTML = '';
      return;
    }

    const containerWidth = container.clientWidth || 700;
    const containerHeight = container.clientHeight || 450;
    const rightScaleWidth = 55;

    let svgContent = '';

    // 1. Session Break Lines (Yesterday vs Today - Strictly Continuous Solid Line)
    if (config.indicators.sessionBreak?.enabled) {
      const sbColor = config.indicators.sessionBreak.color || '#3b82f6';
      const sbWidth = config.indicators.sessionBreak.lineWidth || 2;

      for (let i = 1; i < effectiveCandles.length; i++) {
        const dPrev = getISTDateStr(effectiveCandles[i - 1].time);
        const dCurr = getISTDateStr(effectiveCandles[i].time);
        if (dPrev !== dCurr) {
          const sessionStartTime = effectiveCandles[i].time;
          const sbX = getTimeCoordinate(chart.timeScale(), sessionStartTime, effectiveCandles);
          if (sbX !== null && sbX >= 0 && sbX <= containerWidth) {
            const dateLabel = new Date(sessionStartTime * 1000).toLocaleDateString('en-GB', {
              timeZone: 'Asia/Kolkata',
              day: '2-digit',
              month: 'short'
            });
            // Strictly solid continuous vertical line (NO dots, NO dashes)
            svgContent += `
              <g key="session_break_${sessionStartTime}">
                <line
                  x1="${Math.round(sbX)}"
                  y1="0"
                  x2="${Math.round(sbX)}"
                  y2="${containerHeight}"
                  stroke="${sbColor}"
                  stroke-width="${sbWidth}"
                  stroke-dasharray="none"
                  opacity="0.85"
                />
                <rect
                  x="${Math.max(2, Math.round(sbX) - 24)}"
                  y="4"
                  width="48"
                  height="15"
                  rx="3"
                  fill="${sbColor}"
                  opacity="0.9"
                />
                <text
                  x="${Math.round(sbX)}"
                  y="15"
                  fill="#ffffff"
                  font-size="9"
                  font-family="monospace"
                  font-weight="700"
                  text-anchor="middle"
                >${dateLabel}</text>
              </g>
            `;
          }
        }
      }
    }

    // 2. SMC Order Block Zones (+OB / -OB)
    if (config.indicators.orderBlocks?.enabled) {
      const obs = orderBlocksRef.current || [];
      for (const ob of obs) {
        const isBull = ob.type === 'bullish';

        let rCoord = getTimeCoordinate(chart.timeScale(), ob.startTime, effectiveCandles);
        if (rCoord === null) rCoord = 0;

        let isMitigated = ob.mitigated;
        let endTime = ob.endTime;

        let iCoord: number | null = null;
        if (isMitigated && endTime) {
          iCoord = getTimeCoordinate(chart.timeScale(), endTime, effectiveCandles);
        }
        if (iCoord === null) {
          iCoord = containerWidth - rightScaleWidth;
        }

        const yHigh = candleSeries.priceToCoordinate(ob.high);
        const yLow = candleSeries.priceToCoordinate(ob.low);
        if (yHigh === null || yLow === null) continue;

        const x = Math.min(rCoord, iCoord);
        const y = Math.min(yHigh, yLow);
        const rawWidth = Math.abs(iCoord - rCoord);
        const rawHeight = Math.abs(yLow - yHigh);

        const width = Math.max(8, rawWidth);
        const height = Math.max(3, rawHeight);

        if (x + width < 0 || x > containerWidth) continue;
        if (y + height < 0 || y > containerHeight) continue;

        const maxWidth = Math.max(8, (containerWidth - rightScaleWidth) - x);
        const clampedWidth = Math.min(width, maxWidth);

        const bullColor = config.indicators.orderBlocks.bullishColor || '#10b981';
        const bearColor = config.indicators.orderBlocks.bearishColor || '#f43f5e';

        const fill = isBull ? 'rgba(16, 185, 129, 0.20)' : 'rgba(244, 63, 94, 0.20)';
        const stroke = isBull ? bullColor : bearColor;
        const textFill = isBull ? bullColor : bearColor;
        const dash = isMitigated ? '3 2' : 'none';
        const label = isBull ? '+OB' : '-OB';
        const textX = Math.max(4, Math.round(x) + 4);
        const textY = Math.round(y) + Math.max(9, Math.min(12, height / 2 + 3));

        svgContent += `
          <g key="${ob.id}">
            <rect
              x="${Math.round(x)}"
              y="${Math.round(y)}"
              width="${Math.round(clampedWidth)}"
              height="${Math.round(height)}"
              fill="${fill}"
              stroke="${stroke}"
              stroke-width="1.2"
              stroke-dasharray="${dash}"
              rx="2"
            />
            <text
              x="${textX}"
              y="${textY}"
              fill="${textFill}"
              font-size="9"
              font-family="monospace"
              font-weight="700"
              opacity="0.85"
            >${label}</text>
          </g>
        `;
      }
    }

    // 3. Supertrend Line (Pine Script ta.supertrend - Smooth colored line bands)
    if (config.indicators.supertrend?.enabled && supertrendDataRef.current.length > 0) {
      const stPoints = supertrendDataRef.current;
      const upColor = config.indicators.supertrend.upColor || '#10b981';
      const downColor = config.indicators.supertrend.downColor || '#f43f5e';
      const stWidth = config.indicators.supertrend.lineWidth || 2;

      let currentDir: 1 | -1 = stPoints[0].direction;
      let currentSeg: { x: number; y: number }[] = [];

      const flushSegment = (dir: 1 | -1, pts: { x: number; y: number }[]) => {
        if (pts.length < 2) return;
        const col = dir === -1 ? upColor : downColor;
        let d = `M ${Math.round(pts[0].x)} ${Math.round(pts[0].y)}`;
        for (let j = 1; j < pts.length; j++) {
          d += ` L ${Math.round(pts[j].x)} ${Math.round(pts[j].y)}`;
        }
        svgContent += `
          <path
            d="${d}"
            stroke="${col}"
            stroke-width="${stWidth}"
            fill="none"
            stroke-linecap="round"
            stroke-linejoin="round"
            opacity="0.95"
          />
        `;
      };

      for (let i = 0; i < stPoints.length; i++) {
        const pt = stPoints[i];
        const ptX = getTimeCoordinate(chart.timeScale(), pt.time, effectiveCandles);
        const ptY = candleSeries.priceToCoordinate(pt.value);

        if (pt.direction !== currentDir) {
          flushSegment(currentDir, currentSeg);
          currentDir = pt.direction;
          currentSeg = [];
        }

        if (ptX !== null && ptY !== null && !isNaN(ptX) && !isNaN(ptY)) {
          currentSeg.push({ x: ptX, y: ptY });
        }
      }
      flushSegment(currentDir, currentSeg);
    }

    // 4. ADX Live Candle Label (Pine Script ta.dmi live badge with pointer)
    if (config.indicators.adx?.enabled && (config.indicators.adx.showLabel ?? true) && adxDataRef.current) {
      const lastCandle = effectiveCandles[effectiveCandles.length - 1];
      if (lastCandle) {
        const candX = getTimeCoordinate(chart.timeScale(), lastCandle.time, effectiveCandles);
        const candY = candleSeries.priceToCoordinate(lastCandle.high);

        if (candX !== null && candY !== null && candX >= 0 && candX <= containerWidth) {
          const adxVal = adxDataRef.current.latestAdx.toFixed(1);
          const adxColor = adxDataRef.current.latestColor;
          const bWidth = 66;
          const bHeight = 18;
          const bX = Math.round(candX - bWidth / 2);
          const bY = Math.max(4, Math.round(candY - bHeight - 7));
          const pointerTipY = Math.round(candY - 1);
          const pointerBaseY = Math.round(bY + bHeight);

          svgContent += `
            <g key="adx_live_badge">
              <polygon
                points="${candX - 4},${pointerBaseY} ${candX + 4},${pointerBaseY} ${candX},${pointerTipY}"
                fill="${adxColor}"
              />
              <rect
                x="${bX}"
                y="${bY}"
                width="${bWidth}"
                height="${bHeight}"
                rx="4"
                fill="${adxColor}"
                stroke="rgba(255,255,255,0.25)"
                stroke-width="1"
              />
              <text
                x="${candX}"
                y="${bY + 13}"
                fill="#ffffff"
                font-size="10"
                font-family="monospace"
                font-weight="800"
                text-anchor="middle"
              >ADX: ${adxVal}</text>
            </g>
          `;
        }
      }
    }

    // 5. Demand & Supply Levels (1,2,3 Day | 1,2,3 Week | 1,2,3 Month) - Pine Script DEMAND/SUPPLY
    if (config.indicators.demandSupply?.enabled && demandSupplyRef.current) {
      const ds = demandSupplyRef.current;
      const dsCfg = config.indicators.demandSupply;
      const tol = dsCfg.tolerancePerc || 0.15;
      const showTouches = dsCfg.showTouches ?? true;

      // Find session start time for today in IST
      const lastCandle = effectiveCandles[effectiveCandles.length - 1];
      const todayStr = getISTDateStr(lastCandle.time);
      const todayCandles = effectiveCandles.filter(c => getISTDateStr(c.time) === todayStr);
      const sessionStartCandle = todayCandles.length > 0 ? todayCandles[0] : effectiveCandles[0];
      const sessionStartX = getTimeCoordinate(chart.timeScale(), sessionStartCandle.time, effectiveCandles);
      const startX = sessionStartX !== null && sessionStartX >= 0 ? sessionStartX : 0;
      const endX = containerWidth - rightScaleWidth;

      const levelsToDraw: { key: 'd1'|'d2'|'d3'|'w1'|'w2'|'w3'|'m1'|'m2'|'m3'; label: string }[] = [
        { key: 'd1', label: '1D' },
        { key: 'd2', label: '2D' },
        { key: 'd3', label: '3D' },
        { key: 'w1', label: '1W' },
        { key: 'w2', label: '2W' },
        { key: 'w3', label: '3W' },
        { key: 'm1', label: '1M' },
        { key: 'm2', label: '2M' },
        { key: 'm3', label: '3M' },
      ];

      for (const item of levelsToDraw) {
        const lvlCfg = dsCfg[item.key];
        const lvlData = ds[item.key];
        if (!lvlCfg || !lvlCfg.enabled || !lvlData) continue;

        const stroke = lvlCfg.color || '#f23645';
        const width = lvlCfg.lineWidth || 1;
        const dash = lvlCfg.lineStyle === 'Dashed' ? '6 4' : lvlCfg.lineStyle === 'Dotted' ? '2 3' : 'none';

        // Draw High (Resistance)
        if (lvlData.high && lvlData.high > 0) {
          const y = candleSeries.priceToCoordinate(lvlData.high);
          if (y !== null && y >= 0 && y <= containerHeight) {
            const rx = countLevelReactions(effectiveCandles, lvlData.high, true, tol);
            const badge = showTouches ? (rx > 0 ? `🔥 ${rx} | ` : '0 | ') : '';
            const labelText = `${badge}${item.label} High`;
            const badgeW = labelText.length * 6.5 + 8;
            const badgeX = Math.max(4, Math.min(containerWidth - rightScaleWidth - badgeW - 4, startX + 6));

            svgContent += `
              <g key="${item.key}_high">
                <line
                  x1="${Math.round(startX)}"
                  y1="${Math.round(y)}"
                  x2="${Math.round(endX)}"
                  y2="${Math.round(y)}"
                  stroke="${stroke}"
                  stroke-width="${width}"
                  stroke-dasharray="${dash}"
                  opacity="0.85"
                />
                <rect
                  x="${Math.round(badgeX)}"
                  y="${Math.round(y - 8)}"
                  width="${Math.round(badgeW)}"
                  height="14"
                  rx="3"
                  fill="${isDark ? '#1e222d' : '#ffffff'}"
                  stroke="${stroke}"
                  stroke-width="1"
                  opacity="0.95"
                />
                <text
                  x="${Math.round(badgeX + badgeW / 2)}"
                  y="${Math.round(y + 2.5)}"
                  fill="${stroke}"
                  font-size="9"
                  font-family="monospace"
                  font-weight="700"
                  text-anchor="middle"
                >${labelText}</text>
              </g>
            `;
          }
        }

        // Draw Low (Support)
        if (lvlData.low && lvlData.low > 0) {
          const y = candleSeries.priceToCoordinate(lvlData.low);
          if (y !== null && y >= 0 && y <= containerHeight) {
            const rx = countLevelReactions(effectiveCandles, lvlData.low, false, tol);
            const badge = showTouches ? (rx > 0 ? `🔥 ${rx} | ` : '0 | ') : '';
            const labelText = `${badge}${item.label} Low`;
            const badgeW = labelText.length * 6.5 + 8;
            const badgeX = Math.max(4, Math.min(containerWidth - rightScaleWidth - badgeW - 4, startX + 6));

            svgContent += `
              <g key="${item.key}_low">
                <line
                  x1="${Math.round(startX)}"
                  y1="${Math.round(y)}"
                  x2="${Math.round(endX)}"
                  y2="${Math.round(y)}"
                  stroke="${stroke}"
                  stroke-width="${width}"
                  stroke-dasharray="${dash}"
                  opacity="0.85"
                />
                <rect
                  x="${Math.round(badgeX)}"
                  y="${Math.round(y - 8)}"
                  width="${Math.round(badgeW)}"
                  height="14"
                  rx="3"
                  fill="${isDark ? '#1e222d' : '#ffffff'}"
                  stroke="${stroke}"
                  stroke-width="1"
                  opacity="0.95"
                />
                <text
                  x="${Math.round(badgeX + badgeW / 2)}"
                  y="${Math.round(y + 2.5)}"
                  fill="${stroke}"
                  font-size="9"
                  font-family="monospace"
                  font-weight="700"
                  text-anchor="middle"
                >${labelText}</text>
              </g>
            `;
          }
        }
      }
    }

    svg.innerHTML = svgContent;
  }, [config.indicators.orderBlocks, config.indicators.sessionBreak, config.indicators.supertrend, config.indicators.adx, config.indicators.demandSupply]);

  useEffect(() => {
    renderOrderBlocksRef.current = renderOrderBlocks;
  }, [renderOrderBlocks]);

  useEffect(() => {
    renderOrderBlocks();
  }, [config.indicators.orderBlocks, config.indicators.sessionBreak, config.indicators.supertrend, config.indicators.adx, config.indicators.demandSupply, renderOrderBlocks]);

  // 4. Update Indicators & Reference Lines (FULL CLEAN - No labels/names blocking chart)
  const updateIndicatorsAndLines = useCallback(() => {
    if (!mainSeriesRef.current || rawCandlesRef.current.length === 0) return;

    const dataCandles = rawCandlesRef.current;
    const isHeikin = config.chartType === 'heikin';
    const displayCandles = isHeikin ? calculateHeikinAshi(dataCandles) : dataCandles;

    // Set Main Series Data
    if (config.chartType === 'line' || config.chartType === 'area') {
      const lineData: LineData[] = displayCandles.map(c => ({
        time: c.time as Time,
        value: c.close,
      }));
      mainSeriesRef.current.setData(lineData);
    } else {
      const candleData: CandlestickData[] = displayCandles.map(c => ({
        time: c.time as Time,
        open: c.open,
        high: c.high,
        low: c.low,
        close: c.close,
      }));
      mainSeriesRef.current.setData(candleData);
    }

    // Set Volume Data with Time-of-Day RVOL coloring (Pine Script TOD RVOL)
    if (volumeSeriesRef.current) {
      if (config.indicators.todRvol?.enabled) {
        const rvolRes = calculateTodRvol(
          dataCandles,
          config.indicators.todRvol.lookbackDays || 20,
          config.indicators.todRvol.highThreshold || 2.0
        );
        todRvolDataRef.current = rvolRes;
        setTodRvolInfo({ rvol: rvolRes.latestRvol, color: rvolRes.latestColor });

        const volData: HistogramData[] = dataCandles.map((c, idx) => {
          const rPoint = rvolRes.values[idx];
          const barColor = rPoint ? rPoint.color : (c.close >= c.open ? 'rgba(8, 153, 129, 0.3)' : 'rgba(242, 54, 69, 0.3)');
          return {
            time: c.time as Time,
            value: c.volume || 1000,
            color: barColor,
          };
        });
        volumeSeriesRef.current.setData(volData);
      } else {
        todRvolDataRef.current = null;
        setTodRvolInfo(null);
        const volData: HistogramData[] = dataCandles.map(c => ({
          time: c.time as Time,
          value: c.volume || 1000,
          color: c.close >= c.open ? 'rgba(8, 153, 129, 0.25)' : 'rgba(242, 54, 69, 0.25)',
        }));
        volumeSeriesRef.current.setData(volData);
      }
    }

    // 1. EMA 9 (Curve only, no horizontal line, no label)
    if (ema9SeriesRef.current) {
      ema9SeriesRef.current.applyOptions({
        visible: config.indicators.ema9.enabled,
        color: config.indicators.ema9.color,
        lineWidth: config.indicators.ema9.lineWidth,
        priceLineVisible: false,
        lastValueVisible: false,
        title: '',
      });
      if (config.indicators.ema9.enabled) {
        const ema9Data = calculateEMA(dataCandles, 9);
        ema9SeriesRef.current.setData(ema9Data.map(d => ({ time: d.time as Time, value: d.value })));
      }
    }

    // 2. EMA 15 (Curve only, no horizontal line, no label)
    if (ema15SeriesRef.current) {
      ema15SeriesRef.current.applyOptions({
        visible: config.indicators.ema15.enabled,
        color: config.indicators.ema15.color,
        lineWidth: config.indicators.ema15.lineWidth,
        priceLineVisible: false,
        lastValueVisible: false,
        title: '',
      });
      if (config.indicators.ema15.enabled) {
        const ema15Data = calculateEMA(dataCandles, 15);
        ema15SeriesRef.current.setData(ema15Data.map(d => ({ time: d.time as Time, value: d.value })));
      }
    }

    // 3. VWAP (Curve only, no horizontal line, no label)
    if (vwapSeriesRef.current) {
      vwapSeriesRef.current.applyOptions({
        visible: config.indicators.vwap.enabled,
        color: config.indicators.vwap.color,
        lineWidth: config.indicators.vwap.lineWidth,
        priceLineVisible: false,
        lastValueVisible: false,
        title: '',
      });
      if (config.indicators.vwap.enabled) {
        const vwapData = calculateVWAP(dataCandles);
        vwapSeriesRef.current.setData(vwapData.map(d => ({ time: d.time as Time, value: d.value })));
      }
    }

    // 4. Clean old price lines before re-adding
    if (pdhLineRef.current) {
      try { mainSeriesRef.current.removePriceLine(pdhLineRef.current); } catch (e) {}
      pdhLineRef.current = null;
    }
    if (pdlLineRef.current) {
      try { mainSeriesRef.current.removePriceLine(pdlLineRef.current); } catch (e) {}
      pdlLineRef.current = null;
    }
    if (high5mLineRef.current) {
      try { mainSeriesRef.current.removePriceLine(high5mLineRef.current); } catch (e) {}
      high5mLineRef.current = null;
    }
    if (low5mLineRef.current) {
      try { mainSeriesRef.current.removePriceLine(low5mLineRef.current); } catch (e) {}
      low5mLineRef.current = null;
    }
    if (high15mLineRef.current) {
      try { mainSeriesRef.current.removePriceLine(high15mLineRef.current); } catch (e) {}
      high15mLineRef.current = null;
    }
    if (low15mLineRef.current) {
      try { mainSeriesRef.current.removePriceLine(low15mLineRef.current); } catch (e) {}
      low15mLineRef.current = null;
    }

    // Calculate PDH & PDL (using server value or calculated from previous IST session)
    const calcPD = calculatePDH_PDL(dataCandles);
    const pdhVal = serverPdhRef.current || calcPD.pdh;
    const pdlVal = serverPdlRef.current || calcPD.pdl;

    // Previous Day High (Clean horizontal dashed line, NO text blocking chart)
    if (config.indicators.pdh.enabled && pdhVal !== null && pdhVal > 0) {
      pdhLineRef.current = mainSeriesRef.current.createPriceLine({
        price: pdhVal,
        color: config.indicators.pdh.color,
        lineWidth: config.indicators.pdh.lineWidth,
        lineStyle: LineStyle.Dashed,
        axisLabelVisible: false, // FULL CLEAN
        title: '',               // FULL CLEAN
      });
    }

    // Previous Day Low (Clean horizontal dashed line, NO text blocking chart)
    if (config.indicators.pdl.enabled && pdlVal !== null && pdlVal > 0) {
      pdlLineRef.current = mainSeriesRef.current.createPriceLine({
        price: pdlVal,
        color: config.indicators.pdl.color,
        lineWidth: config.indicators.pdl.lineWidth,
        lineStyle: LineStyle.Dashed,
        axisLabelVisible: false, // FULL CLEAN
        title: '',               // FULL CLEAN
      });
    }

    // 5-Min Opening Range High / Low (Clean reference lines)
    if (config.indicators.highLow5m.enabled) {
      const or5m = calculateOpeningRange(dataCandles, 5);
      if (or5m.high !== null) {
        high5mLineRef.current = mainSeriesRef.current.createPriceLine({
          price: or5m.high,
          color: config.indicators.highLow5m.highColor,
          lineWidth: config.indicators.highLow5m.lineWidth,
          lineStyle: LineStyle.Dotted,
          axisLabelVisible: false, // FULL CLEAN
          title: '',               // FULL CLEAN
        });
      }
      if (or5m.low !== null) {
        low5mLineRef.current = mainSeriesRef.current.createPriceLine({
          price: or5m.low,
          color: config.indicators.highLow5m.lowColor,
          lineWidth: config.indicators.highLow5m.lineWidth,
          lineStyle: LineStyle.Dotted,
          axisLabelVisible: false, // FULL CLEAN
          title: '',               // FULL CLEAN
        });
      }
    }

    // 15-Min Opening Range High / Low (Clean reference lines)
    if (config.indicators.highLow15m.enabled) {
      const or15m = calculateOpeningRange(dataCandles, 15);
      if (or15m.high !== null) {
        high15mLineRef.current = mainSeriesRef.current.createPriceLine({
          price: or15m.high,
          color: config.indicators.highLow15m.highColor,
          lineWidth: config.indicators.highLow15m.lineWidth,
          lineStyle: LineStyle.Dotted,
          axisLabelVisible: false, // FULL CLEAN
          title: '',               // FULL CLEAN
        });
      }
      if (or15m.low !== null) {
        low15mLineRef.current = mainSeriesRef.current.createPriceLine({
          price: or15m.low,
          color: config.indicators.highLow15m.lowColor,
          lineWidth: config.indicators.highLow15m.lineWidth,
          lineStyle: LineStyle.Dotted,
          axisLabelVisible: false, // FULL CLEAN
          title: '',               // FULL CLEAN
        });
      }
    }

    // 5. SMC Order Blocks (+OB Bullish Demand & -OB Bearish Supply)
    if (config.indicators.orderBlocks?.enabled) {
      const computedObs = computeSmcOrderBlocks(dataCandles);
      orderBlocksRef.current = computedObs;

      if (isFirstLoadRef.current) {
        // Record existing historical order blocks so we don't alert old ones
        computedObs.forEach(ob => notifiedOrderBlocksRef.current.add(ob.id));
        isFirstLoadRef.current = false;
      } else {
        // Live updates: alert on newly formed order block across any of the charts
        for (const ob of computedObs) {
          if (!notifiedOrderBlocksRef.current.has(ob.id)) {
            notifiedOrderBlocksRef.current.add(ob.id);
            soundManager.playOrderBlockAlert(ob.type);
            if (onOrderBlockAlert) {
              const now = new Date();
              const timeStr = now.toLocaleTimeString('en-IN', {
                timeZone: 'Asia/Kolkata',
                hour: '2-digit',
                minute: '2-digit',
                second: '2-digit'
              });
              onOrderBlockAlert({
                id: ob.id,
                chartId: config.id,
                symbol: config.symbol,
                type: ob.type,
                high: ob.high,
                low: ob.low,
                time: ob.startTime,
                formattedTime: timeStr,
              });
            }
          }
        }
      }
    } else {
      orderBlocksRef.current = [];
    }

    // 6. Supertrend (Pine Script ta.supertrend)
    if (config.indicators.supertrend?.enabled) {
      const stPoints = calculateSupertrend(
        dataCandles,
        config.indicators.supertrend.factor || 3.0,
        config.indicators.supertrend.atrPeriod || 10
      );
      supertrendDataRef.current = stPoints;
      const lastSt = stPoints[stPoints.length - 1];
      if (lastSt) {
        setSupertrendInfo({ value: lastSt.value, direction: lastSt.direction });
      }
    } else {
      supertrendDataRef.current = [];
      setSupertrendInfo(null);
    }

    // 7. ADX (Pine Script ta.dmi)
    if (config.indicators.adx?.enabled) {
      const adxRes = calculateADX(
        dataCandles,
        config.indicators.adx.period || 14,
        config.indicators.adx.period || 14
      );
      adxDataRef.current = adxRes;
      setAdxInfo({ value: adxRes.latestAdx, color: adxRes.latestColor });
    } else {
      adxDataRef.current = null;
      setAdxInfo(null);
    }

    renderOrderBlocks();
  }, [config.chartType, config.indicators, renderOrderBlocks, config.id, config.symbol, onOrderBlockAlert]);

  useEffect(() => {
    updateIndicatorsAndLines();
  }, [candles, updateIndicatorsAndLines]);

  // 5. Live Tick-by-Tick Handler
  const handleTick = useCallback((tick: TickData) => {
    if (!mainSeriesRef.current || rawCandlesRef.current.length === 0) return;

    const price = tick.ltp;
    const tickTime = Math.floor(tick.ltt / 1000);
    const intervalSec = getTimeframeSeconds(config.timeframe);

    if (price > prevLtpRef.current) {
      setFlashClass('flash-up');
    } else if (price < prevLtpRef.current) {
      setFlashClass('flash-down');
    }
    prevLtpRef.current = price;
    setCurrentLtp(price);

    const firstCandle = rawCandlesRef.current[0];
    if (firstCandle) {
      const diff = price - firstCandle.open;
      const pct = firstCandle.open > 0 ? (diff / firstCandle.open) * 100 : 0;
      setPriceChange({ diff, pct });
    }

    const lastCandle = { ...rawCandlesRef.current[rawCandlesRef.current.length - 1] };
    const candleStart = Math.floor(tickTime / intervalSec) * intervalSec;

    if (lastCandle.time === candleStart) {
      lastCandle.close = price;
      lastCandle.high = Math.max(lastCandle.high, price);
      lastCandle.low = Math.min(lastCandle.low, price);
      lastCandle.volume = (lastCandle.volume || 0) + (tick.volume || 1);

      rawCandlesRef.current[rawCandlesRef.current.length - 1] = lastCandle;

      if (config.chartType === 'line' || config.chartType === 'area') {
        mainSeriesRef.current.update({ time: lastCandle.time as Time, value: lastCandle.close });
      } else {
        mainSeriesRef.current.update({
          time: lastCandle.time as Time,
          open: lastCandle.open,
          high: lastCandle.high,
          low: lastCandle.low,
          close: lastCandle.close,
        });
      }

      if (volumeSeriesRef.current) {
        let vColor = lastCandle.close >= lastCandle.open ? 'rgba(8, 153, 129, 0.25)' : 'rgba(242, 54, 69, 0.25)';
        if (config.indicators.todRvol?.enabled && todRvolInfo) {
          vColor = todRvolInfo.color;
        }
        volumeSeriesRef.current.update({
          time: lastCandle.time as Time,
          value: lastCandle.volume,
          color: vColor,
        });
      }
      renderOrderBlocks();
    } else if (candleStart > lastCandle.time) {
      const newCandle: CandleData = {
        time: candleStart,
        open: price,
        high: price,
        low: price,
        close: price,
        volume: tick.volume || 1,
      };
      rawCandlesRef.current.push(newCandle);

      if (config.chartType === 'line' || config.chartType === 'area') {
        mainSeriesRef.current.update({ time: newCandle.time as Time, value: newCandle.close });
      } else {
        mainSeriesRef.current.update({
          time: newCandle.time as Time,
          open: newCandle.open,
          high: newCandle.high,
          low: newCandle.low,
          close: newCandle.close,
        });
      }

      updateIndicatorsAndLines();
    }
  }, [config.chartType, config.timeframe, updateIndicatorsAndLines, renderOrderBlocks]);

  useEffect(() => {
    subscribe(config.instrumentKey, handleTick);
    return () => {
      unsubscribe(config.instrumentKey, handleTick);
    };
  }, [config.instrumentKey, subscribe, unsubscribe, handleTick]);

  useEffect(() => {
    if (flashClass) {
      const timer = setTimeout(() => setFlashClass(''), 600);
      return () => clearTimeout(timer);
    }
  }, [flashClass]);

  // Filter instruments (includes all 501 Nifty 500 stocks + indices)
  const filteredInstruments = searchQuery
    ? instrumentsList.filter(
        i =>
          i.symbol.toLowerCase().includes(searchQuery.toLowerCase()) ||
          i.name.toLowerCase().includes(searchQuery.toLowerCase()) ||
          i.instrumentKey.toLowerCase().includes(searchQuery.toLowerCase())
      )
    : instrumentsList;

  const displayBar = cursorBar || (rawCandlesRef.current.length > 0 ? rawCandlesRef.current[rawCandlesRef.current.length - 1] : null);

  return (
    <div
      tabIndex={0}
      onFocus={() => { isChartFocusedRef.current = true; }}
      onBlur={(e) => {
        if (e.currentTarget.contains(e.relatedTarget as Node)) return;
        isChartFocusedRef.current = false;
      }}
      onClick={() => { isChartFocusedRef.current = true; }}
      onMouseEnter={() => { isChartFocusedRef.current = true; }}
      onMouseLeave={() => {
        if (!quickSearchOpen) isChartFocusedRef.current = false;
      }}
      className={`relative w-full h-full flex flex-col border overflow-hidden rounded-[2px] transition-all select-none outline-none focus:ring-1 focus:ring-[#2962ff]/50 ${
        isDark ? 'bg-[#131722] border-[#2a2e39]' : 'bg-[#ffffff] border-[#e0e3eb]'
      }`}
    >
      {/* Chart Top Toolbar */}
      <div
        className={`h-8 px-2 border-b flex items-center justify-between text-xs shrink-0 z-10 ${
          isDark ? 'bg-[#1e222d] border-[#2a2e39] text-[#d1d4dc]' : 'bg-[#f8f9fd] border-[#e0e3eb] text-[#131722]'
        }`}
      >
        <div className="flex items-center gap-1.5">
          {/* Symbol Selector Button (Nifty 500 + Indices) */}
          <div className="relative">
            <button
              onClick={() => setSearchOpen(!searchOpen)}
              className={`flex items-center gap-1 px-1.5 py-0.5 rounded font-bold transition-colors ${
                isDark ? 'hover:bg-[#2a2e39] text-white' : 'hover:bg-gray-200 text-black'
              }`}
            >
              <span>{config.symbol}</span>
              <ChevronDown className="w-3 h-3 opacity-60" />
            </button>

            {/* Symbol Search Modal across 500+ stocks */}
            {searchOpen && (
              <div
                className={`absolute left-0 top-7 w-72 rounded-lg shadow-2xl border p-2 z-50 ${
                  isDark ? 'bg-[#1e222d] border-[#2a2e39]' : 'bg-[#ffffff] border-[#e0e3eb]'
                }`}
              >
                <div className="relative mb-2">
                  <input
                    type="text"
                    value={searchQuery}
                    onChange={(e) => setSearchQuery(e.target.value)}
                    placeholder="Search Nifty 500 stocks or indices..."
                    autoFocus
                    className={`w-full px-2.5 py-1.5 pl-7 text-xs rounded border outline-none ${
                      isDark ? 'bg-[#131722] border-[#2a2e39] text-white' : 'bg-gray-50 border-gray-300'
                    }`}
                  />
                  <Search className="w-3.5 h-3.5 absolute left-2 top-2 opacity-50" />
                </div>

                <div className="max-h-56 overflow-y-auto space-y-1">
                  {filteredInstruments.slice(0, 80).map((inst) => (
                    <button
                      key={inst.instrumentKey}
                      onClick={() => {
                        onUpdateConfig({
                          instrumentKey: inst.instrumentKey,
                          symbol: inst.symbol,
                          name: inst.name,
                        });
                        setSearchOpen(false);
                      }}
                      className={`w-full text-left px-2 py-1.5 rounded text-xs flex items-center justify-between transition-colors ${
                        inst.instrumentKey === config.instrumentKey
                          ? 'bg-[#2962ff] text-white'
                          : isDark
                          ? 'hover:bg-[#2a2e39] text-gray-300'
                          : 'hover:bg-gray-100 text-gray-800'
                      }`}
                    >
                      <div>
                        <div className="font-bold flex items-center gap-1.5">
                          <span>{inst.symbol}</span>
                          {inst.segment === 'NSE_INDEX' && (
                            <span className="text-[9px] px-1 rounded bg-blue-500/20 text-blue-400">INDEX</span>
                          )}
                        </div>
                        <div className="text-[10px] opacity-60 truncate w-40">{inst.name}</div>
                      </div>
                      <span className="text-[10px] font-mono opacity-80">
                        ₹{inst.basePrice.toLocaleString('en-IN')}
                      </span>
                    </button>
                  ))}
                </div>
              </div>
            )}
          </div>

          {/* Timeframe Dropdown */}
          <select
            value={config.timeframe}
            onChange={(e) => onUpdateConfig({ timeframe: e.target.value as Timeframe })}
            className={`text-[11px] font-semibold px-1 py-0.5 rounded border outline-none cursor-pointer ${
              isDark ? 'bg-[#131722] border-[#2a2e39] text-gray-200' : 'bg-white border-gray-300 text-gray-800'
            }`}
          >
            {TIMEFRAMES.map((tf) => (
              <option key={tf} value={tf}>
                {tf}
              </option>
            ))}
          </select>

          {/* Live Price with Uptick / Downtick Flash */}
          <div
            className={`flex items-center gap-1.5 px-2 py-0.5 rounded font-mono font-bold text-xs transition-all ${flashClass}`}
          >
            <span className={priceChange.diff >= 0 ? 'text-[#089981]' : 'text-[#f23645]'}>
              ₹{currentLtp.toLocaleString('en-IN', { minimumFractionDigits: 2 })}
            </span>
            <span
              className={`text-[10px] ${
                priceChange.diff >= 0 ? 'text-[#089981]' : 'text-[#f23645]'
              }`}
            >
              {priceChange.diff >= 0 ? '+' : ''}
              {priceChange.pct.toFixed(2)}%
            </span>
          </div>
        </div>

        {/* Right Actions */}
        <div className="flex items-center gap-1">
          <button
            onClick={fetchCandles}
            title="Refresh Historical Candles"
            className="p-1 rounded hover:bg-current/10 opacity-70 hover:opacity-100"
          >
            <RefreshCw className="w-3.5 h-3.5" />
          </button>

          <button
            onClick={onOpenIndicators}
            title="Indicator Settings"
            className="p-1 rounded hover:bg-current/10 opacity-70 hover:opacity-100"
          >
            <Sliders className="w-3.5 h-3.5" />
          </button>

          <button
            onClick={onToggleMaximize}
            title={isMaximized ? 'Minimize to Multi-Grid' : 'Maximize Chart to Fullscreen'}
            className="p-1 rounded hover:bg-current/10 opacity-70 hover:opacity-100"
          >
            {isMaximized ? <Minimize2 className="w-3.5 h-3.5" /> : <Maximize2 className="w-3.5 h-3.5" />}
          </button>

          <button
            onClick={onRemove}
            title="Remove Chart"
            className="p-1 rounded hover:bg-red-500/20 text-red-400 hover:text-red-500"
          >
            <X className="w-3.5 h-3.5" />
          </button>
        </div>
      </div>

      {/* OHLC Bar Legend (TradingView style - Clean info under cursor) */}
      <div
        className={`h-5 px-2 text-[10px] font-mono flex items-center gap-3 shrink-0 border-b border-opacity-10 border-current ${
          isDark ? 'bg-[#131722] text-gray-400' : 'bg-white text-gray-600'
        }`}
      >
        {displayBar ? (
          <>
            <div>
              <span className="opacity-50">O</span>{' '}
              <span className="text-current font-semibold">{displayBar.open?.toFixed(2)}</span>
            </div>
            <div>
              <span className="opacity-50">H</span>{' '}
              <span className="text-[#089981] font-semibold">{displayBar.high?.toFixed(2)}</span>
            </div>
            <div>
              <span className="opacity-50">L</span>{' '}
              <span className="text-[#f23645] font-semibold">{displayBar.low?.toFixed(2)}</span>
            </div>
            <div>
              <span className="opacity-50">C</span>{' '}
              <span
                className={`font-semibold ${
                  (displayBar.close ?? 0) >= (displayBar.open ?? 0) ? 'text-[#089981]' : 'text-[#f23645]'
                }`}
              >
                {displayBar.close?.toFixed(2)}
              </span>
            </div>
            {config.indicators.ema9.enabled && (
              <div className="text-blue-500 hidden sm:inline">EMA9</div>
            )}
            {config.indicators.ema15.enabled && (
              <div className="text-orange-500 hidden sm:inline">EMA15</div>
            )}
            {config.indicators.vwap.enabled && (
              <div className="text-pink-500 hidden sm:inline">VWAP</div>
            )}
            {config.indicators.orderBlocks?.enabled && (
              <div className="text-emerald-400 font-semibold hidden sm:inline">OB</div>
            )}
            {config.indicators.sessionBreak?.enabled && (
              <div className="text-blue-400 font-semibold hidden sm:inline">SB</div>
            )}
            {config.indicators.supertrend?.enabled && (
              <div
                className="font-bold hidden sm:inline"
                style={{
                  color: supertrendInfo
                    ? (supertrendInfo.direction === -1
                        ? (config.indicators.supertrend.upColor || '#10b981')
                        : (config.indicators.supertrend.downColor || '#f43f5e'))
                    : '#10b981'
                }}
              >
                ST: {supertrendInfo ? supertrendInfo.value.toFixed(2) : '--'}
              </div>
            )}
            {config.indicators.adx?.enabled && (
              <div
                className="font-bold hidden sm:inline"
                style={{ color: adxInfo ? adxInfo.color : '#26a69a' }}
              >
                ADX: {adxInfo ? adxInfo.value.toFixed(1) : '--'}
              </div>
            )}
            {config.indicators.todRvol?.enabled && (
              <div
                className="font-bold hidden sm:inline"
                style={{ color: todRvolInfo ? todRvolInfo.color : '#758696' }}
              >
                RVOL: {todRvolInfo ? `${todRvolInfo.rvol.toFixed(2)}x` : '--'}
              </div>
            )}
            {config.indicators.demandSupply?.enabled && (
              <div className="text-purple-400 font-semibold hidden sm:inline">D/S (1,2,3)</div>
            )}
          </>
        ) : (
          <span>Loading Session Feed (09:15 - 15:30 IST)...</span>
        )}
      </div>

      {/* Chart Canvas Container */}
      <div className="relative flex-1 w-full h-full min-h-0">
        <div ref={containerRef} className="w-full h-full" />
        <svg
          ref={svgRef}
          className="absolute inset-0 w-full h-full pointer-events-none z-10 overflow-hidden"
        />

        {/* RVOL Live Table Cell Badge in Lower Volume Pane (Matching TradingView Pine Script) */}
        {config.indicators.todRvol?.enabled && todRvolInfo && (
          <div
            className="absolute right-14 bottom-6 z-20 px-2 py-0.5 rounded text-[10px] font-mono font-bold text-white shadow-md border border-white/20 select-none pointer-events-none"
            style={{ backgroundColor: todRvolInfo.color }}
          >
            RVOL {todRvolInfo.rvol.toFixed(2)}x
          </div>
        )}

        {/* Quick Symbol Type-to-Search Popup (TradingView style - Type anywhere on chart) */}
        {quickSearchOpen && (
          <div
            className="absolute inset-0 z-50 flex items-start justify-center pt-8 bg-black/40 backdrop-blur-[2px]"
            onClick={(e) => {
              if (e.target === e.currentTarget) {
                setQuickSearchOpen(false);
              }
            }}
          >
            <div
              className={`w-80 max-w-[92%] rounded-xl shadow-2xl border flex flex-col overflow-hidden animate-in fade-in zoom-in-95 duration-150 ${
                isDark
                  ? 'bg-[#1e222d] border-[#2962ff]/60 text-white shadow-blue-900/40'
                  : 'bg-white border-[#2962ff]/60 text-black shadow-xl'
              }`}
            >
              {/* Search Header */}
              <div className="p-2.5 border-b border-current/10 flex items-center gap-2 bg-[#2962ff]/10">
                <Search className="w-4 h-4 text-[#2962ff] shrink-0" />
                <input
                  ref={quickSearchInputRef}
                  type="text"
                  value={quickSearchQuery}
                  onChange={(e) => {
                    setQuickSearchQuery(e.target.value.toUpperCase());
                    setQuickSelectedIndex(0);
                  }}
                  placeholder="Type stock name or symbol..."
                  className="w-full bg-transparent text-sm font-bold tracking-wider outline-none"
                />
                <button
                  onClick={() => setQuickSearchOpen(false)}
                  className="p-1 rounded hover:bg-current/10 opacity-60 hover:opacity-100"
                >
                  <X className="w-3.5 h-3.5" />
                </button>
              </div>

              {/* Suggestions List */}
              <div className="max-h-56 overflow-y-auto divide-y divide-current/5">
                {filteredQuickStocks.length > 0 ? (
                  filteredQuickStocks.map((inst, idx) => (
                    <button
                      key={inst.instrumentKey}
                      onClick={() => handleSelectQuickStock(inst)}
                      className={`w-full px-3 py-2 text-left flex items-center justify-between text-xs transition-colors ${
                        idx === quickSelectedIndex
                          ? 'bg-[#2962ff] text-white font-bold'
                          : isDark
                          ? 'hover:bg-[#2a2e39] text-gray-200'
                          : 'hover:bg-gray-100 text-gray-800'
                      }`}
                    >
                      <div>
                        <div className="font-bold flex items-center gap-1.5">
                          <span>{inst.symbol}</span>
                          <span className="text-[10px] opacity-70 px-1 py-0.2 rounded bg-black/20">
                            {inst.instrumentKey.startsWith('NSE_INDEX') ? 'INDEX' : 'NSE'}
                          </span>
                        </div>
                        <div className="text-[10px] opacity-70 truncate max-w-[180px]">
                          {inst.name}
                        </div>
                      </div>
                      {idx === quickSelectedIndex && (
                        <span className="text-[10px] opacity-80 font-mono">↵ Enter</span>
                      )}
                    </button>
                  ))
                ) : (
                  <div className="p-4 text-center text-xs opacity-50">
                    No matching stocks found for "{quickSearchQuery}"
                  </div>
                )}
              </div>

              <div className="px-3 py-1.5 bg-black/10 text-[10px] opacity-50 flex items-center justify-between border-t border-current/10">
                <span>↑↓ Navigate</span>
                <span>↵ Select</span>
                <span>ESC Close</span>
              </div>
            </div>
          </div>
        )}
        {isLoading && (
          <div className="absolute inset-0 flex items-center justify-center bg-black/20 backdrop-blur-[1px]">
            <Activity className="w-6 h-6 animate-spin text-[#2962ff]" />
          </div>
        )}
      </div>
    </div>
  );
};
