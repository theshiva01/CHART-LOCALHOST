import { CandleData, OrderBlock, DemandSupplyData } from '../types/chart';

export interface IndicatorValue {
  time: number;
  value: number;
}

/**
 * Convert Unix timestamp (seconds) to IST Date string 'YYYY-MM-DD'
 */
export function getISTDateStr(unixSec: number): string {
  return new Date(unixSec * 1000).toLocaleDateString('en-CA', { timeZone: 'Asia/Kolkata' });
}

/**
 * Get hour and minute in IST for a timestamp
 */
export function getISTTime(unixSec: number): { hours: number; minutes: number } {
  const parts = new Intl.DateTimeFormat('en-IN', {
    timeZone: 'Asia/Kolkata',
    hour: 'numeric',
    minute: 'numeric',
    hour12: false,
  }).formatToParts(new Date(unixSec * 1000));
  const h = Number(parts.find(p => p.type === 'hour')?.value || 0);
  const m = Number(parts.find(p => p.type === 'minute')?.value || 0);
  return { hours: h, minutes: m };
}

/**
 * Exponential Moving Average (EMA)
 */
export function calculateEMA(candles: CandleData[], period: number): IndicatorValue[] {
  if (!candles || candles.length < period) return [];

  const k = 2 / (period + 1);
  const result: IndicatorValue[] = [];

  let sum = 0;
  for (let i = 0; i < period; i++) {
    sum += candles[i].close;
  }
  let prevEma = sum / period;
  result.push({ time: candles[period - 1].time, value: Number(prevEma.toFixed(2)) });

  for (let i = period; i < candles.length; i++) {
    const currentClose = candles[i].close;
    const currentEma = (currentClose - prevEma) * k + prevEma;
    result.push({ time: candles[i].time, value: Number(currentEma.toFixed(2)) });
    prevEma = currentEma;
  }

  return result;
}

/**
 * Volume Weighted Average Price (VWAP)
 * Resets each trading day at 09:15 AM IST
 */
export function calculateVWAP(candles: CandleData[]): IndicatorValue[] {
  if (!candles || candles.length === 0) return [];

  const result: IndicatorValue[] = [];
  let cumVolume = 0;
  let cumTypicalVolume = 0;
  let lastDayStr = '';

  for (let i = 0; i < candles.length; i++) {
    const c = candles[i];
    const dayStr = getISTDateStr(c.time);

    // Reset VWAP at start of a new calendar day in IST
    if (dayStr !== lastDayStr) {
      cumVolume = 0;
      cumTypicalVolume = 0;
      lastDayStr = dayStr;
    }

    const typicalPrice = (c.high + c.low + c.close) / 3;
    const vol = c.volume && c.volume > 0 ? c.volume : 1000;

    cumVolume += vol;
    cumTypicalVolume += typicalPrice * vol;

    const vwap = cumVolume > 0 ? cumTypicalVolume / cumVolume : typicalPrice;
    result.push({ time: c.time, value: Number(vwap.toFixed(2)) });
  }

  return result;
}

/**
 * Calculate Previous Day High and Low (PDH / PDL) based on IST trading days
 */
export function calculatePDH_PDL(candles: CandleData[]): { pdh: number | null; pdl: number | null } {
  if (!candles || candles.length === 0) return { pdh: null, pdl: null };

  const daysMap = new Map<string, CandleData[]>();
  for (const c of candles) {
    const dStr = getISTDateStr(c.time);
    if (!daysMap.has(dStr)) {
      daysMap.set(dStr, []);
    }
    daysMap.get(dStr)!.push(c);
  }

  const sortedDays = Array.from(daysMap.keys()).sort();
  if (sortedDays.length < 2) {
    // If only one day is in history, estimate from first half of day
    const half = Math.floor(candles.length / 2);
    let max = -Infinity;
    let min = Infinity;
    for (let i = 0; i < Math.max(1, half); i++) {
      if (candles[i].high > max) max = candles[i].high;
      if (candles[i].low < min) min = candles[i].low;
    }
    return {
      pdh: max !== -Infinity ? Number(max.toFixed(2)) : null,
      pdl: min !== Infinity ? Number(min.toFixed(2)) : null,
    };
  }

  // Previous trading day in IST
  const prevDayKey = sortedDays[sortedDays.length - 2];
  const prevDayCandles = daysMap.get(prevDayKey) || [];

  let pdh = -Infinity;
  let pdl = Infinity;
  for (const c of prevDayCandles) {
    if (c.high > pdh) pdh = c.high;
    if (c.low < pdl) pdl = c.low;
  }

  return {
    pdh: pdh !== -Infinity ? Number(pdh.toFixed(2)) : null,
    pdl: pdl !== Infinity ? Number(pdl.toFixed(2)) : null,
  };
}

/**
 * Calculate Opening Range Breakout Levels (5-min ORH/ORL and 15-min ORH/ORL)
 * Calculated strictly from today's first 5 mins (09:15-09:20 IST) and 15 mins (09:15-09:30 IST)
 */
export function calculateOpeningRange(
  candles: CandleData[],
  targetMinutes: 5 | 15
): { high: number | null; low: number | null } {
  if (!candles || candles.length === 0) return { high: null, low: null };

  // Get current IST date string from latest candle
  const lastCandle = candles[candles.length - 1];
  const currentDayStr = getISTDateStr(lastCandle.time);

  // Filter only today's session candles
  const todayCandles = candles.filter(c => getISTDateStr(c.time) === currentDayStr);
  if (todayCandles.length === 0) return { high: null, low: null };

  // First candle of today's session (should be 09:15 IST)
  const firstCandleTime = todayCandles[0].time;
  const cutoffTime = firstCandleTime + targetMinutes * 60;

  let orHigh = -Infinity;
  let orLow = Infinity;
  let found = false;

  for (const c of todayCandles) {
    if (c.time < cutoffTime) {
      if (c.high > orHigh) orHigh = c.high;
      if (c.low < orLow) orLow = c.low;
      found = true;
    } else {
      break;
    }
  }

  if (!found || orHigh === -Infinity || orLow === Infinity) {
    return { high: null, low: null };
  }

  return {
    high: Number(orHigh.toFixed(2)),
    low: Number(orLow.toFixed(2)),
  };
}

/**
 * Convert standard candles to Heikin-Ashi candles
 */
export function calculateHeikinAshi(candles: CandleData[]): CandleData[] {
  if (!candles || candles.length === 0) return [];

  const haCandles: CandleData[] = [];
  let prevHaOpen = candles[0].open;
  let prevHaClose = candles[0].close;

  for (let i = 0; i < candles.length; i++) {
    const c = candles[i];
    const haClose = (c.open + c.high + c.low + c.close) / 4;
    const haOpen = i === 0 ? (c.open + c.close) / 2 : (prevHaOpen + prevHaClose) / 2;
    const haHigh = Math.max(c.high, haOpen, haClose);
    const haLow = Math.min(c.low, haOpen, haClose);

    haCandles.push({
      time: c.time,
      open: Number(haOpen.toFixed(2)),
      high: Number(haHigh.toFixed(2)),
      low: Number(haLow.toFixed(2)),
      close: Number(haClose.toFixed(2)),
      volume: c.volume,
    });

    prevHaOpen = haOpen;
    prevHaClose = haClose;
  }

  return haCandles;
}

/**
 * SMC Order Blocks (+OB Bullish Demand & -OB Bearish Supply)
 * Direct logic from OrderBlockTerminal / hoverChart.js
 */
export function computeSmcOrderBlocks(candles: CandleData[]): OrderBlock[] {
  if (!Array.isArray(candles) || candles.length < 5) return [];

  const total = candles.length;
  let sumRange = 0;
  for (let r = 0; r < total; r++) {
    sumRange += (Number(candles[r].high) - Number(candles[r].low));
  }
  const avgRange = (sumRange / total) || 1;
  const result: OrderBlock[] = [];

  for (let n = 2; n < total - 1; n++) {
    const prev = candles[n - 1];
    const curr = candles[n];
    const next = candles[n + 1];

    // Bullish Order Block (+OB Demand)
    const isBearishCandle = Number(prev.close) <= Number(prev.open);
    const impulseUp = Math.max(Number(curr.close), next ? Number(next.close) : Number(curr.close)) - Number(prev.low);
    const brokeHigh = Number(curr.close) > Number(prev.high) || (next && Number(next.close) > Number(prev.high));

    if (isBearishCandle && brokeHigh && impulseUp >= avgRange * 1.15) {
      let endTime = candles[total - 1].time;
      let isMitigated = false;
      for (let i = n + 1; i < total; i++) {
        if (Number(candles[i].low) < Number(prev.low)) {
          endTime = candles[i].time;
          isMitigated = true;
          break;
        }
      }
      result.push({
        id: `ob_bull_${prev.time}_${n}`,
        type: 'bullish',
        startTime: prev.time,
        endTime: endTime,
        high: Number(prev.high),
        low: Number(prev.low),
        z: Number(((Number(prev.high) + Number(prev.low)) / 2).toFixed(2)),
        mitigated: isMitigated
      });
    }

    // Bearish Order Block (-OB Supply)
    const isBullishCandle = Number(prev.close) >= Number(prev.open);
    const impulseDown = Number(prev.high) - Math.min(Number(curr.close), next ? Number(next.close) : Number(curr.close));
    const brokeLow = Number(curr.close) < Number(prev.low) || (next && Number(next.close) < Number(prev.low));

    if (isBullishCandle && brokeLow && impulseDown >= avgRange * 1.15) {
      let endTime = candles[total - 1].time;
      let isMitigated = false;
      for (let i = n + 1; i < total; i++) {
        if (Number(candles[i].high) > Number(prev.high)) {
          endTime = candles[i].time;
          isMitigated = true;
          break;
        }
      }
      result.push({
        id: `ob_bear_${prev.time}_${n}`,
        type: 'bearish',
        startTime: prev.time,
        endTime: endTime,
        high: Number(prev.high),
        low: Number(prev.low),
        z: Number(((Number(prev.high) + Number(prev.low)) / 2).toFixed(2)),
        mitigated: isMitigated
      });
    }
  }

  // Deduplicate nearby same-direction order blocks (within 900 seconds / 15 mins)
  const deduped: OrderBlock[] = [];
  for (const ob of result) {
    if (!deduped.some(t => t.type === ob.type && Math.abs(t.startTime - ob.startTime) < 900)) {
      deduped.push(ob);
    }
  }

  return deduped;
}

/**
 * Coordinate resolver for chart timeScale
 */
export function getTimeCoordinate(timeScale: any, targetTime: number, candles: CandleData[]): number | null {
  if (!timeScale || targetTime == null) return null;

  try {
    const direct = timeScale.timeToCoordinate(targetTime);
    if (direct !== null && !isNaN(direct)) return direct;
  } catch (_) {}

  if (Array.isArray(candles) && candles.length > 0) {
    if (targetTime <= candles[0].time) {
      try {
        const c0 = timeScale.timeToCoordinate(candles[0].time);
        if (c0 !== null) return c0;
      } catch (_) {}
      return 0;
    }
    if (targetTime >= candles[candles.length - 1].time) {
      try {
        const clast = timeScale.timeToCoordinate(candles[candles.length - 1].time);
        if (clast !== null) return clast;
      } catch (_) {}
      return null;
    }
    let closest = candles[0];
    let minDiff = Math.abs(candles[0].time - targetTime);
    for (let i = 1; i < candles.length; i++) {
      const diff = Math.abs(candles[i].time - targetTime);
      if (diff < minDiff) {
        minDiff = diff;
        closest = candles[i];
      }
    }
    try {
      return timeScale.timeToCoordinate(closest.time);
    } catch (_) {}
  }
  return null;
}

export interface SupertrendPoint {
  time: number;
  value: number;
  direction: 1 | -1; // 1 = Bearish (Red), -1 = Bullish (Green)
}

/**
 * Supertrend Indicator matching TradingView ta.supertrend(factor, atrPeriod)
 */
export function calculateSupertrend(
  candles: CandleData[],
  factor = 3.0,
  period = 10
): SupertrendPoint[] {
  if (!candles || candles.length < period) return [];

  // 1. True Range (TR)
  const tr: number[] = [];
  for (let i = 0; i < candles.length; i++) {
    if (i === 0) {
      tr.push(candles[0].high - candles[0].low);
      continue;
    }
    const hl = candles[i].high - candles[i].low;
    const hc = Math.abs(candles[i].high - candles[i - 1].close);
    const lc = Math.abs(candles[i].low - candles[i - 1].close);
    tr.push(Math.max(hl, hc, lc));
  }

  // 2. Wilder's ATR (RMA)
  const atr: number[] = [];
  let sum = 0;
  for (let i = 0; i < period; i++) sum += tr[i] || 0;
  let prevAtr = sum / period;
  atr[period - 1] = prevAtr;

  for (let i = period; i < candles.length; i++) {
    prevAtr = (prevAtr * (period - 1) + tr[i]) / period;
    atr[i] = prevAtr;
  }

  // 3. Supertrend Bands & Trailing Stops
  const result: SupertrendPoint[] = [];
  let prevUpper = 0;
  let prevLower = 0;
  let prevDir: 1 | -1 = 1;

  for (let i = 0; i < candles.length; i++) {
    if (i < period - 1) continue;

    const c = candles[i];
    const prevC = candles[i - 1];
    const curAtr = atr[i] || 1;
    const hl2 = (c.high + c.low) / 2;
    const basicUpper = hl2 + factor * curAtr;
    const basicLower = hl2 - factor * curAtr;

    let upper = basicUpper;
    let lower = basicLower;

    if (i > period - 1) {
      lower = (basicLower > prevLower || prevC.close < prevLower) ? basicLower : prevLower;
      upper = (basicUpper < prevUpper || prevC.close > prevUpper) ? basicUpper : prevUpper;
    }

    let dir: 1 | -1 = prevDir;
    if (i === period - 1) {
      dir = c.close > upper ? -1 : 1;
    } else {
      if (prevDir === 1 && c.close > prevUpper) dir = -1;
      else if (prevDir === -1 && c.close < prevLower) dir = 1;
    }

    const val = dir === -1 ? lower : upper;
    result.push({
      time: c.time,
      value: Number(val.toFixed(2)),
      direction: dir,
    });

    prevUpper = upper;
    prevLower = lower;
    prevDir = dir;
  }

  return result;
}

export interface AdxResult {
  values: { time: number; adx: number | null }[];
  latestAdx: number;
  latestColor: string;
}

/**
 * Average Directional Index (ADX) matching TradingView ta.dmi(diLen, adxLen)
 */
export function calculateADX(
  candles: CandleData[],
  diLen = 14,
  adxLen = 14
): AdxResult {
  if (!candles || candles.length < diLen + adxLen) {
    return { values: [], latestAdx: 25.0, latestColor: '#26a69a' };
  }

  const len = candles.length;
  const tr: number[] = [];
  const plusDM: number[] = [];
  const minusDM: number[] = [];

  for (let i = 0; i < len; i++) {
    if (i === 0) {
      tr.push(candles[0].high - candles[0].low);
      plusDM.push(0);
      minusDM.push(0);
      continue;
    }
    const c = candles[i];
    const prev = candles[i - 1];
    const hl = c.high - c.low;
    const hc = Math.abs(c.high - prev.close);
    const lc = Math.abs(c.low - prev.close);
    tr.push(Math.max(hl, hc, lc));

    const upMove = c.high - prev.high;
    const downMove = prev.low - c.low;

    if (upMove > downMove && upMove > 0) plusDM.push(upMove);
    else plusDM.push(0);

    if (downMove > upMove && downMove > 0) minusDM.push(downMove);
    else minusDM.push(0);
  }

  // Wilder's Smoothing (RMA)
  function rma(arr: number[], period: number): number[] {
    const out: number[] = [];
    let sum = 0;
    for (let i = 0; i < period; i++) sum += arr[i] || 0;
    let prev = sum / period;
    out[period - 1] = prev;
    for (let i = period; i < arr.length; i++) {
      prev = (prev * (period - 1) + arr[i]) / period;
      out[i] = prev;
    }
    return out;
  }

  const smoothTR = rma(tr, diLen);
  const smoothPlusDM = rma(plusDM, diLen);
  const smoothMinusDM = rma(minusDM, diLen);

  const dx: number[] = [];
  for (let i = 0; i < len; i++) {
    if (i < diLen - 1) {
      dx.push(0);
      continue;
    }
    const str = smoothTR[i] || 1;
    const pDI = (smoothPlusDM[i] / str) * 100;
    const mDI = (smoothMinusDM[i] / str) * 100;
    const diSum = pDI + mDI;
    const diDiff = Math.abs(pDI - mDI);
    dx.push(diSum === 0 ? 0 : (diDiff / diSum) * 100);
  }

  const adx = rma(dx.slice(diLen - 1), adxLen);
  const result: { time: number; adx: number | null }[] = [];
  for (let i = 0; i < len; i++) {
    const adxIdx = i - (diLen - 1);
    const val = (adxIdx >= adxLen - 1 && adx[adxIdx]) ? Number(adx[adxIdx].toFixed(1)) : null;
    result.push({ time: candles[i].time, adx: val });
  }

  const latest = result[result.length - 1]?.adx ?? 25.0;
  // Tiered colors from Pine Script: <20 Red (#e91e63), 20-30 Teal (#26a69a), 30+ Dark Green (#006400)
  const latestColor = latest < 20.0 ? '#e91e63' : latest <= 30.0 ? '#26a69a' : '#089981';

  return { values: result, latestAdx: latest, latestColor };
}

export interface TodRvolPoint {
  time: number;
  rvol: number;
  color: string;
}

export interface TodRvolResult {
  values: TodRvolPoint[];
  latestRvol: number;
  latestColor: string;
}

/**
 * Time-Of-Day Relative Volume (TOD RVOL) matching Pine Script Slot mode
 */
export function calculateTodRvol(
  candles: CandleData[],
  lookback = 20,
  highThreshold = 2.0
): TodRvolResult {
  if (!candles || candles.length === 0) {
    return { values: [], latestRvol: 1.0, latestColor: '#26a69a' };
  }

  const dayMap = new Map<string, CandleData[]>();
  for (const c of candles) {
    const dStr = getISTDateStr(c.time);
    if (!dayMap.has(dStr)) dayMap.set(dStr, []);
    dayMap.get(dStr)!.push(c);
  }

  const days = Array.from(dayMap.keys()).sort();
  const priorDays = days.slice(0, -1);

  // Time slot (minutes since 00:00 IST) -> array of historical volumes
  const slotTotals = new Map<number, number[]>();
  for (const d of priorDays.slice(-lookback)) {
    const dayCandles = dayMap.get(d) || [];
    for (const c of dayCandles) {
      const t = getISTTime(c.time);
      const slot = t.hours * 60 + t.minutes;
      if (!slotTotals.has(slot)) slotTotals.set(slot, []);
      slotTotals.get(slot)!.push(c.volume || 1000);
    }
  }

  const result: TodRvolPoint[] = [];
  for (const c of candles) {
    const t = getISTTime(c.time);
    const slot = t.hours * 60 + t.minutes;
    const hist = slotTotals.get(slot) || [];
    const avg = hist.length > 0 ? (hist.reduce((a, b) => a + b, 0) / hist.length) : (c.volume || 1000);
    const curVol = c.volume || 1000;
    const rvol = avg > 0 ? Number((curVol / avg).toFixed(2)) : 1.0;

    // Pine Script tiered colors:
    // RVOL >= hiThr (2.0): Lime Green (#00e676)
    // 1.0 <= RVOL < 2.0: Teal (#26a69a)
    // RVOL < 1.0: Muted Gray (#758696)
    let color = '#758696';
    if (rvol >= highThreshold) {
      color = '#00e676';
    } else if (rvol >= 1.0) {
      color = '#26a69a';
    }

    result.push({
      time: c.time,
      rvol,
      color,
    });
  }

  const lastPoint = result[result.length - 1];
  return {
    values: result,
    latestRvol: lastPoint ? lastPoint.rvol : 1.0,
    latestColor: lastPoint ? lastPoint.color : '#26a69a',
  };
}

/**
 * Count historical touches and reactions on a level within a tolerance percentage
 * Matching Pine Script: calc_reactions(float lvl, bool is_high_res)
 */
export function countLevelReactions(
  candles: CandleData[],
  level: number,
  isHighRes: boolean,
  tolerancePerc: number = 0.15
): number {
  if (!candles || candles.length === 0 || !level || level <= 0) return 0;
  const zone = level * (tolerancePerc / 100);
  let count = 0;
  for (let i = 0; i < candles.length; i++) {
    const c = candles[i];
    if (isHighRes) {
      if (c.high >= level - zone && c.high <= level + zone && c.close < c.high) {
        count++;
      }
    } else {
      if (c.low <= level + zone && c.low >= level - zone && c.close > c.low) {
        count++;
      }
    }
  }
  return count;
}



