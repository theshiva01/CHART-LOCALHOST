import React, { useState, useRef, useEffect } from 'react';
import { LayoutGrid, Check } from 'lucide-react';
import { LayoutPreset } from '../types/chart';

interface LayoutSelectorProps {
  currentCount: LayoutPreset;
  onSelectLayout: (count: LayoutPreset) => void;
  isDark: boolean;
}

interface LayoutOption {
  count: LayoutPreset;
  label: string;
  gridClass: string;
  rows: number;
  cols: number;
  description: string;
}

const LAYOUT_OPTIONS: LayoutOption[] = [
  { count: 1, label: '1 Chart', gridClass: 'grid-cols-1 grid-rows-1', rows: 1, cols: 1, description: 'Single Full Chart' },
  { count: 2, label: '2 Charts (Split)', gridClass: 'grid-cols-2 grid-rows-1', rows: 1, cols: 2, description: '2 Horizontal Charts' },
  { count: 3, label: '3 Charts', gridClass: 'grid-cols-3 grid-rows-1', rows: 1, cols: 3, description: '3 Column Grid' },
  { count: 4, label: '4 Charts (2x2)', gridClass: 'grid-cols-2 grid-rows-2', rows: 2, cols: 2, description: 'Standard 4 Quadrants' },
  { count: 6, label: '6 Charts (3x2)', gridClass: 'grid-cols-3 grid-rows-2', rows: 2, cols: 3, description: '6 Multi-Chart Grid' },
  { count: 8, label: '8 Charts (4x2)', gridClass: 'grid-cols-4 grid-rows-2', rows: 2, cols: 4, description: '8 Charts Pro View' },
  { count: 9, label: '9 Charts (3x3)', gridClass: 'grid-cols-3 grid-rows-3', rows: 3, cols: 3, description: '9 Chart Matrix' },
  { count: 10, label: '10 Charts (5x2)', gridClass: 'grid-cols-5 grid-rows-2', rows: 2, cols: 5, description: '10 Instrument Monitor' },
  { count: 12, label: '12 Charts (4x3)', gridClass: 'grid-cols-4 grid-rows-3', rows: 3, cols: 4, description: 'Maximum 12 Multi-Screen Pro' },
];

export const LayoutSelector: React.FC<LayoutSelectorProps> = ({
  currentCount,
  onSelectLayout,
  isDark,
}) => {
  const [isOpen, setIsOpen] = useState(false);
  const dropdownRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    const handleClickOutside = (event: MouseEvent) => {
      if (dropdownRef.current && !dropdownRef.current.contains(event.target as Node)) {
        setIsOpen(false);
      }
    };
    document.addEventListener('mousedown', handleClickOutside);
    return () => document.removeEventListener('mousedown', handleClickOutside);
  }, []);

  return (
    <div className="relative" ref={dropdownRef}>
      <button
        onClick={() => setIsOpen(!isOpen)}
        title="Select Multi-Chart Layout (Up to 12 Charts)"
        className={`flex items-center gap-1.5 px-2.5 py-1.5 rounded text-xs font-medium border transition-colors ${
          isOpen
            ? isDark
              ? 'bg-[#2a2e39] border-[#2962ff] text-[#2962ff]'
              : 'bg-[#e0e3eb] border-[#2962ff] text-[#2962ff]'
            : isDark
            ? 'bg-[#1e222d] border-[#2a2e39] text-[#d1d4dc] hover:bg-[#2a2e39]'
            : 'bg-[#ffffff] border-[#e0e3eb] text-[#131722] hover:bg-[#f0f3fa]'
        }`}
      >
        <LayoutGrid className="w-3.5 h-3.5" />
        <span className="font-semibold">{currentCount} {currentCount === 1 ? 'Chart' : 'Charts'}</span>
      </button>

      {isOpen && (
        <div
          className={`absolute left-0 mt-1.5 w-72 rounded-lg shadow-2xl border p-2 z-50 ${
            isDark
              ? 'bg-[#1e222d] border-[#2a2e39] text-[#d1d4dc]'
              : 'bg-[#ffffff] border-[#e0e3eb] text-[#131722]'
          }`}
        >
          <div className="flex items-center justify-between pb-2 mb-2 border-b border-opacity-40 border-gray-500">
            <span className="text-xs font-semibold uppercase tracking-wider text-gray-400">
              Select Chart Layout (Max 12)
            </span>
            <span className="text-[10px] px-1.5 py-0.5 rounded bg-blue-500/10 text-blue-500 font-mono">
              TV Pro Multi
            </span>
          </div>

          <div className="grid grid-cols-3 gap-2">
            {LAYOUT_OPTIONS.map((opt) => {
              const isSelected = currentCount === opt.count;
              return (
                <button
                  key={opt.count}
                  onClick={() => {
                    onSelectLayout(opt.count);
                    setIsOpen(false);
                  }}
                  className={`flex flex-col items-center p-2 rounded-md border text-center transition-all ${
                    isSelected
                      ? isDark
                        ? 'border-[#2962ff] bg-[#2962ff]/15 text-[#2962ff]'
                        : 'border-[#2962ff] bg-blue-50 text-[#2962ff]'
                      : isDark
                      ? 'border-[#2a2e39] hover:bg-[#2a2e39]/60 hover:border-gray-500 text-gray-300'
                      : 'border-[#e0e3eb] hover:bg-[#f8f9fd] hover:border-gray-400 text-gray-700'
                  }`}
                >
                  {/* Visual Layout Representation */}
                  <div
                    className={`w-10 h-7 rounded border border-current/40 mb-1.5 grid gap-0.5 p-0.5 ${
                      opt.rows === 1 ? 'grid-rows-1' : opt.rows === 2 ? 'grid-rows-2' : 'grid-rows-3'
                    } ${
                      opt.cols === 1
                        ? 'grid-cols-1'
                        : opt.cols === 2
                        ? 'grid-cols-2'
                        : opt.cols === 3
                        ? 'grid-cols-3'
                        : opt.cols === 4
                        ? 'grid-cols-4'
                        : 'grid-cols-5'
                    }`}
                  >
                    {Array.from({ length: opt.count }).map((_, i) => (
                      <div
                        key={i}
                        className={`rounded-[1px] ${
                          isSelected ? 'bg-[#2962ff]' : 'bg-current opacity-30'
                        }`}
                      />
                    ))}
                  </div>

                  <span className="text-xs font-medium leading-none mb-0.5 flex items-center justify-center gap-1">
                    {opt.label}
                    {isSelected && <Check className="w-3 h-3 text-[#2962ff]" />}
                  </span>
                  <span className="text-[10px] opacity-60 leading-tight">
                    {opt.rows}x{opt.cols}
                  </span>
                </button>
              );
            })}
          </div>
        </div>
      )}
    </div>
  );
};

