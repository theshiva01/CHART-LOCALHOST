const WebSocket = require('ws').WebSocket;
const protobuf = require('protobufjs');
const https = require('https');
const axios = require('axios');
const path = require('path');
const EventEmitter = require('events');

class UpstoxFeedManager extends EventEmitter {
  constructor() {
    super();
    this.accessToken = null;
    this.ws = null;
    this.protobufRoot = null;
    this.FeedResponse = null;
    this.subscribedKeys = new Set();
    this.isConnected = false;
    this.isConnecting = false;
    this.reconnectTimer = null;
    this.userProfile = null;
    this.tickCount = 0;
  }

  async initProtobuf() {
    if (this.protobufRoot) return;
    try {
      const protoPath = path.join(__dirname, 'proto', 'MarketDataFeedV3.proto');
      this.protobufRoot = await protobuf.load(protoPath);
      this.FeedResponse = this.protobufRoot.lookupType(
        'com.upstox.marketdatafeederv3udapi.rpc.proto.FeedResponse'
      );
      console.log('✅ Upstox Protobuf schema loaded successfully');
    } catch (err) {
      console.error('❌ Failed to load Upstox Protobuf schema:', err.message);
    }
  }

  async setAccessToken(token) {
    if (!token || token.trim() === '') {
      this.disconnect();
      this.accessToken = null;
      this.userProfile = null;
      this.emit('status', { connected: false, message: 'Token removed.' });
      return { success: true };
    }

    this.accessToken = token.trim();
    await this.initProtobuf();

    try {
      const profileRes = await axios.get('https://api.upstox.com/v2/user/profile', {
        headers: {
          'Authorization': `Bearer ${this.accessToken}`,
          'Accept': 'application/json'
        },
        timeout: 8000
      });

      this.userProfile = profileRes.data.data;
      console.log(`✅ Upstox Token Validated for User: ${this.userProfile?.user_name || 'Trader'}`);

      await this.connect();

      return {
        success: true,
        user: this.userProfile,
        mode: 'live'
      };
    } catch (err) {
      console.error('❌ Upstox Token Validation Failed:', err.response?.data || err.message);
      this.accessToken = null;
      throw new Error(err.response?.data?.errors?.[0]?.message || err.message || 'Invalid Upstox Access Token');
    }
  }

  async getMarketFeedUrl() {
    const url = 'https://api.upstox.com/v3/feed/market-data-feed/authorize';
    const response = await axios.get(url, {
      headers: {
        'Accept': 'application/json',
        'Authorization': `Bearer ${this.accessToken}`
      },
      timeout: 10000
    });
    return response.data?.data?.authorizedRedirectUri;
  }

  async connect() {
    if (this.isConnecting || !this.accessToken) return;
    this.isConnecting = true;

    try {
      const wsUrl = await this.getMarketFeedUrl();
      if (!wsUrl) throw new Error('Could not get Upstox WebSocket redirect URL');

      if (this.ws) {
        try { this.ws.terminate(); } catch (e) {}
      }

      this.ws = new WebSocket(wsUrl, { followRedirects: true });

      this.ws.on('open', () => {
        this.isConnected = true;
        this.isConnecting = false;
        console.log('⚡ Connected to Upstox Live Market Data WebSocket');
        this.emit('status', {
          connected: true,
          mode: 'live',
          user: this.userProfile,
          message: 'Connected to Upstox Live Feed'
        });

        if (this.subscribedKeys.size > 0) {
          this.sendSubscription(Array.from(this.subscribedKeys));
        }
      });

      this.ws.on('message', (buffer) => {
        this.handleBinaryMessage(buffer);
      });

      this.ws.on('close', (code, reason) => {
        this.isConnected = false;
        this.isConnecting = false;
        console.warn(`Upstox WebSocket closed (code: ${code}). Reason: ${reason || 'none'}`);
        this.emit('status', {
          connected: false,
          mode: 'reconnecting',
          message: 'Upstox WebSocket disconnected. Retrying in 5s...'
        });
        this.scheduleReconnect();
      });

      this.ws.on('error', (err) => {
        console.error('Upstox WebSocket error:', err.message);
      });

    } catch (err) {
      this.isConnecting = false;
      this.isConnected = false;
      console.error('Failed to connect to Upstox WebSocket:', err.message);
      this.emit('status', {
        connected: false,
        mode: 'error',
        message: err.message
      });
      this.scheduleReconnect();
    }
  }

  scheduleReconnect() {
    if (this.reconnectTimer || !this.accessToken) return;
    this.reconnectTimer = setTimeout(() => {
      this.reconnectTimer = null;
      if (this.accessToken && !this.isConnected) {
        console.log('Attempting Upstox WebSocket reconnect...');
        this.connect();
      }
    }, 5000);
  }

  disconnect() {
    if (this.reconnectTimer) {
      clearTimeout(this.reconnectTimer);
      this.reconnectTimer = null;
    }
    if (this.ws) {
      try { this.ws.close(); } catch (e) {}
      this.ws = null;
    }
    this.isConnected = false;
    this.isConnecting = false;
  }

  subscribe(keys) {
    if (!Array.isArray(keys)) keys = [keys];
    let newKeys = false;
    keys.forEach(k => {
      if (!this.subscribedKeys.has(k)) {
        this.subscribedKeys.add(k);
        newKeys = true;
      }
    });

    if (this.isConnected && this.ws?.readyState === WebSocket.OPEN && this.subscribedKeys.size > 0) {
      this.sendSubscription(Array.from(this.subscribedKeys));
    }
  }

  unsubscribe(keys) {
    if (!Array.isArray(keys)) keys = [keys];
    keys.forEach(k => this.subscribedKeys.delete(k));
    if (keys.length > 0 && this.isConnected && this.ws?.readyState === WebSocket.OPEN) {
      const data = {
        guid: 'unsub_' + Date.now(),
        method: 'unsub',
        data: {
          instrumentKeys: keys
        }
      };
      this.ws.send(Buffer.from(JSON.stringify(data)));
    }
  }

  sendSubscription(instrumentKeys) {
    if (!this.ws || this.ws.readyState !== WebSocket.OPEN) return;
    const cleanKeys = Array.from(new Set(instrumentKeys));
    const data = {
      guid: 'sub_' + Date.now(),
      method: 'sub',
      data: {
        mode: 'full',
        instrumentKeys: cleanKeys
      }
    };
    this.ws.send(Buffer.from(JSON.stringify(data)));
    console.log(`📡 Upstox Live Subscribed to ${cleanKeys.length} instruments:`, cleanKeys.slice(0, 5));
  }

  handleBinaryMessage(buffer) {
    if (!this.FeedResponse) return;
    try {
      const decoded = this.FeedResponse.decode(buffer);
      const obj = this.FeedResponse.toObject(decoded, {
        longs: Number,
        enums: String,
        defaults: true
      });

      if (!obj || !obj.feeds) return;

      for (const [instrumentKey, feed] of Object.entries(obj.feeds)) {
        let ltp = 0;
        let ltt = Date.now();
        let ltq = 0;
        let cp = 0;
        let high = 0;
        let low = 0;
        let open = 0;
        let volume = 0;

        if (feed.ltpc) {
          ltp = Number(feed.ltpc.ltp || 0);
          ltt = Number(feed.ltpc.ltt || Date.now());
          ltq = Number(feed.ltpc.ltq || 0);
          cp = Number(feed.ltpc.cp || 0);
        }

        if (feed.fullFeed) {
          const ff = feed.fullFeed.marketFF || feed.fullFeed.indexFF;
          if (ff?.ltpc) {
            ltp = Number(ff.ltpc.ltp || ltp);
            ltt = Number(ff.ltpc.ltt || ltt);
            ltq = Number(ff.ltpc.ltq || ltq);
            cp = Number(ff.ltpc.cp || cp);
          }
          if (ff?.marketOHLC?.ohlc && ff.marketOHLC.ohlc.length > 0) {
            const ohlc = ff.marketOHLC.ohlc[0];
            open = Number(ohlc.open || 0);
            high = Number(ohlc.high || 0);
            low = Number(ohlc.low || 0);
            volume = Number(ohlc.vol || 0);
          }
          if (ff?.vtt) {
            volume = Number(ff.vtt || volume);
          }
        }

        if (feed.firstLevelWithGreeks?.ltpc) {
          ltp = Number(feed.firstLevelWithGreeks.ltpc.ltp || ltp);
          ltt = Number(feed.firstLevelWithGreeks.ltpc.ltt || ltt);
          ltq = Number(feed.firstLevelWithGreeks.ltpc.ltq || ltq);
          cp = Number(feed.firstLevelWithGreeks.ltpc.cp || cp);
        }

        if (ltp > 0) {
          this.tickCount++;
          const tick = {
            instrumentKey,
            ltp,
            volume: ltq || 1,
            totalVolume: volume,
            high: high || ltp,
            low: low || ltp,
            open: open || ltp,
            cp,
            ltt,
            source: 'upstox'
          };
          this.emit('tick', tick);
        }
      }
    } catch (err) {
      console.error('Error decoding Upstox protobuf message:', err.message);
    }
  }

  /**
   * Helper to execute HTTPS GET request to Upstox API
   */
  httpGet(url) {
    return new Promise((resolve) => {
      const headers = { 'Accept': 'application/json' };
      if (this.accessToken) {
        headers['Authorization'] = `Bearer ${this.accessToken}`;
      }
      https.get(url, { headers, timeout: 8000 }, (res) => {
        let data = '';
        res.on('data', chunk => data += chunk);
        res.on('end', () => {
          try {
            resolve(JSON.parse(data));
          } catch (e) {
            resolve(null);
          }
        });
      }).on('error', () => resolve(null));
    });
  }

  /**
   * Compute Demand & Supply Levels from Daily Candles (1,2,3 Day, 1,2,3 Week, 1,2,3 Month)
   * Matching Pine Script DEMAND/SUPPLY indicator
   */
  computeDemandSupplyLevels(dailyCandles) {
    if (!Array.isArray(dailyCandles) || dailyCandles.length === 0) {
      return { d1: null, d2: null, d3: null, w1: null, w2: null, w3: null, m1: null, m2: null, m3: null };
    }

    const candles = [...dailyCandles].map(c => ({
      dateStr: String(c[0]).split('T')[0],
      date: new Date(c[0]),
      open: Number(c[1]),
      high: Number(c[2]),
      low: Number(c[3]),
      close: Number(c[4]),
    })).sort((a, b) => a.date - b.date);

    const len = candles.length;
    const d1 = len >= 1 ? { high: candles[len - 1].high, low: candles[len - 1].low, date: candles[len - 1].dateStr } : null;
    const d2 = len >= 2 ? { high: candles[len - 2].high, low: candles[len - 2].low, date: candles[len - 2].dateStr } : null;
    const d3 = len >= 3 ? { high: candles[len - 3].high, low: candles[len - 3].low, date: candles[len - 3].dateStr } : null;

    // Group by calendar week (Monday start)
    const weeksMap = new Map();
    for (const c of candles) {
      const d = new Date(c.date);
      const day = d.getDay();
      const diff = d.getDate() - day + (day === 0 ? -6 : 1);
      const monday = new Date(d.setDate(diff));
      const wKey = monday.toISOString().split('T')[0];
      if (!weeksMap.has(wKey)) weeksMap.set(wKey, []);
      weeksMap.get(wKey).push(c);
    }
    const weekKeys = Array.from(weeksMap.keys()).sort();
    const completedWeeks = weekKeys.slice(0, -1);
    const getWeekHL = (key) => {
      if (!key) return null;
      const list = weeksMap.get(key) || [];
      return {
        high: Number(Math.max(...list.map(c => c.high)).toFixed(2)),
        low: Number(Math.min(...list.map(c => c.low)).toFixed(2)),
        key
      };
    };
    const w1 = getWeekHL(completedWeeks[completedWeeks.length - 1]);
    const w2 = getWeekHL(completedWeeks[completedWeeks.length - 2]);
    const w3 = getWeekHL(completedWeeks[completedWeeks.length - 3]);

    // Group by calendar month ('YYYY-MM')
    const monthsMap = new Map();
    for (const c of candles) {
      const mKey = c.dateStr.slice(0, 7);
      if (!monthsMap.has(mKey)) monthsMap.set(mKey, []);
      monthsMap.get(mKey).push(c);
    }
    const monthKeys = Array.from(monthsMap.keys()).sort();
    const completedMonths = monthKeys.slice(0, -1);
    const getMonthHL = (key) => {
      if (!key) return null;
      const list = monthsMap.get(key) || [];
      return {
        high: Number(Math.max(...list.map(c => c.high)).toFixed(2)),
        low: Number(Math.min(...list.map(c => c.low)).toFixed(2)),
        key
      };
    };
    const m1 = getMonthHL(completedMonths[completedMonths.length - 1]);
    const m2 = getMonthHL(completedMonths[completedMonths.length - 2]);
    const m3 = getMonthHL(completedMonths[completedMonths.length - 3]);

    return { d1, d2, d3, w1, w2, w3, m1, m2, m3 };
  }

  /**
   * Fetch 100% REAL LIVE historical candles from Upstox API v3
   */
  async fetchHistoricalCandles(instrumentKey, interval = '5m') {
    const encoded = encodeURIComponent(instrumentKey);
    let unit = 'minutes';
    let intVal = '5';

    if (interval === '1m') { unit = 'minutes'; intVal = '1'; }
    else if (interval === '3m') { unit = 'minutes'; intVal = '3'; }
    else if (interval === '5m') { unit = 'minutes'; intVal = '5'; }
    else if (interval === '15m') { unit = 'minutes'; intVal = '15'; }
    else if (interval === '30m') { unit = 'minutes'; intVal = '30'; }
    else if (interval === '1h') { unit = 'hours'; intVal = '1'; }
    else if (interval === '1D') { unit = 'days'; intVal = '1'; }

    const now = new Date();
    const toDate = now.toLocaleDateString('en-CA', { timeZone: 'Asia/Kolkata' });
    const fromDate = new Date(now.getTime() - 4 * 86400000).toLocaleDateString('en-CA', { timeZone: 'Asia/Kolkata' });
    const dailyFromDate = new Date(now.getTime() - 120 * 86400000).toLocaleDateString('en-CA', { timeZone: 'Asia/Kolkata' });

    // 1. Previous multi-day session candles
    const histUrl = `https://api.upstox.com/v3/historical-candle/${encoded}/${unit}/${intVal}/${toDate}/${fromDate}`;
    // 2. Today's intraday live candles
    const intraUrl = `https://api.upstox.com/v3/historical-candle/intraday/${encoded}/${unit}/${intVal}`;
    // 3. Daily candles for official PDH/PDL and 1D, 2D, 3D, 1W, 2W, 3W, 1M, 2M, 3M Demand & Supply levels
    const dailyUrl = `https://api.upstox.com/v3/historical-candle/${encoded}/days/1/${toDate}/${dailyFromDate}`;

    try {
      const [histRes, intraRes, dailyRes] = await Promise.all([
        this.httpGet(histUrl),
        this.httpGet(intraUrl),
        this.httpGet(dailyUrl)
      ]);

      const rawHist = histRes?.data?.candles || [];
      const rawIntra = intraRes?.data?.candles || [];
      const rawDaily = dailyRes?.data?.candles || [];

      const timeMap = new Map();

      // Older historical candles
      [...rawHist].reverse().forEach(c => {
        const time = Math.floor(new Date(c[0]).getTime() / 1000);
        timeMap.set(time, {
          time,
          open: Number(c[1]),
          high: Number(c[2]),
          low: Number(c[3]),
          close: Number(c[4]),
          volume: Number(c[5])
        });
      });

      // Today's intraday live candles
      [...rawIntra].reverse().forEach(c => {
        const time = Math.floor(new Date(c[0]).getTime() / 1000);
        timeMap.set(time, {
          time,
          open: Number(c[1]),
          high: Number(c[2]),
          low: Number(c[3]),
          close: Number(c[4]),
          volume: Number(c[5])
        });
      });

      const sortedCandles = Array.from(timeMap.values()).sort((a, b) => a.time - b.time);

      // Extract official PDH and PDL from yesterday's daily candle
      let pdh = null;
      let pdl = null;
      if (rawDaily.length > 0) {
        // First candle in rawDaily is yesterday's session
        const yCandle = rawDaily[0];
        pdh = Number(yCandle[2]);
        pdl = Number(yCandle[3]);
      }

      // Compute 1,2,3 Day, 1,2,3 Week, 1,2,3 Month Demand & Supply Levels
      const demandSupply = this.computeDemandSupplyLevels(rawDaily);

      console.log(`📊 Loaded REAL Upstox candles for ${instrumentKey}: ${sortedCandles.length} candles, PDH: ${pdh}, PDL: ${pdl}`);

      return {
        candles: sortedCandles,
        pdh,
        pdl,
        demandSupply
      };
    } catch (err) {
      console.error(`Failed to fetch Upstox candles for ${instrumentKey}:`, err.message);
      return { candles: [], pdh: null, pdl: null };
    }
  }
}

module.exports = new UpstoxFeedManager();
