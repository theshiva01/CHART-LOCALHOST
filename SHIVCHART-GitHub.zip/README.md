# ⚡ SHIVCHART PRO - Multi-Chart Live TradingView Dashboard

A high-performance TradingView-style Multi-Chart Dashboard running on **`http://localhost:5000`**, supporting **up to 12 live charts on a single screen**, real-time **tick-by-tick candle updates**, built-in **EMA 9, EMA 15, VWAP, PDH/PDL, 5-min H/L, and 15-min H/L marks** (with instant ON/OFF toggles), **Upstox API v3 live WebSocket integration**, and full **Light & Dark mode** themes.

---

## 🌟 Key Features

### 1. 📊 Multi-Chart Grid (Up to 12 Charts on a Single Screen)
- **Presets**: 1 (Single), 2 (Split), 3 (Columns), 4 (2x2), 6 (3x2), 8 (4x2), 9 (3x3), 10 (5x2), and **12 (4x3 Pro View)**.
- **Individual Controls for each of the 12 charts**:
  - Independent Symbol search (Nifty 50, Bank Nifty, Fin Nifty, Sensex, Reliance, HDFC Bank, TCS, Infosys, SBI, Tata Motors, etc. + custom Upstox instrument keys).
  - Independent Timeframe switcher (`1m`, `3m`, `5m`, `15m`, `30m`, `1h`, `1D`).
  - Chart Types: Candlestick, Line, Area, and Heikin-Ashi.
  - Maximize button to focus on any single chart, and minimize back to the multi-grid view.
- **Global Multi-Chart Sync**:
  - **Crosshair Sync**: Hovering over one chart syncs crosshairs across all 12 charts simultaneously.
  - **Time Sync**: Panning or scrolling synchronizes timestamps across all charts.

---

### 2. 📈 Indicators with 1-Click ON/OFF Toggles & Customization
All required indicators are built right into the charts with instant header toggles and a dedicated Settings modal:
- **EMA 9 (Exponential Moving Average 9)**: Fast moving average line (customizable color & thickness).
- **EMA 15 (Exponential Moving Average 15)**: Medium moving average line.
- **VWAP (Volume Weighted Average Price)**: Daily cumulative $((\text{High} + \text{Low} + \text{Close}) / 3 \times \text{Volume}) / \text{Volume}$ resetting at each session day.
- **Previous Day High / Low (PDH / PDL)**: Horizontal price lines across the chart marking the previous trading day's high (green) and low (red) levels with price labels.
- **5-Min High / Low Mark**: Opening 5-minute range breakout levels (5m ORH / ORL) with distinct color levels.
- **15-Min High / Low Mark**: Opening 15-minute range breakout levels (15m ORH / ORL).
- **Global & Per-Chart Application**: Toggle on/off for a single chart or click "Apply to All 12 Charts".

---

### 3. ⏱️ Live Tick-by-Tick Candle Execution
- Fast 60 FPS updates using TradingView's official **Lightweight Charts** engine.
- Every incoming tick immediately updates the current candle's `close`, expands `high`/`low`, and accumulates `volume`.
- When the timeframe duration completes (e.g. at 09:16:00 for 1m candle), a new candle forms seamlessly.
- Live price badge blinks with an animated green glow (uptick) or red glow (downtick).

---

### 4. 🔑 Upstox Access Token Connection
- **Upstox V3 Market Data Feed WebSocket**: Connects using Google Protobuf (`MarketDataFeedV3.proto`) decoding.
- **Live Historical Candles**: Fetches intraday and daily history directly from Upstox REST API.
- **Realistic Fallback Simulator**: If no Upstox token is provided, a realistic tick-by-tick simulator with market noise runs automatically across all instruments so you can test all 12 charts immediately.
- To connect: Click the **Upstox Token** button in the header, paste your Bearer token, and click **Connect**.

---

### 5. 🌓 Dual Themes: Light and Dark
- 1-click Theme Toggle in the header (Sun / Moon icon).
- **Dark Theme**: TradingView Deep Navy `#131722` / `#1e222d` with emerald (`#089981`) and crimson (`#f23645`) candles.
- **Light Theme**: Clean crisp white `#ffffff` / `#f0f3fa` with high-contrast candles and grid.
- Dynamic theme transition across all 12 chart canvases simultaneously.

---

## 🚀 Quick Start Guide

### Step 1: Start Backend and Frontend
Run the following in the project root:

```bash
# Start the entire dashboard on PORT 5000:
npm run dev
```

Or start the production server:
```bash
# Run standalone on port 5000
npm start
```

### Step 2: Open in Browser
Visit **`http://localhost:5000`** in your browser.

---

## 🛠️ Project Structure

```
SHIVCHART/
├── server/
│   ├── proto/
│   │   └── MarketDataFeedV3.proto   # Upstox v3 Protobuf schema
│   ├── instruments.json             # Pre-configured Indian indices and stocks
│   ├── upstoxFeed.js                # Upstox WebSocket + Protobuf decoder + REST candles
│   ├── simulator.js                 # Realistic tick-by-tick market generator
│   └── server.js                    # Express + WebSocket server
├── client/
│   ├── src/
│   │   ├── components/
│   │   │   ├── Header.tsx           # TV Top Bar, Quick Indicator toggles, Theme toggle
│   │   │   ├── LayoutSelector.tsx   # 1 to 12 Charts layout picker
│   │   │   ├── ChartGrid.tsx        # Responsive multi-chart grid container
│   │   │   ├── SingleChart.tsx      # Individual TV chart, indicators & tick engine
│   │   │   ├── IndicatorModal.tsx   # EMA 9, 15, VWAP, PDH, PDL, 5m, 15m settings
│   │   │   ├── UpstoxModal.tsx      # Upstox Access Token connection modal
│   │   │   ├── DrawingToolbar.tsx   # TV Left drawing tools
│   │   │   └── StatusBar.tsx        # Bottom latency, ticks/s, IST clock
│   │   ├── hooks/
│   │   │   ├── useWebSocket.ts      # Live tick stream manager (connects on port 5000)
│   │   │   └── useTheme.ts          # Dark / Light theme manager
│   │   ├── utils/
│   │   │   ├── indicators.ts        # EMA, VWAP, PDH/PDL, 5m/15m ORH/ORL math
│   │   │   └── chartOptions.ts      # TV chart styles and color schemes
│   │   ├── types/
│   │   │   └── chart.ts             # TypeScript definitions
│   │   ├── App.tsx                  # Main Dashboard Container
│   │   └── main.tsx                 # Entrypoint
│   └── vite.config.ts               # Serves dashboard on PORT 5000
└── package.json
```
