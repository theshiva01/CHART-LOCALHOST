import { useEffect, useRef, useState, useCallback } from 'react';
import { TickData, UpstoxStatus } from '../types/chart';

type TickListener = (tick: TickData) => void;
type StatusListener = (status: UpstoxStatus) => void;

export function useWebSocket() {
  const wsRef = useRef<WebSocket | null>(null);
  const [isConnected, setIsConnected] = useState(false);
  const [latency, setLatency] = useState<number>(12);
  const [upstoxStatus, setUpstoxStatus] = useState<UpstoxStatus>({
    connected: false,
    mode: 'standby',
    message: 'Connecting to local feed...'
  });

  const tickListeners = useRef<Map<string, Set<TickListener>>>(new Map());
  const statusListeners = useRef<Set<StatusListener>>(new Set());
  const activeSubscribedKeys = useRef<Set<string>>(new Set());
  const pingStartRef = useRef<number>(0);

  const connect = useCallback(() => {
    const protocol = window.location.protocol === 'https:' ? 'wss:' : 'ws:';
    // Use /ws on port 5000 which Vite/Express proxies to backend on 5005
    const wsUrl = `${protocol}//${window.location.host}/ws`;

    const ws = new WebSocket(wsUrl);
    wsRef.current = ws;

    ws.onopen = () => {
      setIsConnected(true);
      // Resubscribe any active keys
      if (activeSubscribedKeys.current.size > 0) {
        ws.send(JSON.stringify({
          type: 'subscribe',
          keys: Array.from(activeSubscribedKeys.current)
        }));
      }

      // Start ping loop for latency measurement
      const pingInterval = setInterval(() => {
        if (ws.readyState === WebSocket.OPEN) {
          pingStartRef.current = Date.now();
          ws.send(JSON.stringify({ type: 'ping' }));
        }
      }, 5000);

      (ws as any)._pingInterval = pingInterval;
    };

    ws.onmessage = (event) => {
      try {
        const msg = JSON.parse(event.data);
        if (msg.type === 'tick' && msg.data) {
          const tick: TickData = msg.data;
          const listeners = tickListeners.current.get(tick.instrumentKey);
          if (listeners) {
            listeners.forEach(cb => cb(tick));
          }
        } else if (msg.type === 'status') {
          setUpstoxStatus(msg);
          statusListeners.current.forEach(cb => cb(msg));
        } else if (msg.type === 'pong') {
          const rtt = Date.now() - pingStartRef.current;
          setLatency(Math.max(2, rtt));
        }
      } catch (err) {
        console.error('Failed to parse WebSocket message:', err);
      }
    };

    ws.onclose = () => {
      setIsConnected(false);
      if ((ws as any)._pingInterval) {
        clearInterval((ws as any)._pingInterval);
      }
      // Reconnect after 2 seconds
      setTimeout(() => {
        connect();
      }, 2000);
    };

    ws.onerror = (err) => {
      console.warn('WS error:', err);
      ws.close();
    };
  }, []);

  useEffect(() => {
    connect();
    return () => {
      if (wsRef.current) {
        wsRef.current.close();
      }
    };
  }, [connect]);

  const subscribe = useCallback((keys: string | string[], callback?: TickListener) => {
    const keyArray = Array.isArray(keys) ? keys : [keys];
    
    keyArray.forEach(k => {
      activeSubscribedKeys.current.add(k);
      if (callback) {
        if (!tickListeners.current.has(k)) {
          tickListeners.current.set(k, new Set());
        }
        tickListeners.current.get(k)!.add(callback);
      }
    });

    if (wsRef.current && wsRef.current.readyState === WebSocket.OPEN) {
      wsRef.current.send(JSON.stringify({
        type: 'subscribe',
        keys: keyArray
      }));
    }
  }, []);

  const unsubscribe = useCallback((keys: string | string[], callback?: TickListener) => {
    const keyArray = Array.isArray(keys) ? keys : [keys];

    keyArray.forEach(k => {
      if (callback && tickListeners.current.has(k)) {
        tickListeners.current.get(k)!.delete(callback);
        if (tickListeners.current.get(k)!.size === 0) {
          tickListeners.current.delete(k);
          activeSubscribedKeys.current.delete(k);
        }
      } else {
        tickListeners.current.delete(k);
        activeSubscribedKeys.current.delete(k);
      }
    });

    if (wsRef.current && wsRef.current.readyState === WebSocket.OPEN) {
      wsRef.current.send(JSON.stringify({
        type: 'unsubscribe',
        keys: keyArray
      }));
    }
  }, []);

  const onStatusChange = useCallback((cb: StatusListener) => {
    statusListeners.current.add(cb);
    return () => {
      statusListeners.current.delete(cb);
    };
  }, []);

  return {
    isConnected,
    latency,
    upstoxStatus,
    subscribe,
    unsubscribe,
    onStatusChange
  };
}
