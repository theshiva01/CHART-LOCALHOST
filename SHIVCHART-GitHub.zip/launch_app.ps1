# SHIVCHART PRO App Launcher
# Checks backend and frontend services, then opens Chrome/Edge in dedicated Desktop App Mode

$workspace = "f:\SHIVCHART"
$clientPort = 5000
$serverPort = 5005
$url = "http://localhost:$clientPort"

function Test-PortListening {
    param([int]$p)
    try {
        $client = New-Object System.Net.Sockets.TcpClient
        $iar = $client.BeginConnect("127.0.0.1", $p, $null, $null)
        $wait = $iar.AsyncWaitHandle.WaitOne(600, $false)
        if ($wait) {
            $client.EndConnect($iar)
            $client.Close()
            return $true
        }
        $client.Close()
        return $false
    } catch {
        return $false
    }
}

# 1. Start Node backend on port 5005 if not running
if (-not (Test-PortListening $serverPort)) {
    Start-Process -FilePath "node.exe" -ArgumentList "server/server.js" -WorkingDirectory $workspace -WindowStyle Hidden
}

# 2. Start Vite frontend on port 5000 if not running
if (-not (Test-PortListening $clientPort)) {
    Start-Process -FilePath "cmd.exe" -ArgumentList "/c npm.cmd --prefix client run dev" -WorkingDirectory $workspace -WindowStyle Hidden
    
    # Wait for Vite dev server to respond
    $attempts = 0
    while ((-not (Test-PortListening $clientPort)) -and ($attempts -lt 25)) {
        Start-Sleep -Milliseconds 400
        $attempts++
    }
}

# 3. Locate Chrome or Edge for standalone App Mode
$chromePaths = @(
    "C:\Program Files\Google\Chrome\Application\chrome.exe",
    "C:\Program Files (x86)\Google\Chrome\Application\chrome.exe",
    (Join-Path $env:LOCALAPPDATA "Google\Chrome\Application\chrome.exe")
)
$edgePaths = @(
    "C:\Program Files (x86)\Microsoft\Edge\Application\msedge.exe",
    "C:\Program Files\Microsoft\Edge\Application\msedge.exe",
    (Join-Path $env:LOCALAPPDATA "Microsoft\Edge\Application\msedge.exe")
)
$bravePaths = @(
    "C:\Program Files\BraveSoftware\Brave-Browser\Application\brave.exe",
    (Join-Path $env:LOCALAPPDATA "BraveSoftware\Brave-Browser\Application\brave.exe")
)

$targetBrowser = $null
foreach ($p in $chromePaths) {
    if (Test-Path $p) {
        $targetBrowser = $p
        break
    }
}
if (-not $targetBrowser) {
    foreach ($p in $edgePaths) {
        if (Test-Path $p) {
            $targetBrowser = $p
            break
        }
    }
}
if (-not $targetBrowser) {
    foreach ($p in $bravePaths) {
        if (Test-Path $p) {
            $targetBrowser = $p
            break
        }
    }
}

# 4. Launch in standalone Native App Mode (no address bar, no tabs)
if ($targetBrowser) {
    Start-Process -FilePath $targetBrowser -ArgumentList "--app=$url --start-maximized"
} else {
    Start-Process $url
}

