import React, { useState } from 'react';
import { X, Key, ShieldCheck, AlertCircle, CheckCircle2, Eye, EyeOff, ExternalLink, Unlink } from 'lucide-react';
import { UpstoxStatus } from '../types/chart';

interface UpstoxModalProps {
  isOpen: boolean;
  onClose: () => void;
  status: UpstoxStatus;
  onStatusUpdate: () => void;
  isDark: boolean;
}

export const UpstoxModal: React.FC<UpstoxModalProps> = ({
  isOpen,
  onClose,
  status,
  onStatusUpdate,
  isDark,
}) => {
  const [tokenInput, setTokenInput] = useState('');
  const [showToken, setShowToken] = useState(false);
  const [loading, setLoading] = useState(false);
  const [errorMsg, setErrorMsg] = useState<string | null>(null);
  const [successMsg, setSuccessMsg] = useState<string | null>(null);

  if (!isOpen) return null;

  const handleConnect = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!tokenInput.trim()) {
      setErrorMsg('Please enter an Upstox Access Token.');
      return;
    }

    setLoading(true);
    setErrorMsg(null);
    setSuccessMsg(null);

    try {
      const res = await fetch('/api/upstox/token', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ token: tokenInput.trim() }),
      });

      const data = await res.json();
      if (!res.ok || !data.success) {
        throw new Error(data.error || 'Failed to authenticate Upstox token.');
      }

      setSuccessMsg(`Connected successfully! Welcome ${data.user?.user_name || 'Trader'}`);
      setTokenInput('');
      onStatusUpdate();
      setTimeout(() => {
        onClose();
      }, 1500);
    } catch (err: any) {
      setErrorMsg(err.message || 'Connection failed.');
    } finally {
      setLoading(false);
    }
  };

  const handleDisconnect = async () => {
    setLoading(true);
    setErrorMsg(null);
    try {
      await fetch('/api/upstox/token', { method: 'DELETE' });
      setSuccessMsg('Disconnected from Upstox token.');
      onStatusUpdate();
    } catch (err: any) {
      setErrorMsg(err.message || 'Failed to disconnect.');
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/60 backdrop-blur-sm p-4">
      <div
        className={`w-full max-w-lg rounded-xl shadow-2xl border flex flex-col overflow-hidden ${
          isDark
            ? 'bg-[#1e222d] border-[#2a2e39] text-[#d1d4dc]'
            : 'bg-[#ffffff] border-[#e0e3eb] text-[#131722]'
        }`}
      >
        {/* Header */}
        <div className="flex items-center justify-between px-6 py-4 border-b border-opacity-30 border-gray-500">
          <div className="flex items-center gap-2.5">
            <Key className="w-5 h-5 text-[#2962ff]" />
            <div>
              <h2 className="text-base font-bold">Upstox API v3 Live Feed</h2>
              <p className="text-xs opacity-60">Connect Access Token for Real-time Tick-by-Tick Feed</p>
            </div>
          </div>
          <button
            onClick={onClose}
            className="p-1 rounded-md hover:bg-gray-500/20 transition-colors"
          >
            <X className="w-5 h-5 opacity-70 hover:opacity-100" />
          </button>
        </div>

        {/* Body */}
        <div className="p-6 space-y-5">
          {/* Status banner */}
          <div
            className={`p-3.5 rounded-lg border flex items-start gap-3 ${
              status.connected
                ? isDark
                  ? 'bg-emerald-500/10 border-emerald-500/30 text-emerald-400'
                  : 'bg-emerald-50 border-emerald-200 text-emerald-800'
                : isDark
                ? 'bg-amber-500/10 border-amber-500/30 text-amber-400'
                : 'bg-amber-50 border-amber-200 text-amber-800'
            }`}
          >
            {status.connected ? (
              <CheckCircle2 className="w-5 h-5 text-emerald-500 shrink-0 mt-0.5" />
            ) : (
              <AlertCircle className="w-5 h-5 text-amber-500 shrink-0 mt-0.5" />
            )}
            <div className="text-xs space-y-1">
              <div className="font-semibold text-sm">
                {status.connected ? 'Upstox Live Connected' : 'Upstox Token Setup'}
              </div>
              <div>
                {status.connected
                  ? `Authenticated as: ${status.user?.user_name || 'Upstox User'} (${status.user?.user_id || 'ID'})`
                  : 'Enter your Upstox Access Token below to stream live tick-by-tick market data directly from NSE/BSE to your charts.'}
              </div>
            </div>
          </div>

          {/* Form */}
          <form onSubmit={handleConnect} className="space-y-4">
            <div>
              <label className="block text-xs font-semibold mb-1.5 opacity-80">
                Upstox Access Token
              </label>
              <div className="relative">
                <input
                  type={showToken ? 'text' : 'password'}
                  value={tokenInput}
                  onChange={(e) => setTokenInput(e.target.value)}
                  placeholder="Paste your Upstox Bearer Access Token here..."
                  className={`w-full px-3.5 py-2.5 pr-10 text-xs rounded-lg border font-mono transition-colors outline-none focus:border-[#2962ff] ${
                    isDark
                      ? 'bg-[#131722] border-[#2a2e39] text-[#d1d4dc] placeholder-gray-600'
                      : 'bg-white border-gray-300 text-gray-900 placeholder-gray-400'
                  }`}
                />
                <button
                  type="button"
                  onClick={() => setShowToken(!showToken)}
                  className="absolute right-3 top-2.5 opacity-60 hover:opacity-100"
                >
                  {showToken ? <EyeOff className="w-4 h-4" /> : <Eye className="w-4 h-4" />}
                </button>
              </div>
            </div>

            {errorMsg && (
              <div className="text-xs text-red-500 flex items-center gap-1.5 bg-red-500/10 p-2.5 rounded-lg border border-red-500/30">
                <AlertCircle className="w-4 h-4 shrink-0" />
                <span>{errorMsg}</span>
              </div>
            )}

            {successMsg && (
              <div className="text-xs text-emerald-500 flex items-center gap-1.5 bg-emerald-500/10 p-2.5 rounded-lg border border-emerald-500/30">
                <CheckCircle2 className="w-4 h-4 shrink-0" />
                <span>{successMsg}</span>
              </div>
            )}

            <div className="flex items-center justify-between pt-2">
              {status.connected ? (
                <button
                  type="button"
                  onClick={handleDisconnect}
                  disabled={loading}
                  className="flex items-center gap-1.5 px-3 py-2 rounded-lg text-xs font-medium text-red-400 hover:bg-red-500/10 border border-red-500/30 transition-colors"
                >
                  <Unlink className="w-4 h-4" />
                  Disconnect Token
                </button>
              ) : <div />}

              <button
                type="submit"
                disabled={loading}
                className="flex items-center gap-2 px-5 py-2 rounded-lg text-xs font-semibold bg-[#2962ff] text-white hover:bg-blue-600 transition-colors shadow-lg shadow-blue-500/20 disabled:opacity-50"
              >
                <ShieldCheck className="w-4 h-4" />
                {loading ? 'Validating Token...' : 'Connect Upstox Token'}
              </button>
            </div>
          </form>

          {/* Quick instructions */}
          <div
            className={`p-3 rounded-lg border text-xs space-y-1.5 ${
              isDark ? 'bg-[#131722]/50 border-[#2a2e39]' : 'bg-gray-50 border-gray-200'
            }`}
          >
            <div className="font-semibold flex items-center justify-between">
              <span>How to get an Upstox Access Token:</span>
              <a
                href="https://developer.upstox.com/"
                target="_blank"
                rel="noreferrer"
                className="text-[#2962ff] hover:underline flex items-center gap-1"
              >
                Upstox Developer Portal <ExternalLink className="w-3 h-3" />
              </a>
            </div>
            <ol className="list-decimal list-inside space-y-1 opacity-70 text-[11px] leading-relaxed">
              <li>Log in to your Upstox Developer console and create an app.</li>
              <li>Complete the OAuth 2.0 flow to obtain your daily session token.</li>
              <li>Paste the access token above to stream live ticks across all 12 charts!</li>
            </ol>
          </div>
        </div>
      </div>
    </div>
  );
};
