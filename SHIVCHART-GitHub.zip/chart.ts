export interface CandleData {
  time: number; // Unix timestamp in seconds
  open: number;
  high: number;
  low: number;
  close: number;
  volume?: number;
}

export interface TickData {
  instrumentKey: string;
  symbol: string;
  ltp: number;
  volume: number;
  totalVolume?: number;
  high?: number;
  low?: number;
  open?: number;
  cp?: number;
  pdh?: number;
  pdl?: number;
  vwap?: number;
  ltt: number;
  source?: string;
}

export interface OrderBlock {
  id: string;
  type: 'bullish' | 'bearish';
  startTime: number;
  endTime: number;
  high: number;
  low: number;
  z: number;
  mitigated: boolean;
}

export interface IndicatorConfig {
  ema9: {
    enabled: boolean;
    color: string;
    lineWidth: 1 | 2 | 3 | 4;
  };
  ema15: {
    enabled: boolean;
    color: string;
    lineWidth: 1 | 2 | 3 | 4;
  };
  vwap: {
    enabled: boolean;
    color: string;
    lineWidth: 1 | 2 | 3 | 4;
  };
  pdh: {
    enabled: boolean;
    color: string;
    lineWidth: 1 | 2 | 3 | 4;
  };
  pdl: {
    enabled: boolean;
    color: string;
    lineWidth: 1 | 2 | 3 | 4;
  };
  highLow5m: {
    enabled: boolean;
    highColor: string;
    lowColor: string;
    lineWidth: 1 | 2 | 3 | 4;
  };
  highLow15m: {
    enabled: boolean;
    highColor: string;
    lowColor: string;
    lineWidth: 1 | 2 | 3 | 4;
  };
  orderBlocks: {
    enabled: boolean;
    bullishColor: string;
    bearishColor: string;
  };
  sessionBreak: {
    enabled: boolean;
    color: string;
    lineWidth: 1 | 2 | 3 | 4;
  };
  supertrend: {
    enabled: boolean;
    atrPeriod: number;
    factor: number;
    upColor: string;
    downColor: string;
    lineWidth: 1 | 2 | 3 | 4;
  };
  adx: {
    enabled: boolean;
    period: number;
    showLabel: boolean;
  };
  todRvol: {
    enabled: boolean;
    lookbackDays: number;
    highThreshold: number;
  };
  demandSupply: DemandSupplyConfig;
}

export interface DemandSupplyLevelConfig {
  enabled: boolean;
  color: string;
  lineWidth: 1 | 2 | 3 | 4;
  lineStyle: 'Solid' | 'Dashed' | 'Dotted';
}

export interface DemandSupplyConfig {
  enabled: boolean;
  showTouches: boolean;
  tolerancePerc: number;
  d1: DemandSupplyLevelConfig;
  d2: DemandSupplyLevelConfig;
  d3: DemandSupplyLevelConfig;
  w1: DemandSupplyLevelConfig;
  w2: DemandSupplyLevelConfig;
  w3: DemandSupplyLevelConfig;
  m1: DemandSupplyLevelConfig;
  m2: DemandSupplyLevelConfig;
  m3: DemandSupplyLevelConfig;
}

export interface LevelInfo {
  high: number;
  low: number;
  date?: string;
  key?: string;
}

export interface DemandSupplyData {
  d1: LevelInfo | null;
  d2: LevelInfo | null;
  d3: LevelInfo | null;
  w1: LevelInfo | null;
  w2: LevelInfo | null;
  w3: LevelInfo | null;
  m1: LevelInfo | null;
  m2: LevelInfo | null;
  m3: LevelInfo | null;
}

export interface OrderBlockAlert {
  id: string;
  chartId: string;
  symbol: string;
  type: 'bullish' | 'bearish';
  high: number;
  low: number;
  time: number;
  formattedTime: string;
}

export type Timeframe = '1m' | '3m' | '5m' | '15m' | '30m' | '1h' | '1D';

export type ChartType = 'candlestick' | 'line' | 'area' | 'bar' | 'heikin';

export interface ChartConfig {
  id: string;
  instrumentKey: string;
  symbol: string;
  name: string;
  timeframe: Timeframe;
  chartType: ChartType;
  indicators: IndicatorConfig;
}

export type LayoutPreset = 1 | 2 | 3 | 4 | 6 | 8 | 9 | 10 | 12;

export interface UpstoxUserProfile {
  user_id?: string;
  user_name?: string;
  email?: string;
  user_type?: string;
}

export interface UpstoxStatus {
  connected: boolean;
  mode: 'live' | 'standby';
  user?: UpstoxUserProfile | null;
  message?: string;
  activeSubscribersCount?: number;
  tps?: number;
}

export interface InstrumentItem {
  symbol: string;
  name: string;
  instrumentKey: string;
  segment: string;
  basePrice: number;
  tickSize: number;
  industry?: string;
}
