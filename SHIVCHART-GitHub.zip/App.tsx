import React, { useState, useEffect, useCallback } from 'react';
import { Header } from './components/Header';
import { DrawingToolbar, DrawingTool } from './components/DrawingToolbar';
import { ChartGrid } from './components/ChartGrid';
import { StatusBar } from './components/StatusBar';
import { IndicatorModal } from './components/IndicatorModal';
import { UpstoxModal } from './components/UpstoxModal';
import { useTheme } from './hooks/useTheme';
import { useWebSocket } from './hooks/useWebSocket';
import {
  ChartConfig,
  LayoutPreset,
  Timeframe,
  ChartType,
  IndicatorConfig,
  InstrumentItem,
  OrderBlockAlert
} from './types/chart';
import { DEFAULT_INDICATOR_CONFIG } from './utils/chartOptions';
import { soundManager } from './utils/soundAlerts';
import { Sparkles, X } from 'lucide-react';

// Initial 12 preset instruments for 12-chart dashboard
const INITIAL_INSTRUMENTS: { symbol: string; name: string; key: string }[] = [
  { symbol: 'NIFTY', name: 'Nifty 50 Index', key: 'NSE_INDEX|Nifty 50' },
  { symbol: 'BANKNIFTY', name: 'Nifty Bank Index', key: 'NSE_INDEX|Nifty Bank' },
  { symbol: 'FINNIFTY', name: 'Nifty Financial Services', key: 'NSE_INDEX|Nifty Fin Service' },
  { symbol: 'SENSEX', name: 'BSE Sensex Index', key: 'BSE_INDEX|SENSEX' },
  { symbol: 'RELIANCE', name: 'Reliance Industries', key: 'NSE_EQ|INE002A01018' },
  { symbol: 'HDFCBANK', name: 'HDFC Bank Ltd.', key: 'NSE_EQ|INE040A01034' },
  { symbol: 'ICICIBANK', name: 'ICICI Bank Ltd.', key: 'NSE_EQ|INE090A01021' },
  { symbol: 'INFY', name: 'Infosys Ltd.', key: 'NSE_EQ|INE009A01021' },
  { symbol: 'TCS', name: 'Tata Consultancy Services', key: 'NSE_EQ|INE467B01029' },
  { symbol: 'SBIN', name: 'State Bank of India', key: 'NSE_EQ|INE062A01020' },
  { symbol: 'TATAMOTORS', name: 'Tata Motors Ltd.', key: 'NSE_EQ|INE155A01022' },
  { symbol: 'BHARTIARTL', name: 'Bharti Airtel Ltd.', key: 'NSE_EQ|INE397D01024' },
];

export function App() {
  const { isDark, toggleTheme } = useTheme();
  const { isConnected, latency, upstoxStatus, subscribe, unsubscribe } = useWebSocket();

  // Layout Count (persisted in localStorage)
  const [layoutCount, setLayoutCount] = useState<LayoutPreset>(() => {
    const saved = localStorage.getItem('shivchart_layout_count');
    if (saved) {
      const p = parseInt(saved, 10);
      if ([1, 2, 3, 4, 6, 8, 9, 10, 12].includes(p)) return p as LayoutPreset;
    }
    return 4;
  });

  // Left Drawing Toolbar visible/hidden state (persisted)
  const [showToolbar, setShowToolbar] = useState<boolean>(() => {
    return localStorage.getItem('shivchart_show_toolbar') !== 'false';
  });

  // Sound alert enabled state (persisted via soundManager)
  const [soundEnabled, setSoundEnabled] = useState<boolean>(() => soundManager.isEnabled());

  // Order Block live alert banners
  const [obAlerts, setObAlerts] = useState<OrderBlockAlert[]>([]);

  // Active Global Controls
  const [activeTimeframe, setActiveTimeframe] = useState<Timeframe>('5m');
  const [activeChartType, setActiveChartType] = useState<ChartType>('candlestick');
  const [syncCrosshair, setSyncCrosshair] = useState<boolean>(true);
  const [syncTime, setSyncTime] = useState<boolean>(false);
  const [activeTool, setActiveTool] = useState<DrawingTool>(null);
  const [isFullscreen, setIsFullscreen] = useState<boolean>(false);

  // Modals
  const [indicatorModalOpen, setIndicatorModalOpen] = useState<boolean>(false);
  const [selectedChartForIndicators, setSelectedChartForIndicators] = useState<ChartConfig | null>(null);
  const [upstoxModalOpen, setUpstoxModalOpen] = useState<boolean>(false);

  // Instruments catalog from server
  const [instrumentsList, setInstrumentsList] = useState<InstrumentItem[]>([]);

  // Global indicator defaults (persisted in localStorage)
  const [globalIndicators, setGlobalIndicators] = useState<IndicatorConfig>(() => {
    try {
      const saved = localStorage.getItem('shivchart_global_indicators');
      if (saved) {
        const parsed = JSON.parse(saved);
        return {
          ...DEFAULT_INDICATOR_CONFIG,
          ...parsed,
          supertrend: { ...DEFAULT_INDICATOR_CONFIG.supertrend, ...(parsed.supertrend || {}) },
          adx: { ...DEFAULT_INDICATOR_CONFIG.adx, ...(parsed.adx || {}) },
          todRvol: { ...DEFAULT_INDICATOR_CONFIG.todRvol, ...(parsed.todRvol || {}) },
          demandSupply: {
            ...DEFAULT_INDICATOR_CONFIG.demandSupply,
            ...(parsed.demandSupply || {}),
            d1: { ...DEFAULT_INDICATOR_CONFIG.demandSupply.d1, ...(parsed.demandSupply?.d1 || {}) },
            d2: { ...DEFAULT_INDICATOR_CONFIG.demandSupply.d2, ...(parsed.demandSupply?.d2 || {}) },
            d3: { ...DEFAULT_INDICATOR_CONFIG.demandSupply.d3, ...(parsed.demandSupply?.d3 || {}) },
            w1: { ...DEFAULT_INDICATOR_CONFIG.demandSupply.w1, ...(parsed.demandSupply?.w1 || {}) },
            w2: { ...DEFAULT_INDICATOR_CONFIG.demandSupply.w2, ...(parsed.demandSupply?.w2 || {}) },
            w3: { ...DEFAULT_INDICATOR_CONFIG.demandSupply.w3, ...(parsed.demandSupply?.w3 || {}) },
            m1: { ...DEFAULT_INDICATOR_CONFIG.demandSupply.m1, ...(parsed.demandSupply?.m1 || {}) },
            m2: { ...DEFAULT_INDICATOR_CONFIG.demandSupply.m2, ...(parsed.demandSupply?.m2 || {}) },
            m3: { ...DEFAULT_INDICATOR_CONFIG.demandSupply.m3, ...(parsed.demandSupply?.m3 || {}) },
          },
        };
      }
    } catch (_) {}
    return DEFAULT_INDICATOR_CONFIG;
  });

  // 12 Charts state (persisted in localStorage)
  const [charts, setCharts] = useState<ChartConfig[]>(() => {
    try {
      const saved = localStorage.getItem('shivchart_charts');
      if (saved) {
        const parsed: ChartConfig[] = JSON.parse(saved);
        if (Array.isArray(parsed) && parsed.length >= 12) {
          return parsed.map((c) => ({
            ...c,
            indicators: {
              ...DEFAULT_INDICATOR_CONFIG,
              ...(c.indicators || {}),
              supertrend: { ...DEFAULT_INDICATOR_CONFIG.supertrend, ...(c.indicators?.supertrend || {}) },
              adx: { ...DEFAULT_INDICATOR_CONFIG.adx, ...(c.indicators?.adx || {}) },
              todRvol: { ...DEFAULT_INDICATOR_CONFIG.todRvol, ...(c.indicators?.todRvol || {}) },
              demandSupply: {
                ...DEFAULT_INDICATOR_CONFIG.demandSupply,
                ...(c.indicators?.demandSupply || {}),
                d1: { ...DEFAULT_INDICATOR_CONFIG.demandSupply.d1, ...(c.indicators?.demandSupply?.d1 || {}) },
                d2: { ...DEFAULT_INDICATOR_CONFIG.demandSupply.d2, ...(c.indicators?.demandSupply?.d2 || {}) },
                d3: { ...DEFAULT_INDICATOR_CONFIG.demandSupply.d3, ...(c.indicators?.demandSupply?.d3 || {}) },
                w1: { ...DEFAULT_INDICATOR_CONFIG.demandSupply.w1, ...(c.indicators?.demandSupply?.w1 || {}) },
                w2: { ...DEFAULT_INDICATOR_CONFIG.demandSupply.w2, ...(c.indicators?.demandSupply?.w2 || {}) },
                w3: { ...DEFAULT_INDICATOR_CONFIG.demandSupply.w3, ...(c.indicators?.demandSupply?.w3 || {}) },
                m1: { ...DEFAULT_INDICATOR_CONFIG.demandSupply.m1, ...(c.indicators?.demandSupply?.m1 || {}) },
                m2: { ...DEFAULT_INDICATOR_CONFIG.demandSupply.m2, ...(c.indicators?.demandSupply?.m2 || {}) },
                m3: { ...DEFAULT_INDICATOR_CONFIG.demandSupply.m3, ...(c.indicators?.demandSupply?.m3 || {}) },
              },
            },
          }));
        }
      }
    } catch (_) {}
    return INITIAL_INSTRUMENTS.map((inst, index) => ({
      id: `chart-${index + 1}`,
      instrumentKey: inst.key,
      symbol: inst.symbol,
      name: inst.name,
      timeframe: '5m',
      chartType: 'candlestick',
      indicators: JSON.parse(JSON.stringify(DEFAULT_INDICATOR_CONFIG)),
    }));
  });

  // Fetch instruments list (Nifty 500 stocks + indices)
  useEffect(() => {
    fetch('/api/instruments')
      .then((res) => res.json())
      .then((data) => {
        if (Array.isArray(data)) setInstrumentsList(data);
      })
      .catch((err) => console.error('Failed to load instruments:', err));
  }, []);

  // When Upstox connects, automatically ensure all active chart keys are subscribed
  useEffect(() => {
    if (upstoxStatus.connected) {
      const activeKeys = charts.slice(0, layoutCount).map((c) => c.instrumentKey);
      subscribe(activeKeys);
    }
  }, [upstoxStatus.connected, layoutCount, charts, subscribe]);

  // Update a single chart's configuration
  const handleUpdateChartConfig = (id: string, newConfig: Partial<ChartConfig>) => {
    setCharts((prev) => {
      const updated = prev.map((c) => (c.id === id ? { ...c, ...newConfig } : c));
      localStorage.setItem('shivchart_charts', JSON.stringify(updated));
      return updated;
    });
  };

  // Remove a chart
  const handleRemoveChart = (id: string) => {
    if (layoutCount > 1) {
      setLayoutCount((prev) => {
        const next = prev === 12 ? 10 : prev === 10 ? 9 : prev === 9 ? 8 : prev === 8 ? 6 : prev === 6 ? 4 : prev === 4 ? 3 : prev === 3 ? 2 : 1;
        localStorage.setItem('shivchart_layout_count', String(next));
        return next;
      });
    }
  };

  const handleSelectLayout = (l: LayoutPreset) => {
    setLayoutCount(l);
    localStorage.setItem('shivchart_layout_count', String(l));
  };

  const handleToggleToolbar = () => {
    setShowToolbar((prev) => {
      const next = !prev;
      localStorage.setItem('shivchart_show_toolbar', String(next));
      return next;
    });
  };

  const handleToggleSound = () => {
    const next = soundManager.toggle();
    setSoundEnabled(next);
  };

  // Live Order Block Alert Notification Handler
  const handleOrderBlockAlert = useCallback((alert: OrderBlockAlert) => {
    setObAlerts((prev) => [alert, ...prev.slice(0, 3)]);
    setTimeout(() => {
      setObAlerts((prev) => prev.filter((a) => a.id !== alert.id));
    }, 6000);
  }, []);

  // Quick toggle indicator (EMA9, EMA15, VWAP, PDH/PDL, 5m, 15m, OB, Session Line)
  const handleToggleQuickIndicator = (key: keyof IndicatorConfig) => {
    const nextState = !globalIndicators[key].enabled;
    const updatedGlobal = {
      ...globalIndicators,
      [key]: {
        ...globalIndicators[key],
        enabled: nextState,
      },
    };
    setGlobalIndicators(updatedGlobal);
    localStorage.setItem('shivchart_global_indicators', JSON.stringify(updatedGlobal));

    // Update in all 12 charts
    setCharts((prev) => {
      const updated = prev.map((c) => ({
        ...c,
        indicators: {
          ...c.indicators,
          [key]: {
            ...c.indicators[key],
            enabled: nextState,
          },
        },
      }));
      localStorage.setItem('shivchart_charts', JSON.stringify(updated));
      return updated;
    });
  };

  // Global Timeframe Change
  const handleChangeGlobalTimeframe = (tf: Timeframe) => {
    setActiveTimeframe(tf);
    setCharts((prev) => {
      const updated = prev.map((c) => ({ ...c, timeframe: tf }));
      localStorage.setItem('shivchart_charts', JSON.stringify(updated));
      return updated;
    });
  };

  // Global Chart Type Change
  const handleChangeGlobalChartType = (type: ChartType) => {
    setActiveChartType(type);
    setCharts((prev) => {
      const updated = prev.map((c) => ({ ...c, chartType: type }));
      localStorage.setItem('shivchart_charts', JSON.stringify(updated));
      return updated;
    });
  };

  // Save from Indicator Modal (Permanent Persistence in localStorage)
  const handleSaveIndicators = (newConfig: IndicatorConfig, applyToAll: boolean) => {
    if (applyToAll || !selectedChartForIndicators) {
      setGlobalIndicators(newConfig);
      localStorage.setItem('shivchart_global_indicators', JSON.stringify(newConfig));
      setCharts((prev) => {
        const updated = prev.map((c) => ({
          ...c,
          indicators: JSON.parse(JSON.stringify(newConfig)),
        }));
        localStorage.setItem('shivchart_charts', JSON.stringify(updated));
        return updated;
      });
    } else {
      handleUpdateChartConfig(selectedChartForIndicators.id, {
        indicators: newConfig,
      });
    }
  };

  // Fullscreen Toggle
  const handleToggleFullscreen = () => {
    if (!document.fullscreenElement) {
      document.documentElement.requestFullscreen().catch(() => {});
      setIsFullscreen(true);
    } else {
      document.exitFullscreen().catch(() => {});
      setIsFullscreen(false);
    }
  };

  return (
    <div className="flex flex-col h-screen w-screen overflow-hidden select-none">
      {/* Top TradingView Header */}
      <Header
        currentLayout={layoutCount}
        onSelectLayout={handleSelectLayout}
        isDark={isDark}
        onToggleTheme={toggleTheme}
        onOpenIndicators={() => {
          setSelectedChartForIndicators(null);
          setIndicatorModalOpen(true);
        }}
        onOpenUpstox={() => setUpstoxModalOpen(true)}
        upstoxStatus={upstoxStatus}
        globalIndicators={globalIndicators}
        onToggleQuickIndicator={handleToggleQuickIndicator}
        activeTimeframe={activeTimeframe}
        onChangeTimeframe={handleChangeGlobalTimeframe}
        activeChartType={activeChartType}
        onChangeChartType={handleChangeGlobalChartType}
        syncCrosshair={syncCrosshair}
        onToggleSyncCrosshair={() => setSyncCrosshair(!syncCrosshair)}
        syncTime={syncTime}
        onToggleSyncTime={() => setSyncTime(!syncTime)}
        isFullscreen={isFullscreen}
        onToggleFullscreen={handleToggleFullscreen}
        showToolbar={showToolbar}
        onToggleToolbar={handleToggleToolbar}
        soundEnabled={soundEnabled}
        onToggleSound={handleToggleSound}
      />

      {/* Main Workspace (Drawing Toolbar + Multi-Chart Grid) */}
      <div className="flex flex-1 w-full h-[calc(100vh-4.75rem)] overflow-hidden">
        {/* TradingView Drawing Tools Toolbar (Hide/Unhide supported) */}
        <DrawingToolbar
          activeTool={activeTool}
          onSelectTool={setActiveTool}
          onClearDrawings={() => alert('Drawing annotations cleared')}
          isDark={isDark}
          isOpen={showToolbar}
          onToggle={handleToggleToolbar}
        />

        {/* Multi-Chart Grid (Supports 1 to 12 charts) */}
        <ChartGrid
          charts={charts}
          layoutCount={layoutCount}
          isDark={isDark}
          onUpdateChartConfig={handleUpdateChartConfig}
          onRemoveChart={handleRemoveChart}
          onOpenIndicatorsForChart={(chart) => {
            setSelectedChartForIndicators(chart);
            setIndicatorModalOpen(true);
          }}
          instrumentsList={instrumentsList}
          subscribe={subscribe}
          unsubscribe={unsubscribe}
          syncCrosshair={syncCrosshair}
          onOrderBlockAlert={handleOrderBlockAlert}
        />
      </div>

      {/* Floating Order Block Alert Banners */}
      <div className="fixed top-14 right-4 z-50 flex flex-col gap-2 pointer-events-none max-w-sm">
        {obAlerts.map((alert) => (
          <div
            key={alert.id}
            className={`pointer-events-auto p-3 rounded-xl border shadow-2xl backdrop-blur-md flex items-center justify-between gap-3 animate-in slide-in-from-right-5 fade-in duration-200 ${
              alert.type === 'bullish'
                ? 'bg-[#042017]/95 border-emerald-500/50 text-emerald-300 shadow-emerald-950/60'
                : 'bg-[#25080c]/95 border-rose-500/50 text-rose-300 shadow-rose-950/60'
            }`}
          >
            <div className="flex items-center gap-2.5">
              <div className={`p-1.5 rounded-lg ${alert.type === 'bullish' ? 'bg-emerald-500/20' : 'bg-rose-500/20'}`}>
                <Sparkles className="w-4 h-4" />
              </div>
              <div>
                <div className="flex items-center gap-1.5 font-black text-xs tracking-wider">
                  <span>{alert.symbol}</span>
                  <span className={`px-1 py-0.2 rounded text-[10px] font-bold ${
                    alert.type === 'bullish' ? 'bg-emerald-500/20 text-emerald-300' : 'bg-rose-500/20 text-rose-300'
                  }`}>
                    {alert.type === 'bullish' ? '+OB DEMAND' : '-OB SUPPLY'}
                  </span>
                </div>
                <div className="text-[11px] opacity-80 font-mono mt-0.5">
                  Zone: ₹{alert.low.toFixed(2)} - ₹{alert.high.toFixed(2)} • {alert.formattedTime}
                </div>
              </div>
            </div>
            <button
              onClick={() => setObAlerts((prev) => prev.filter((a) => a.id !== alert.id))}
              className="p-1 rounded hover:bg-white/10 opacity-60 hover:opacity-100"
            >
              <X className="w-3.5 h-3.5" />
            </button>
          </div>
        ))}
      </div>

      {/* Futuristic Cyber Bottom Status Bar */}
      <StatusBar
        upstoxStatus={upstoxStatus}
        latency={latency}
        activeChartsCount={layoutCount}
        isDark={isDark}
        onOpenUpstoxModal={() => setUpstoxModalOpen(true)}
      />

      {/* Indicator Customization Modal */}
      <IndicatorModal
        isOpen={indicatorModalOpen}
        onClose={() => {
          setIndicatorModalOpen(false);
          setSelectedChartForIndicators(null);
        }}
        config={selectedChartForIndicators ? selectedChartForIndicators.indicators : globalIndicators}
        onSave={handleSaveIndicators}
        isDark={isDark}
        targetChartSymbol={selectedChartForIndicators?.symbol}
      />

      {/* Upstox Access Token Modal */}
      <UpstoxModal
        isOpen={upstoxModalOpen}
        onClose={() => setUpstoxModalOpen(false)}
        status={upstoxStatus}
        onStatusUpdate={() => {}}
        isDark={isDark}
      />
    </div>
  );
}

export default App;


