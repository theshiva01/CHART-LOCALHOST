import React, { useState, useEffect } from 'react';
import { Wifi, Activity, Cpu } from 'lucide-react';
import { UpstoxStatus } from '../types/chart';

interface StatusBarProps {
  upstoxStatus: UpstoxStatus;
  latency: number;
  activeChartsCount: number;
  isDark: boolean;
  onOpenUpstoxModal: () => void;
}

export const StatusBar: React.FC<StatusBarProps> = ({
  upstoxStatus,
  latency,
  activeChartsCount,
  isDark,
  onOpenUpstoxModal,
}) => {
  const [istTime, setIstTime] = useState('');
  const [istDate, setIstDate] = useState('');

  useEffect(() => {
    const updateTime = () => {
      const now = new Date();
      const timeStr = now.toLocaleTimeString('en-IN', {
        timeZone: 'Asia/Kolkata',
        hour12: false,
        hour: '2-digit',
        minute: '2-digit',
        second: '2-digit',
      });
      const dateStr = now.toLocaleDateString('en-GB', {
        timeZone: 'Asia/Kolkata',
        day: '2-digit',
        month: 'short',
        year: 'numeric',
      }).toUpperCase();
      setIstTime(timeStr);
      setIstDate(dateStr);
    };
    updateTime();
    const interval = setInterval(updateTime, 1000);
    return () => clearInterval(interval);
  }, []);

  return (
    <footer
      className={`h-7 px-3 border-t flex items-center justify-between text-[11px] font-mono shrink-0 select-none ${
        isDark
          ? 'bg-[#1e222d] border-[#2a2e39] text-[#787b86]'
          : 'bg-[#ffffff] border-[#e0e3eb] text-[#787b86]'
      }`}
    >
      {/* Left: Feed status */}
      <div className="flex items-center gap-4">
        <button
          onClick={onOpenUpstoxModal}
          className="flex items-center gap-1.5 hover:underline transition-opacity"
        >
          <span
            className={`w-2 h-2 rounded-full animate-pulse ${
              upstoxStatus.connected ? 'bg-emerald-500' : 'bg-amber-400'
            }`}
          />
          <span className={upstoxStatus.connected ? 'text-emerald-400 font-semibold' : 'text-amber-400 font-medium'}>
            {upstoxStatus.connected
              ? `LIVE: Upstox Connected (${upstoxStatus.user?.user_name || 'Trader'})`
              : 'UPSTOX: Live Data Active (Click to Enter Access Token for Realtime Ticks)'}
          </span>
        </button>

        <div className="flex items-center gap-1">
          <Wifi className="w-3 h-3 opacity-60" />
          <span>{latency} ms</span>
        </div>

        <div className="flex items-center gap-1">
          <Activity className="w-3 h-3 opacity-60" />
          <span>{upstoxStatus.tps || 0} ticks/s</span>
        </div>
      </div>

      {/* Right: Charts count & Futuristic Cyber HUD Clock */}
      <div className="flex items-center gap-3">
        <div className="hidden sm:flex items-center gap-1.5 px-2 py-0.5 rounded bg-black/10 dark:bg-black/40 border border-current/10">
          <Cpu className="w-3 h-3 text-[#2962ff]" />
          <span className="opacity-60">GRID:</span>
          <span className="font-bold text-[#2962ff]">{activeChartsCount} CHARTS</span>
        </div>

        {/* Futuristic Cyber HUD Clock Container */}
        <div className="relative group flex items-center gap-2 px-2.5 py-0.5 rounded-md border border-cyan-500/40 bg-gradient-to-r from-[#031525]/90 via-[#051c2c]/90 to-[#020b14]/90 shadow-[0_0_12px_rgba(6,182,212,0.3)] backdrop-blur-md">
          {/* Neon pulsating radar ping */}
          <div className="relative flex items-center justify-center">
            <span className="w-2 h-2 rounded-full bg-cyan-400" />
            <span className="absolute w-3.5 h-3.5 rounded-full bg-cyan-400/40 animate-ping" />
          </div>

          <div className="flex items-center gap-1.5 font-mono">
            <span className="text-[10px] text-cyan-500/70 font-semibold tracking-wider hidden md:inline">
              {istDate}
            </span>
            <span className="text-cyan-500/40 hidden md:inline">|</span>
            <span className="text-[12px] font-black text-cyan-300 tracking-widest drop-shadow-[0_0_8px_rgba(34,211,238,0.9)]">
              {istTime}
            </span>
            <span className="text-[9px] px-1 py-0.2 rounded bg-cyan-500/20 text-cyan-300 font-bold border border-cyan-500/30 tracking-tight">
              IST +5:30
            </span>
          </div>
        </div>
      </div>
    </footer>
  );
};
