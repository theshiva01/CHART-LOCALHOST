import { ChartOptions, DeepPartial, LineStyle } from 'lightweight-charts';

export const getChartThemeOptions = (isDark: boolean): DeepPartial<ChartOptions> => {
  return {
    layout: {
      background: {
        color: isDark ? '#131722' : '#ffffff',
      },
      textColor: isDark ? '#d1d4dc' : '#131722',
      fontFamily: "'Inter', -apple-system, BlinkMacSystemFont, sans-serif",
      fontSize: 11,
    },
    grid: {
      vertLines: {
        color: isDark ? '#1e222d' : '#f0f3fa',
      },
      horzLines: {
        color: isDark ? '#1e222d' : '#f0f3fa',
      },
    },
    crosshair: {
      mode: 1, // Magnet or Normal
      vertLine: {
        color: isDark ? '#758696' : '#9598a1',
        width: 1,
        style: LineStyle.Dashed,
        labelBackgroundColor: isDark ? '#2a2e39' : '#e0e3eb',
      },
      horzLine: {
        color: isDark ? '#758696' : '#9598a1',
        width: 1,
        style: LineStyle.Dashed,
        labelBackgroundColor: isDark ? '#2a2e39' : '#e0e3eb',
      },
    },
    rightPriceScale: {
      borderColor: isDark ? '#2a2e39' : '#e0e3eb',
      visible: true,
      scaleMargins: {
        top: 0.1,
        bottom: 0.15,
      },
    },
    timeScale: {
      borderColor: isDark ? '#2a2e39' : '#e0e3eb',
      timeVisible: true,
      secondsVisible: false,
    },
    handleScroll: {
      mouseWheel: true,
      pressedMouseMove: true,
      horzTouchDrag: true,
      vertTouchDrag: true,
    },
    handleScale: {
      axisPressedMouseMove: true,
      mouseWheel: true,
      pinch: true,
    },
  };
};

export const CANDLE_COLORS = {
  upColor: '#089981',
  downColor: '#f23645',
  borderUpColor: '#089981',
  borderDownColor: '#f23645',
  wickUpColor: '#089981',
  wickDownColor: '#f23645',
};

export const DEFAULT_INDICATOR_CONFIG = {
  ema9: {
    enabled: true,
    color: '#2962ff', // Blue
    lineWidth: 2 as const,
  },
  ema15: {
    enabled: true,
    color: '#ff9800', // Orange
    lineWidth: 2 as const,
  },
  vwap: {
    enabled: true,
    color: '#e91e63', // Pink/Magenta
    lineWidth: 2 as const,
  },
  pdh: {
    enabled: true,
    color: '#00e676', // Bright Green
    lineWidth: 2 as const,
  },
  pdl: {
    enabled: true,
    color: '#ff1744', // Bright Red
    lineWidth: 2 as const,
  },
  highLow5m: {
    enabled: true,
    highColor: '#00bcd4', // Cyan
    lowColor: '#7c4dff', // Deep Purple
    lineWidth: 2 as const,
  },
  highLow15m: {
    enabled: true,
    highColor: '#ffeb3b', // Yellow
    lowColor: '#ff5722', // Deep Orange
    lineWidth: 2 as const,
  },
  orderBlocks: {
    enabled: true,
    bullishColor: '#10b981', // Demand zone Emerald Green
    bearishColor: '#f43f5e', // Supply zone Rose Red
  },
  sessionBreak: {
    enabled: true,
    color: '#3b82f6', // Solid Blue session break line
    lineWidth: 2 as const,
  },
  supertrend: {
    enabled: true,
    atrPeriod: 10,
    factor: 3.0,
    upColor: '#10b981', // Green Bullish
    downColor: '#f43f5e', // Red Bearish
    lineWidth: 2 as const,
  },
  adx: {
    enabled: true,
    period: 14,
    showLabel: true,
  },
  todRvol: {
    enabled: true,
    lookbackDays: 20,
    highThreshold: 2.0,
  },
  demandSupply: {
    enabled: true,
    showTouches: true,
    tolerancePerc: 0.15,
    // 1, 2, 3 Day
    d1: { enabled: true, color: '#f23645', lineWidth: 1 as const, lineStyle: 'Solid' as const },
    d2: { enabled: true, color: '#ff9800', lineWidth: 1 as const, lineStyle: 'Solid' as const },
    d3: { enabled: true, color: '#ffeb3b', lineWidth: 1 as const, lineStyle: 'Solid' as const },
    // 1, 2, 3 Week
    w1: { enabled: true, color: '#2962ff', lineWidth: 1 as const, lineStyle: 'Dashed' as const },
    w2: { enabled: true, color: '#009688', lineWidth: 1 as const, lineStyle: 'Dashed' as const },
    w3: { enabled: true, color: '#3f51b5', lineWidth: 1 as const, lineStyle: 'Dashed' as const },
    // 1, 2, 3 Month
    m1: { enabled: true, color: '#9c27b0', lineWidth: 2 as const, lineStyle: 'Dotted' as const },
    m2: { enabled: true, color: '#ba68c8', lineWidth: 2 as const, lineStyle: 'Dotted' as const },
    m3: { enabled: true, color: '#ad1457', lineWidth: 2 as const, lineStyle: 'Dotted' as const },
  },
};

