import React, { useState } from 'react';
import { X, Check, Sliders, RefreshCw } from 'lucide-react';
import { IndicatorConfig } from '../types/chart';

interface IndicatorModalProps {
  isOpen: boolean;
  onClose: () => void;
  config: IndicatorConfig;
  onSave: (newConfig: IndicatorConfig, applyToAll: boolean) => void;
  isDark: boolean;
  targetChartSymbol?: string;
}

export const IndicatorModal: React.FC<IndicatorModalProps> = ({
  isOpen,
  onClose,
  config,
  onSave,
  isDark,
  targetChartSymbol,
}) => {
  const [localConfig, setLocalConfig] = useState<IndicatorConfig>(config);

  if (!isOpen) return null;

  const handleToggle = (key: keyof IndicatorConfig) => {
    setLocalConfig(prev => ({
      ...prev,
      [key]: {
        ...prev[key],
        enabled: !prev[key].enabled,
      },
    }));
  };

  const handleColorChange = (key: keyof IndicatorConfig, color: string, field = 'color') => {
    setLocalConfig(prev => ({
      ...prev,
      [key]: {
        ...prev[key],
        [field]: color,
      },
    }));
  };

  const handleWidthChange = (key: keyof IndicatorConfig, width: 1 | 2 | 3 | 4) => {
    setLocalConfig(prev => ({
      ...prev,
      [key]: {
        ...prev[key],
        lineWidth: width,
      },
    }));
  };

  const handlePropChange = (key: keyof IndicatorConfig, field: string, value: any) => {
    setLocalConfig(prev => ({
      ...prev,
      [key]: {
        ...prev[key],
        [field]: value,
      },
    }));
  };

  const handleDsPropChange = (field: string, value: any) => {
    setLocalConfig(prev => ({
      ...prev,
      demandSupply: {
        ...(prev.demandSupply || {}),
        [field]: value,
      },
    }));
  };

  const handleDsLevelChange = (
    levelKey: 'd1' | 'd2' | 'd3' | 'w1' | 'w2' | 'w3' | 'm1' | 'm2' | 'm3',
    field: string,
    value: any
  ) => {
    setLocalConfig(prev => ({
      ...prev,
      demandSupply: {
        ...(prev.demandSupply || {}),
        [levelKey]: {
          ...(prev.demandSupply?.[levelKey] || {}),
          [field]: value,
        },
      },
    }));
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/60 backdrop-blur-sm p-4">
      <div
        className={`w-full max-w-lg rounded-xl shadow-2xl border flex flex-col overflow-hidden max-h-[90vh] ${
          isDark
            ? 'bg-[#1e222d] border-[#2a2e39] text-[#d1d4dc]'
            : 'bg-[#ffffff] border-[#e0e3eb] text-[#131722]'
        }`}
      >
        {/* Header */}
        <div className="flex items-center justify-between px-6 py-4 border-b border-opacity-30 border-gray-500">
          <div className="flex items-center gap-2.5">
            <Sliders className="w-5 h-5 text-[#2962ff]" />
            <div>
              <h2 className="text-base font-bold">Indicators & Levels</h2>
              <p className="text-xs opacity-60">
                {targetChartSymbol ? `Configuring: ${targetChartSymbol}` : 'Global Indicator Settings'}
              </p>
            </div>
          </div>
          <button
            onClick={onClose}
            className="p-1 rounded-md hover:bg-gray-500/20 transition-colors"
          >
            <X className="w-5 h-5 opacity-70 hover:opacity-100" />
          </button>
        </div>

        {/* Content list */}
        <div className="flex-1 overflow-y-auto p-6 space-y-4">
          {/* EMA 9 */}
          <div
            className={`p-3.5 rounded-lg border transition-all ${
              localConfig.ema9.enabled
                ? isDark
                  ? 'bg-[#2a2e39]/50 border-[#2962ff]/50'
                  : 'bg-blue-50/50 border-blue-200'
                : isDark
                ? 'bg-[#131722]/50 border-[#2a2e39] opacity-70'
                : 'bg-gray-50 border-gray-200 opacity-70'
            }`}
          >
            <div className="flex items-center justify-between">
              <div className="flex items-center gap-3">
                <input
                  type="checkbox"
                  id="ema9-toggle"
                  checked={localConfig.ema9.enabled}
                  onChange={() => handleToggle('ema9')}
                  className="w-4 h-4 rounded text-[#2962ff] focus:ring-0 cursor-pointer"
                />
                <label htmlFor="ema9-toggle" className="text-sm font-semibold cursor-pointer">
                  EMA 9 (Exponential Moving Average)
                </label>
              </div>

              <div className="flex items-center gap-3">
                {/* Color input */}
                <div className="flex items-center gap-1.5">
                  <span className="text-xs opacity-60">Color:</span>
                  <input
                    type="color"
                    value={localConfig.ema9.color}
                    onChange={(e) => handleColorChange('ema9', e.target.value)}
                    className="w-6 h-6 rounded cursor-pointer border-0 bg-transparent p-0"
                  />
                </div>
                {/* Line width */}
                <select
                  value={localConfig.ema9.lineWidth}
                  onChange={(e) => handleWidthChange('ema9', Number(e.target.value) as any)}
                  className={`text-xs px-2 py-1 rounded border ${
                    isDark ? 'bg-[#131722] border-[#2a2e39]' : 'bg-white border-gray-300'
                  }`}
                >
                  <option value={1}>1px</option>
                  <option value={2}>2px</option>
                  <option value={3}>3px</option>
                </select>
              </div>
            </div>
          </div>

          {/* EMA 15 */}
          <div
            className={`p-3.5 rounded-lg border transition-all ${
              localConfig.ema15.enabled
                ? isDark
                  ? 'bg-[#2a2e39]/50 border-orange-500/50'
                  : 'bg-orange-50/50 border-orange-200'
                : isDark
                ? 'bg-[#131722]/50 border-[#2a2e39] opacity-70'
                : 'bg-gray-50 border-gray-200 opacity-70'
            }`}
          >
            <div className="flex items-center justify-between">
              <div className="flex items-center gap-3">
                <input
                  type="checkbox"
                  id="ema15-toggle"
                  checked={localConfig.ema15.enabled}
                  onChange={() => handleToggle('ema15')}
                  className="w-4 h-4 rounded text-orange-500 focus:ring-0 cursor-pointer"
                />
                <label htmlFor="ema15-toggle" className="text-sm font-semibold cursor-pointer">
                  EMA 15 (Exponential Moving Average)
                </label>
              </div>

              <div className="flex items-center gap-3">
                <div className="flex items-center gap-1.5">
                  <span className="text-xs opacity-60">Color:</span>
                  <input
                    type="color"
                    value={localConfig.ema15.color}
                    onChange={(e) => handleColorChange('ema15', e.target.value)}
                    className="w-6 h-6 rounded cursor-pointer border-0 bg-transparent p-0"
                  />
                </div>
                <select
                  value={localConfig.ema15.lineWidth}
                  onChange={(e) => handleWidthChange('ema15', Number(e.target.value) as any)}
                  className={`text-xs px-2 py-1 rounded border ${
                    isDark ? 'bg-[#131722] border-[#2a2e39]' : 'bg-white border-gray-300'
                  }`}
                >
                  <option value={1}>1px</option>
                  <option value={2}>2px</option>
                  <option value={3}>3px</option>
                </select>
              </div>
            </div>
          </div>

          {/* VWAP */}
          <div
            className={`p-3.5 rounded-lg border transition-all ${
              localConfig.vwap.enabled
                ? isDark
                  ? 'bg-[#2a2e39]/50 border-pink-500/50'
                  : 'bg-pink-50/50 border-pink-200'
                : isDark
                ? 'bg-[#131722]/50 border-[#2a2e39] opacity-70'
                : 'bg-gray-50 border-gray-200 opacity-70'
            }`}
          >
            <div className="flex items-center justify-between">
              <div className="flex items-center gap-3">
                <input
                  type="checkbox"
                  id="vwap-toggle"
                  checked={localConfig.vwap.enabled}
                  onChange={() => handleToggle('vwap')}
                  className="w-4 h-4 rounded text-pink-500 focus:ring-0 cursor-pointer"
                />
                <label htmlFor="vwap-toggle" className="text-sm font-semibold cursor-pointer">
                  VWAP (Volume Weighted Average Price)
                </label>
              </div>

              <div className="flex items-center gap-3">
                <div className="flex items-center gap-1.5">
                  <span className="text-xs opacity-60">Color:</span>
                  <input
                    type="color"
                    value={localConfig.vwap.color}
                    onChange={(e) => handleColorChange('vwap', e.target.value)}
                    className="w-6 h-6 rounded cursor-pointer border-0 bg-transparent p-0"
                  />
                </div>
                <select
                  value={localConfig.vwap.lineWidth}
                  onChange={(e) => handleWidthChange('vwap', Number(e.target.value) as any)}
                  className={`text-xs px-2 py-1 rounded border ${
                    isDark ? 'bg-[#131722] border-[#2a2e39]' : 'bg-white border-gray-300'
                  }`}
                >
                  <option value={1}>1px</option>
                  <option value={2}>2px</option>
                  <option value={3}>3px</option>
                </select>
              </div>
            </div>
          </div>

          {/* PREVIOUS DAY HIGH / LOW (PDH / PDL) */}
          <div
            className={`p-3.5 rounded-lg border transition-all ${
              localConfig.pdh.enabled || localConfig.pdl.enabled
                ? isDark
                  ? 'bg-[#2a2e39]/50 border-emerald-500/50'
                  : 'bg-emerald-50/50 border-emerald-200'
                : isDark
                ? 'bg-[#131722]/50 border-[#2a2e39] opacity-70'
                : 'bg-gray-50 border-gray-200 opacity-70'
            }`}
          >
            <div className="space-y-2">
              <div className="flex items-center justify-between">
                <div className="flex items-center gap-3">
                  <input
                    type="checkbox"
                    id="pdh-toggle"
                    checked={localConfig.pdh.enabled}
                    onChange={() => handleToggle('pdh')}
                    className="w-4 h-4 rounded text-emerald-500 focus:ring-0 cursor-pointer"
                  />
                  <label htmlFor="pdh-toggle" className="text-sm font-semibold cursor-pointer">
                    Previous Day High (PDH Mark)
                  </label>
                </div>
                <div className="flex items-center gap-1.5">
                  <span className="text-xs opacity-60">High Color:</span>
                  <input
                    type="color"
                    value={localConfig.pdh.color}
                    onChange={(e) => handleColorChange('pdh', e.target.value)}
                    className="w-6 h-6 rounded cursor-pointer border-0 bg-transparent p-0"
                  />
                </div>
              </div>

              <div className="flex items-center justify-between pt-1 border-t border-opacity-20 border-gray-500">
                <div className="flex items-center gap-3">
                  <input
                    type="checkbox"
                    id="pdl-toggle"
                    checked={localConfig.pdl.enabled}
                    onChange={() => handleToggle('pdl')}
                    className="w-4 h-4 rounded text-red-500 focus:ring-0 cursor-pointer"
                  />
                  <label htmlFor="pdl-toggle" className="text-sm font-semibold cursor-pointer">
                    Previous Day Low (PDL Mark)
                  </label>
                </div>
                <div className="flex items-center gap-1.5">
                  <span className="text-xs opacity-60">Low Color:</span>
                  <input
                    type="color"
                    value={localConfig.pdl.color}
                    onChange={(e) => handleColorChange('pdl', e.target.value)}
                    className="w-6 h-6 rounded cursor-pointer border-0 bg-transparent p-0"
                  />
                </div>
              </div>
            </div>
          </div>

          {/* 5 MIN HIGH / LOW MARK */}
          <div
            className={`p-3.5 rounded-lg border transition-all ${
              localConfig.highLow5m.enabled
                ? isDark
                  ? 'bg-[#2a2e39]/50 border-cyan-500/50'
                  : 'bg-cyan-50/50 border-cyan-200'
                : isDark
                ? 'bg-[#131722]/50 border-[#2a2e39] opacity-70'
                : 'bg-gray-50 border-gray-200 opacity-70'
            }`}
          >
            <div className="flex items-center justify-between">
              <div className="flex items-center gap-3">
                <input
                  type="checkbox"
                  id="5m-toggle"
                  checked={localConfig.highLow5m.enabled}
                  onChange={() => handleToggle('highLow5m')}
                  className="w-4 h-4 rounded text-cyan-500 focus:ring-0 cursor-pointer"
                />
                <label htmlFor="5m-toggle" className="text-sm font-semibold cursor-pointer">
                  5 Min High / Low Mark (5m ORH / ORL)
                </label>
              </div>

              <div className="flex items-center gap-3">
                <div className="flex items-center gap-1.5">
                  <span className="text-xs opacity-60">High:</span>
                  <input
                    type="color"
                    value={localConfig.highLow5m.highColor}
                    onChange={(e) => handleColorChange('highLow5m', e.target.value, 'highColor')}
                    className="w-6 h-6 rounded cursor-pointer border-0 bg-transparent p-0"
                  />
                </div>
                <div className="flex items-center gap-1.5">
                  <span className="text-xs opacity-60">Low:</span>
                  <input
                    type="color"
                    value={localConfig.highLow5m.lowColor}
                    onChange={(e) => handleColorChange('highLow5m', e.target.value, 'lowColor')}
                    className="w-6 h-6 rounded cursor-pointer border-0 bg-transparent p-0"
                  />
                </div>
              </div>
            </div>
          </div>

          {/* 15 MIN HIGH / LOW MARK */}
          <div
            className={`p-3.5 rounded-lg border transition-all ${
              localConfig.highLow15m.enabled
                ? isDark
                  ? 'bg-[#2a2e39]/50 border-yellow-500/50'
                  : 'bg-yellow-50/50 border-yellow-200'
                : isDark
                ? 'bg-[#131722]/50 border-[#2a2e39] opacity-70'
                : 'bg-gray-50 border-gray-200 opacity-70'
            }`}
          >
            <div className="flex items-center justify-between">
              <div className="flex items-center gap-3">
                <input
                  type="checkbox"
                  id="15m-toggle"
                  checked={localConfig.highLow15m.enabled}
                  onChange={() => handleToggle('highLow15m')}
                  className="w-4 h-4 rounded text-yellow-500 focus:ring-0 cursor-pointer"
                />
                <label htmlFor="15m-toggle" className="text-sm font-semibold cursor-pointer">
                  15 Min High / Low Mark (15m ORH / ORL)
                </label>
              </div>

              <div className="flex items-center gap-3">
                <div className="flex items-center gap-1.5">
                  <span className="text-xs opacity-60">High:</span>
                  <input
                    type="color"
                    value={localConfig.highLow15m.highColor}
                    onChange={(e) => handleColorChange('highLow15m', e.target.value, 'highColor')}
                    className="w-6 h-6 rounded cursor-pointer border-0 bg-transparent p-0"
                  />
                </div>
                <div className="flex items-center gap-1.5">
                  <span className="text-xs opacity-60">Low:</span>
                  <input
                    type="color"
                    value={localConfig.highLow15m.lowColor}
                    onChange={(e) => handleColorChange('highLow15m', e.target.value, 'lowColor')}
                    className="w-6 h-6 rounded cursor-pointer border-0 bg-transparent p-0"
                  />
                </div>
              </div>
            </div>
          </div>

          {/* SMC ORDER BLOCKS (+OB / -OB) */}
          <div
            className={`p-3.5 rounded-lg border transition-all ${
              localConfig.orderBlocks?.enabled
                ? isDark
                  ? 'bg-[#2a2e39]/50 border-emerald-500/50'
                  : 'bg-emerald-50/50 border-emerald-200'
                : isDark
                ? 'bg-[#131722]/50 border-[#2a2e39] opacity-70'
                : 'bg-gray-50 border-gray-200 opacity-70'
            }`}
          >
            <div className="flex items-center justify-between">
              <div className="flex items-center gap-3">
                <input
                  type="checkbox"
                  id="ob-toggle"
                  checked={localConfig.orderBlocks?.enabled ?? true}
                  onChange={() => handleToggle('orderBlocks')}
                  className="w-4 h-4 rounded text-emerald-500 focus:ring-0 cursor-pointer"
                />
                <div>
                  <label htmlFor="ob-toggle" className="text-sm font-semibold cursor-pointer block">
                    SMC Order Blocks (+OB Demand / -OB Supply)
                  </label>
                  <p className="text-[11px] opacity-60">
                    Calculates institutional demand (+OB) and supply (-OB) mitigation zones
                  </p>
                </div>
              </div>

              <div className="flex items-center gap-3">
                <div className="flex items-center gap-1.5">
                  <span className="text-xs opacity-60">Demand (+OB):</span>
                  <input
                    type="color"
                    value={localConfig.orderBlocks?.bullishColor || '#10b981'}
                    onChange={(e) => handleColorChange('orderBlocks', e.target.value, 'bullishColor')}
                    className="w-6 h-6 rounded cursor-pointer border-0 bg-transparent p-0"
                  />
                </div>
                <div className="flex items-center gap-1.5">
                  <span className="text-xs opacity-60">Supply (-OB):</span>
                  <input
                    type="color"
                    value={localConfig.orderBlocks?.bearishColor || '#f43f5e'}
                    onChange={(e) => handleColorChange('orderBlocks', e.target.value, 'bearishColor')}
                    className="w-6 h-6 rounded cursor-pointer border-0 bg-transparent p-0"
                  />
                </div>
              </div>
            </div>
          </div>

          {/* SESSION BREAK LINE (Yesterday vs Today Solid Line) */}
          <div
            className={`p-3.5 rounded-lg border transition-all ${
              localConfig.sessionBreak?.enabled
                ? isDark
                  ? 'bg-[#2a2e39]/50 border-blue-500/50'
                  : 'bg-blue-50/50 border-blue-200'
                : isDark
                ? 'bg-[#131722]/50 border-[#2a2e39] opacity-70'
                : 'bg-gray-50 border-gray-200 opacity-70'
            }`}
          >
            <div className="flex items-center justify-between">
              <div className="flex items-center gap-3">
                <input
                  type="checkbox"
                  id="session-break-toggle"
                  checked={localConfig.sessionBreak?.enabled ?? true}
                  onChange={() => handleToggle('sessionBreak')}
                  className="w-4 h-4 rounded text-blue-500 focus:ring-0 cursor-pointer"
                />
                <div>
                  <label htmlFor="session-break-toggle" className="text-sm font-semibold cursor-pointer block">
                    Session Break Line (Yesterday / Today)
                  </label>
                  <p className="text-[11px] opacity-60">
                    Solid vertical divider line at session open (09:15 IST)
                  </p>
                </div>
              </div>

              <div className="flex items-center gap-3">
                <div className="flex items-center gap-1.5">
                  <span className="text-xs opacity-60">Color:</span>
                  <input
                    type="color"
                    value={localConfig.sessionBreak?.color || '#3b82f6'}
                    onChange={(e) => handleColorChange('sessionBreak', e.target.value)}
                    className="w-6 h-6 rounded cursor-pointer border-0 bg-transparent p-0"
                  />
                </div>
                <div className="flex items-center gap-1">
                  <span className="text-xs opacity-60">Width:</span>
                  {[1, 2, 3, 4].map((w) => (
                    <button
                      key={w}
                      type="button"
                      onClick={() => handleWidthChange('sessionBreak', w as 1 | 2 | 3 | 4)}
                      className={`w-5 h-5 rounded text-[10px] font-bold border transition-colors ${
                        (localConfig.sessionBreak?.lineWidth || 2) === w
                          ? 'bg-[#2962ff] text-white border-[#2962ff]'
                          : isDark
                          ? 'border-[#2a2e39] text-[#787b86] hover:text-white'
                          : 'border-gray-300 text-gray-600 hover:text-black'
                      }`}
                    >
                      {w}
                    </button>
                  ))}
                </div>
              </div>
            </div>
          </div>

          {/* SUPERTREND (Pine Script: ta.supertrend) */}
          <div
            className={`p-3.5 rounded-lg border transition-all ${
              localConfig.supertrend?.enabled
                ? isDark
                  ? 'bg-[#2a2e39]/50 border-emerald-500/50'
                  : 'bg-emerald-50/50 border-emerald-200'
                : isDark
                ? 'bg-[#131722]/50 border-[#2a2e39] opacity-70'
                : 'bg-gray-50 border-gray-200 opacity-70'
            }`}
          >
            <div className="flex flex-col gap-3">
              <div className="flex items-center justify-between">
                <div className="flex items-center gap-3">
                  <input
                    type="checkbox"
                    id="supertrend-toggle"
                    checked={localConfig.supertrend?.enabled ?? true}
                    onChange={() => handleToggle('supertrend')}
                    className="w-4 h-4 rounded text-emerald-500 focus:ring-0 cursor-pointer"
                  />
                  <div>
                    <label htmlFor="supertrend-toggle" className="text-sm font-semibold cursor-pointer block">
                      Supertrend (Pine Script ta.supertrend)
                    </label>
                    <p className="text-[11px] opacity-60">
                      Adaptive trend-following stop line: Green (uptrend below price) / Red (downtrend above price)
                    </p>
                  </div>
                </div>

                {/* Line width */}
                <div className="flex items-center gap-1">
                  <span className="text-xs opacity-60">Width:</span>
                  {[1, 2, 3, 4].map((w) => (
                    <button
                      key={w}
                      type="button"
                      onClick={() => handleWidthChange('supertrend', w as 1 | 2 | 3 | 4)}
                      className={`w-5 h-5 rounded text-[10px] font-bold border transition-colors ${
                        (localConfig.supertrend?.lineWidth || 2) === w
                          ? 'bg-[#2962ff] text-white border-[#2962ff]'
                          : isDark
                          ? 'border-[#2a2e39] text-[#787b86] hover:text-white'
                          : 'border-gray-300 text-gray-600 hover:text-black'
                      }`}
                    >
                      {w}
                    </button>
                  ))}
                </div>
              </div>

              {/* ATR Period & Factor Inputs & Colors */}
              <div className="grid grid-cols-2 sm:grid-cols-4 gap-2 pt-1 border-t border-current/10">
                <div className="flex items-center gap-1.5">
                  <span className="text-xs opacity-75">ATR Length:</span>
                  <input
                    type="number"
                    min={1}
                    max={100}
                    value={localConfig.supertrend?.atrPeriod || 10}
                    onChange={(e) => handlePropChange('supertrend', 'atrPeriod', Math.max(1, parseInt(e.target.value, 10) || 10))}
                    className={`w-14 px-1.5 py-0.5 rounded text-xs border outline-none font-mono ${
                      isDark ? 'bg-[#131722] border-[#2a2e39] text-white' : 'bg-white border-gray-300'
                    }`}
                  />
                </div>

                <div className="flex items-center gap-1.5">
                  <span className="text-xs opacity-75">Factor:</span>
                  <input
                    type="number"
                    step={0.1}
                    min={0.1}
                    max={20}
                    value={localConfig.supertrend?.factor || 3.0}
                    onChange={(e) => handlePropChange('supertrend', 'factor', Math.max(0.1, parseFloat(e.target.value) || 3.0))}
                    className={`w-14 px-1.5 py-0.5 rounded text-xs border outline-none font-mono ${
                      isDark ? 'bg-[#131722] border-[#2a2e39] text-white' : 'bg-white border-gray-300'
                    }`}
                  />
                </div>

                <div className="flex items-center gap-1.5">
                  <span className="text-xs opacity-75">Bullish:</span>
                  <input
                    type="color"
                    value={localConfig.supertrend?.upColor || '#10b981'}
                    onChange={(e) => handleColorChange('supertrend', e.target.value, 'upColor')}
                    className="w-5 h-5 rounded cursor-pointer border-0 bg-transparent p-0"
                  />
                </div>

                <div className="flex items-center gap-1.5">
                  <span className="text-xs opacity-75">Bearish:</span>
                  <input
                    type="color"
                    value={localConfig.supertrend?.downColor || '#f43f5e'}
                    onChange={(e) => handleColorChange('supertrend', e.target.value, 'downColor')}
                    className="w-5 h-5 rounded cursor-pointer border-0 bg-transparent p-0"
                  />
                </div>
              </div>
            </div>
          </div>

          {/* ADX LIVE CANDLE LABEL (Pine Script: ta.dmi) */}
          <div
            className={`p-3.5 rounded-lg border transition-all ${
              localConfig.adx?.enabled
                ? isDark
                  ? 'bg-[#2a2e39]/50 border-teal-500/50'
                  : 'bg-teal-50/50 border-teal-200'
                : isDark
                ? 'bg-[#131722]/50 border-[#2a2e39] opacity-70'
                : 'bg-gray-50 border-gray-200 opacity-70'
            }`}
          >
            <div className="flex flex-col gap-3">
              <div className="flex items-center justify-between">
                <div className="flex items-center gap-3">
                  <input
                    type="checkbox"
                    id="adx-toggle"
                    checked={localConfig.adx?.enabled ?? true}
                    onChange={() => handleToggle('adx')}
                    className="w-4 h-4 rounded text-teal-500 focus:ring-0 cursor-pointer"
                  />
                  <div>
                    <label htmlFor="adx-toggle" className="text-sm font-semibold cursor-pointer block">
                      ADX Live Candle Label (TradingView ta.dmi)
                    </label>
                    <p className="text-[11px] opacity-60">
                      Real-time floating pill badge right above the live candle with tiered colors
                    </p>
                  </div>
                </div>

                {/* Show label toggle */}
                <label className="flex items-center gap-1.5 text-xs cursor-pointer">
                  <input
                    type="checkbox"
                    checked={localConfig.adx?.showLabel ?? true}
                    onChange={(e) => handlePropChange('adx', 'showLabel', e.target.checked)}
                    className="w-3.5 h-3.5 rounded text-teal-500 cursor-pointer"
                  />
                  <span>Candle Badge</span>
                </label>
              </div>

              {/* Parameters & Color Tiers explanation */}
              <div className="flex flex-wrap items-center justify-between gap-2 pt-1 border-t border-current/10">
                <div className="flex items-center gap-2">
                  <span className="text-xs opacity-75">Smoothing Period:</span>
                  <input
                    type="number"
                    min={2}
                    max={100}
                    value={localConfig.adx?.period || 14}
                    onChange={(e) => handlePropChange('adx', 'period', Math.max(2, parseInt(e.target.value, 10) || 14))}
                    className={`w-14 px-1.5 py-0.5 rounded text-xs border outline-none font-mono ${
                      isDark ? 'bg-[#131722] border-[#2a2e39] text-white' : 'bg-white border-gray-300'
                    }`}
                  />
                </div>

                <div className="flex items-center gap-2 text-[10px] font-mono">
                  <span className="px-1.5 py-0.5 rounded bg-[#e91e63] text-white font-bold">&lt;20 Red (Weak)</span>
                  <span className="px-1.5 py-0.5 rounded bg-[#26a69a] text-white font-bold">20-30 Light Green</span>
                  <span className="px-1.5 py-0.5 rounded bg-[#089981] text-white font-bold">&gt;30 Dark Green (Strong)</span>
                </div>
              </div>
            </div>
          </div>

          {/* TIME-OF-DAY RVOL (Pine Script: Slot Relative Volume) */}
          <div
            className={`p-3.5 rounded-lg border transition-all ${
              localConfig.todRvol?.enabled
                ? isDark
                  ? 'bg-[#2a2e39]/50 border-lime-500/50'
                  : 'bg-lime-50/50 border-lime-200'
                : isDark
                ? 'bg-[#131722]/50 border-[#2a2e39] opacity-70'
                : 'bg-gray-50 border-gray-200 opacity-70'
            }`}
          >
            <div className="flex flex-col gap-3">
              <div className="flex items-center justify-between">
                <div className="flex items-center gap-3">
                  <input
                    type="checkbox"
                    id="tod-rvol-toggle"
                    checked={localConfig.todRvol?.enabled ?? true}
                    onChange={() => handleToggle('todRvol')}
                    className="w-4 h-4 rounded text-lime-500 focus:ring-0 cursor-pointer"
                  />
                  <div>
                    <label htmlFor="tod-rvol-toggle" className="text-sm font-semibold cursor-pointer block">
                      Time-of-Day RVOL (Relative Volume Histogram)
                    </label>
                    <p className="text-[11px] opacity-60">
                      Compares current candle volume against identical intraday time-slots across past N days
                    </p>
                  </div>
                </div>
              </div>

              {/* Lookback & Threshold inputs */}
              <div className="flex flex-wrap items-center justify-between gap-2 pt-1 border-t border-current/10">
                <div className="flex items-center gap-3">
                  <div className="flex items-center gap-1.5">
                    <span className="text-xs opacity-75">Lookback Days:</span>
                    <input
                      type="number"
                      min={1}
                      max={60}
                      value={localConfig.todRvol?.lookbackDays || 20}
                      onChange={(e) => handlePropChange('todRvol', 'lookbackDays', Math.max(1, parseInt(e.target.value, 10) || 20))}
                      className={`w-14 px-1.5 py-0.5 rounded text-xs border outline-none font-mono ${
                        isDark ? 'bg-[#131722] border-[#2a2e39] text-white' : 'bg-white border-gray-300'
                      }`}
                    />
                  </div>

                  <div className="flex items-center gap-1.5">
                    <span className="text-xs opacity-75">High RVOL Threshold:</span>
                    <input
                      type="number"
                      step={0.1}
                      min={1.1}
                      max={10.0}
                      value={localConfig.todRvol?.highThreshold || 2.0}
                      onChange={(e) => handlePropChange('todRvol', 'highThreshold', Math.max(1.1, parseFloat(e.target.value) || 2.0))}
                      className={`w-14 px-1.5 py-0.5 rounded text-xs border outline-none font-mono ${
                        isDark ? 'bg-[#131722] border-[#2a2e39] text-white' : 'bg-white border-gray-300'
                      }`}
                    />
                  </div>
                </div>

                <div className="flex items-center gap-1.5 text-[10px] font-mono">
                  <span className="px-1.5 py-0.5 rounded bg-[#00e676] text-black font-bold">&ge;2.0x Spike</span>
                  <span className="px-1.5 py-0.5 rounded bg-[#26a69a] text-white font-bold">1x-2x Normal</span>
                  <span className="px-1.5 py-0.5 rounded bg-[#758696] text-white font-bold">&lt;1x Low</span>
                </div>
              </div>
            </div>
          </div>

          {/* DEMAND & SUPPLY LEVELS (1,2,3 DAY | 1,2,3 WEEK | 1,2,3 MONTH) */}
          <div
            className={`p-3.5 rounded-lg border transition-all ${
              localConfig.demandSupply?.enabled
                ? isDark
                  ? 'bg-[#2a2e39]/50 border-purple-500/50'
                  : 'bg-purple-50/50 border-purple-200'
                : isDark
                ? 'bg-[#131722]/50 border-[#2a2e39] opacity-70'
                : 'bg-gray-50 border-gray-200 opacity-70'
            }`}
          >
            <div className="flex flex-col gap-3">
              {/* Master Header */}
              <div className="flex items-center justify-between">
                <div className="flex items-center gap-3">
                  <input
                    type="checkbox"
                    id="demand-supply-toggle"
                    checked={localConfig.demandSupply?.enabled ?? true}
                    onChange={() =>
                      handleDsPropChange('enabled', !(localConfig.demandSupply?.enabled ?? true))
                    }
                    className="w-4 h-4 rounded text-purple-500 focus:ring-0 cursor-pointer"
                  />
                  <div>
                    <label htmlFor="demand-supply-toggle" className="text-sm font-semibold cursor-pointer block">
                      Demand & Supply Levels (1,2,3 Day | 1,2,3 Week | 1,2,3 Month)
                    </label>
                    <p className="text-[11px] opacity-60">
                      Multi-timeframe High (Resistance) & Low (Support) levels from today's open with touch counts
                    </p>
                  </div>
                </div>

                {/* Touch reaction tracking toggle */}
                <label className="flex items-center gap-1.5 text-xs cursor-pointer">
                  <input
                    type="checkbox"
                    checked={localConfig.demandSupply?.showTouches ?? true}
                    onChange={(e) => handleDsPropChange('showTouches', e.target.checked)}
                    className="w-3.5 h-3.5 rounded text-purple-500 cursor-pointer"
                  />
                  <span className="flex items-center gap-1 font-semibold">
                    <span>🔥 Badges</span>
                  </span>
                </label>
              </div>

              {/* Touch Zone Tolerance input */}
              <div className="flex items-center justify-between pt-1 border-t border-current/10 text-xs">
                <div className="flex items-center gap-2">
                  <span className="opacity-75">Touch Zone Tolerance (% of price):</span>
                  <input
                    type="number"
                    step={0.01}
                    min={0.01}
                    max={2.0}
                    value={localConfig.demandSupply?.tolerancePerc || 0.15}
                    onChange={(e) =>
                      handleDsPropChange('tolerancePerc', Math.max(0.01, parseFloat(e.target.value) || 0.15))
                    }
                    className={`w-16 px-1.5 py-0.5 rounded text-xs border outline-none font-mono ${
                      isDark ? 'bg-[#131722] border-[#2a2e39] text-white' : 'bg-white border-gray-300'
                    }`}
                  />
                </div>
                <span className="text-[10px] opacity-60">
                  Tests & rejects within zone trigger 🔥 count
                </span>
              </div>

              {/* LEVEL CONFIGS: 1, 2, 3 DAY */}
              <div className="space-y-1.5 pt-2 border-t border-current/10">
                <div className="text-[11px] font-bold uppercase tracking-wider text-red-400">
                  Daily Levels (1D, 2D, 3D)
                </div>
                {(['d1', 'd2', 'd3'] as const).map((key, idx) => {
                  const cfg = localConfig.demandSupply?.[key] || {
                    enabled: true,
                    color: idx === 0 ? '#f23645' : idx === 1 ? '#ff9800' : '#ffeb3b',
                    lineWidth: 1,
                    lineStyle: 'Solid'
                  };
                  const label = idx === 0 ? '1D (Previous Day)' : idx === 1 ? '2D (Two Days Ago)' : '3D (Three Days Ago)';
                  return (
                    <div
                      key={key}
                      className="flex items-center justify-between px-2 py-1 rounded bg-black/5 dark:bg-black/20 text-xs"
                    >
                      <label className="flex items-center gap-2 cursor-pointer font-medium">
                        <input
                          type="checkbox"
                          checked={cfg.enabled}
                          onChange={(e) => handleDsLevelChange(key, 'enabled', e.target.checked)}
                          className="w-3.5 h-3.5 rounded cursor-pointer"
                        />
                        <span>{label}</span>
                      </label>
                      <div className="flex items-center gap-2">
                        <input
                          type="color"
                          value={cfg.color}
                          onChange={(e) => handleDsLevelChange(key, 'color', e.target.value)}
                          className="w-4 h-4 rounded cursor-pointer border-0 bg-transparent p-0"
                        />
                        <select
                          value={cfg.lineStyle}
                          onChange={(e) => handleDsLevelChange(key, 'lineStyle', e.target.value)}
                          className={`text-[10px] px-1 py-0.5 rounded border ${
                            isDark ? 'bg-[#131722] border-[#2a2e39]' : 'bg-white border-gray-300'
                          }`}
                        >
                          <option value="Solid">Solid</option>
                          <option value="Dashed">Dashed</option>
                          <option value="Dotted">Dotted</option>
                        </select>
                        <div className="flex items-center gap-0.5">
                          {[1, 2, 3, 4].map((w) => (
                            <button
                              key={w}
                              type="button"
                              onClick={() => handleDsLevelChange(key, 'lineWidth', w)}
                              className={`w-4 h-4 rounded text-[9px] font-bold border ${
                                cfg.lineWidth === w
                                  ? 'bg-[#2962ff] text-white border-[#2962ff]'
                                  : isDark
                                  ? 'border-[#2a2e39] text-gray-400'
                                  : 'border-gray-300 text-gray-600'
                              }`}
                            >
                              {w}
                            </button>
                          ))}
                        </div>
                      </div>
                    </div>
                  );
                })}
              </div>

              {/* LEVEL CONFIGS: 1, 2, 3 WEEK */}
              <div className="space-y-1.5 pt-2 border-t border-current/10">
                <div className="text-[11px] font-bold uppercase tracking-wider text-blue-400">
                  Weekly Levels (1W, 2W, 3W)
                </div>
                {(['w1', 'w2', 'w3'] as const).map((key, idx) => {
                  const cfg = localConfig.demandSupply?.[key] || {
                    enabled: true,
                    color: idx === 0 ? '#2962ff' : idx === 1 ? '#009688' : '#3f51b5',
                    lineWidth: 1,
                    lineStyle: 'Dashed'
                  };
                  const label = idx === 0 ? '1W (Previous Week)' : idx === 1 ? '2W (Two Weeks Ago)' : '3W (Three Weeks Ago)';
                  return (
                    <div
                      key={key}
                      className="flex items-center justify-between px-2 py-1 rounded bg-black/5 dark:bg-black/20 text-xs"
                    >
                      <label className="flex items-center gap-2 cursor-pointer font-medium">
                        <input
                          type="checkbox"
                          checked={cfg.enabled}
                          onChange={(e) => handleDsLevelChange(key, 'enabled', e.target.checked)}
                          className="w-3.5 h-3.5 rounded cursor-pointer"
                        />
                        <span>{label}</span>
                      </label>
                      <div className="flex items-center gap-2">
                        <input
                          type="color"
                          value={cfg.color}
                          onChange={(e) => handleDsLevelChange(key, 'color', e.target.value)}
                          className="w-4 h-4 rounded cursor-pointer border-0 bg-transparent p-0"
                        />
                        <select
                          value={cfg.lineStyle}
                          onChange={(e) => handleDsLevelChange(key, 'lineStyle', e.target.value)}
                          className={`text-[10px] px-1 py-0.5 rounded border ${
                            isDark ? 'bg-[#131722] border-[#2a2e39]' : 'bg-white border-gray-300'
                          }`}
                        >
                          <option value="Solid">Solid</option>
                          <option value="Dashed">Dashed</option>
                          <option value="Dotted">Dotted</option>
                        </select>
                        <div className="flex items-center gap-0.5">
                          {[1, 2, 3, 4].map((w) => (
                            <button
                              key={w}
                              type="button"
                              onClick={() => handleDsLevelChange(key, 'lineWidth', w)}
                              className={`w-4 h-4 rounded text-[9px] font-bold border ${
                                cfg.lineWidth === w
                                  ? 'bg-[#2962ff] text-white border-[#2962ff]'
                                  : isDark
                                  ? 'border-[#2a2e39] text-gray-400'
                                  : 'border-gray-300 text-gray-600'
                              }`}
                            >
                              {w}
                            </button>
                          ))}
                        </div>
                      </div>
                    </div>
                  );
                })}
              </div>

              {/* LEVEL CONFIGS: 1, 2, 3 MONTH */}
              <div className="space-y-1.5 pt-2 border-t border-current/10">
                <div className="text-[11px] font-bold uppercase tracking-wider text-purple-400">
                  Monthly Levels (1M, 2M, 3M)
                </div>
                {(['m1', 'm2', 'm3'] as const).map((key, idx) => {
                  const cfg = localConfig.demandSupply?.[key] || {
                    enabled: true,
                    color: idx === 0 ? '#9c27b0' : idx === 1 ? '#ba68c8' : '#ad1457',
                    lineWidth: 2,
                    lineStyle: 'Dotted'
                  };
                  const label = idx === 0 ? '1M (Previous Month)' : idx === 1 ? '2M (Two Months Ago)' : '3M (Three Months Ago)';
                  return (
                    <div
                      key={key}
                      className="flex items-center justify-between px-2 py-1 rounded bg-black/5 dark:bg-black/20 text-xs"
                    >
                      <label className="flex items-center gap-2 cursor-pointer font-medium">
                        <input
                          type="checkbox"
                          checked={cfg.enabled}
                          onChange={(e) => handleDsLevelChange(key, 'enabled', e.target.checked)}
                          className="w-3.5 h-3.5 rounded cursor-pointer"
                        />
                        <span>{label}</span>
                      </label>
                      <div className="flex items-center gap-2">
                        <input
                          type="color"
                          value={cfg.color}
                          onChange={(e) => handleDsLevelChange(key, 'color', e.target.value)}
                          className="w-4 h-4 rounded cursor-pointer border-0 bg-transparent p-0"
                        />
                        <select
                          value={cfg.lineStyle}
                          onChange={(e) => handleDsLevelChange(key, 'lineStyle', e.target.value)}
                          className={`text-[10px] px-1 py-0.5 rounded border ${
                            isDark ? 'bg-[#131722] border-[#2a2e39]' : 'bg-white border-gray-300'
                          }`}
                        >
                          <option value="Solid">Solid</option>
                          <option value="Dashed">Dashed</option>
                          <option value="Dotted">Dotted</option>
                        </select>
                        <div className="flex items-center gap-0.5">
                          {[1, 2, 3, 4].map((w) => (
                            <button
                              key={w}
                              type="button"
                              onClick={() => handleDsLevelChange(key, 'lineWidth', w)}
                              className={`w-4 h-4 rounded text-[9px] font-bold border ${
                                cfg.lineWidth === w
                                  ? 'bg-[#2962ff] text-white border-[#2962ff]'
                                  : isDark
                                  ? 'border-[#2a2e39] text-gray-400'
                                  : 'border-gray-300 text-gray-600'
                              }`}
                            >
                              {w}
                            </button>
                          ))}
                        </div>
                      </div>
                    </div>
                  );
                })}
              </div>
            </div>
          </div>
        </div>

        {/* Footer actions */}
        <div className="flex items-center justify-between px-6 py-4 border-t border-opacity-30 border-gray-500 bg-black/10">
          <button
            onClick={() => {
              // Quick reset to all ON
              setLocalConfig(prev => ({
                ...prev,
                ema9: { ...prev.ema9, enabled: true },
                ema15: { ...prev.ema15, enabled: true },
                vwap: { ...prev.vwap, enabled: true },
                pdh: { ...prev.pdh, enabled: true },
                pdl: { ...prev.pdl, enabled: true },
                highLow5m: { ...prev.highLow5m, enabled: true },
                highLow15m: { ...prev.highLow15m, enabled: true },
                orderBlocks: { ...prev.orderBlocks, enabled: true },
                sessionBreak: { ...prev.sessionBreak, enabled: true },
                supertrend: { ...prev.supertrend, enabled: true },
                adx: { ...prev.adx, enabled: true },
                todRvol: { ...prev.todRvol, enabled: true },
                demandSupply: { ...prev.demandSupply, enabled: true },
              }));
            }}
            className="flex items-center gap-1 text-xs opacity-70 hover:opacity-100 transition-opacity"
          >
            <RefreshCw className="w-3.5 h-3.5" />
            Enable All
          </button>

          <div className="flex items-center gap-2.5">
            <button
              onClick={() => {
                onSave(localConfig, true);
                onClose();
              }}
              className={`px-3.5 py-1.5 rounded-md text-xs font-medium border transition-colors ${
                isDark
                  ? 'border-[#2a2e39] hover:bg-[#2a2e39] text-[#d1d4dc]'
                  : 'border-[#e0e3eb] hover:bg-gray-100 text-gray-800'
              }`}
            >
              Apply to All 12 Charts
            </button>

            <button
              onClick={() => {
                onSave(localConfig, false);
                onClose();
              }}
              className="flex items-center gap-1.5 px-4 py-1.5 rounded-md text-xs font-semibold bg-[#2962ff] text-white hover:bg-blue-600 transition-colors shadow-lg shadow-blue-500/20"
            >
              <Check className="w-4 h-4" />
              Save Settings
            </button>
          </div>
        </div>
      </div>
    </div>
  );
};

