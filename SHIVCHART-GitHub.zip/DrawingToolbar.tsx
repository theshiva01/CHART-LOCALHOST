import React from 'react';
import {
  Crosshair,
  TrendingUp,
  Minus,
  Maximize2,
  Square,
  Type,
  Ruler,
  Trash2,
  HelpCircle,
  ChevronLeft,
  ChevronRight
} from 'lucide-react';

export type DrawingTool = 'crosshair' | 'trendline' | 'horizontal' | 'rectangle' | 'text' | 'measure' | null;

interface DrawingToolbarProps {
  activeTool: DrawingTool;
  onSelectTool: (tool: DrawingTool) => void;
  onClearDrawings: () => void;
  isDark: boolean;
  isOpen: boolean;
  onToggle: () => void;
}

export const DrawingToolbar: React.FC<DrawingToolbarProps> = ({
  activeTool,
  onSelectTool,
  onClearDrawings,
  isDark,
  isOpen,
  onToggle,
}) => {
  const tools = [
    { id: 'crosshair', icon: Crosshair, label: 'Crosshair / Pointer' },
    { id: 'trendline', icon: TrendingUp, label: 'Trend Line Tool' },
    { id: 'horizontal', icon: Minus, label: 'Horizontal Support / Resistance Line' },
    { id: 'rectangle', icon: Square, label: 'Box / Supply-Demand Zone' },
    { id: 'text', icon: Type, label: 'Text Note' },
    { id: 'measure', icon: Ruler, label: 'Price & Time Range Measure' },
  ];

  if (!isOpen) {
    return (
      <div className="relative group shrink-0 z-20">
        <button
          onClick={onToggle}
          title="Show Drawing Toolbar (Expand)"
          className={`absolute left-0 top-1/2 -translate-y-1/2 w-3.5 h-12 rounded-r-md flex items-center justify-center border-y border-r transition-all shadow-md ${
            isDark
              ? 'bg-[#1e222d] border-[#2a2e39] text-gray-400 hover:text-white hover:w-5'
              : 'bg-white border-gray-300 text-gray-600 hover:text-black hover:w-5'
          }`}
        >
          <ChevronRight className="w-3 h-3" />
        </button>
      </div>
    );
  }

  return (
    <aside
      className={`w-11 border-r flex flex-col items-center py-2 space-y-1.5 shrink-0 z-20 transition-all ${
        isDark ? 'bg-[#1e222d] border-[#2a2e39]' : 'bg-[#ffffff] border-[#e0e3eb]'
      }`}
    >
      {/* Collapse Button */}
      <button
        onClick={onToggle}
        title="Hide Drawing Toolbar (Maximize Chart Space)"
        className={`w-8 h-6 rounded flex items-center justify-center transition-colors mb-1 ${
          isDark
            ? 'text-[#787b86] hover:text-white hover:bg-[#2a2e39]'
            : 'text-gray-500 hover:text-black hover:bg-gray-100'
        }`}
      >
        <ChevronLeft className="w-3.5 h-3.5" />
      </button>

      <div className="w-6 h-px mb-1 opacity-20 bg-gray-500" />

      {tools.map((t) => {
        const Icon = t.icon;
        const isActive = activeTool === t.id;
        return (
          <button
            key={t.id}
            onClick={() => onSelectTool(isActive ? null : (t.id as DrawingTool))}
            title={t.label}
            className={`w-8 h-8 rounded-md flex items-center justify-center transition-all ${
              isActive
                ? 'bg-[#2962ff] text-white shadow-md'
                : isDark
                ? 'text-[#787b86] hover:text-[#d1d4dc] hover:bg-[#2a2e39]'
                : 'text-gray-500 hover:text-gray-900 hover:bg-gray-100'
            }`}
          >
            <Icon className="w-4 h-4" />
          </button>
        );
      })}

      <div className="w-6 h-px my-1.5 opacity-20 bg-gray-500" />

      <button
        onClick={onClearDrawings}
        title="Clear Chart Drawings"
        className={`w-8 h-8 rounded-md flex items-center justify-center transition-colors ${
          isDark
            ? 'text-[#787b86] hover:text-red-400 hover:bg-red-500/10'
            : 'text-gray-500 hover:text-red-600 hover:bg-red-50'
        }`}
      >
        <Trash2 className="w-4 h-4" />
      </button>

      <div className="flex-1" />

      <button
        onClick={() => {
          alert('SHIVCHART Pro Tips:\n- Use Layout menu to display up to 12 charts!\n- Click any indicator in the header to toggle on/off.\n- Type anywhere on a chart to search stocks instantly.\n- Live Order Blocks detect institutional demand & supply with sound alerts.');
        }}
        title="TradingView Dashboard Guide"
        className={`w-8 h-8 rounded-md flex items-center justify-center transition-colors ${
          isDark
            ? 'text-[#787b86] hover:text-[#d1d4dc] hover:bg-[#2a2e39]'
            : 'text-gray-500 hover:text-gray-900 hover:bg-gray-100'
        }`}
      >
        <HelpCircle className="w-4 h-4" />
      </button>
    </aside>
  );
};

